import { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Metrics } from './components/Metrics';
import { DomainCards } from './components/DomainCards';
import { SystemEvents } from './components/SystemEvents';
import { FullLogModal } from './components/FullLogModal';
import { IdentityConsole } from './components/IdentityConsole';
import { EconomyConsole } from './components/EconomyConsole';
import { MembershipConsole } from './components/MembershipConsole';
import { LexisConsole } from './components/LexisConsole';
import { NotificationsConsole } from './components/NotificationsConsole';
import { LexisCoreDrawer } from './components/LexisCoreDrawer';

import {
  ProfileModal,
  AddLexemeModal,
  GenerateApiKeyModal,
  CreditModal,
  SecurityModal,
} from './components/InteractiveDialogs';

import { Profile, DashboardStats, ApiKey, Lexeme, SystemEvent } from './types';
import defaultAvatar from './assets/default-avatar.svg';

export default function App() {
  // ---- 1. CORE STATES (with offline-first local storage sync) ----
  const [profile, setProfile] = useState<Profile>(() => {
    const saved = localStorage.getItem('lexicon_profile');
    const base: Profile = saved
      ? JSON.parse(saved)
      : {
          name: 'System Administrator',
          role: 'Chief Systems Officer',
          avatar: defaultAvatar,
        };
    // Migrate away from any previously-saved remote Google avatar to the local asset.
    if (base.avatar && base.avatar.startsWith('http')) base.avatar = defaultAvatar;
    return base;
  });

  const [stats, setStats] = useState<DashboardStats>(() => {
    const saved = localStorage.getItem('lexicon_stats');
    return saved
      ? JSON.parse(saved)
      : {
          identityHealth: 99.8,
          apiUsage: 12.4,
          totalLexemes: 4092,
          creditBalance: 850,
        };
  });

  const [apiKeys, setApiKeys] = useState<ApiKey[]>(() => {
    const saved = localStorage.getItem('lexicon_api_keys');
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 'key_u9g2k',
            name: 'Website Auth Middleware Client',
            key: 'lex_live_4a82b9e110cfdf08d51',
            created: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5),
          },
        ];
  });

  const [lexemes, setLexemes] = useState<Lexeme[]>(() => {
    const saved = localStorage.getItem('lexicon_lexemes');
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 'lex_1',
            word: 'Atkinson',
            translation: 'Hyperlegible Next display typography node',
            partOfSpeech: 'noun',
            addedAt: new Date(Date.now() - 1000 * 60 * 60 * 4),
          },
          {
            id: 'lex_2',
            word: 'Courier Prime',
            translation: 'Manuscript style typewriter code monospace face',
            partOfSpeech: 'noun',
            addedAt: new Date(Date.now() - 1000 * 60 * 60 * 12),
          },
        ];
  });

  const [logs, setLogs] = useState<SystemEvent[]>(() => {
    const saved = localStorage.getItem('lexicon_logs');
    if (saved) {
      const parsed = JSON.parse(saved);
      return parsed.map((item: any) => ({ ...item, timestamp: new Date(item.timestamp) }));
    }
    return [
      {
        id: 'log_1',
        title: 'API Key Generated',
        description: 'Domain: Account & Identity (Production Keys namespace initialized)',
        domain: 'Account & Identity',
        type: 'success',
        timestamp: new Date(Date.now() - 1000 * 60 * 10), // 10 mins ago
      },
      {
        id: 'log_2',
        title: 'Credit Deducted: -50',
        description: 'Domain: Economy Center (Automatic security query scan task execution)',
        domain: 'Economy Center',
        type: 'info',
        timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
      },
      {
        id: 'log_3',
        title: 'New Lexeme Added',
        description: 'Domain: Lexis Core (Private word collection metadata update)',
        domain: 'Lexis Core',
        type: 'success',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
      },
      {
        id: 'log_4',
        title: 'Login Success',
        description: 'IP: 192.168.1.1 (Biometric multi-factor session validation)',
        domain: 'Account & Identity',
        type: 'success',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
      },
    ];
  });

  const [mfaEnabled, setMfaEnabled] = useState(true);
  const [sessionTimeout, setSessionTimeout] = useState(60);
  const [membershipTier, setMembershipTier] = useState('Pro');

  // ---- 2. NAVIGATION & LAYOUT ----
  const [activeSidebarTab, setActiveSidebarTab] = useState('dashboard');
  const [currentHeaderTab, setCurrentHeaderTab] = useState('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // ---- 3. MODALS TRIGGER STATUSES ----
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isAddLexemeOpen, setIsAddLexemeOpen] = useState(false);
  const [isGenerateApiKeyOpen, setIsGenerateApiKeyOpen] = useState(false);
  const [isCreditOpen, setIsCreditOpen] = useState(false);
  const [isSecurityOpen, setIsSecurityOpen] = useState(false);
  const [isFullLogOpen, setIsFullLogOpen] = useState(false);
  const [isLexisDrawerOpen, setIsLexisDrawerOpen] = useState(false);

  // Save to localStorage whenever states mutate
  useEffect(() => {
    localStorage.setItem('lexicon_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('lexicon_stats', JSON.stringify(stats));
  }, [stats]);

  useEffect(() => {
    localStorage.setItem('lexicon_api_keys', JSON.stringify(apiKeys));
  }, [apiKeys]);

  useEffect(() => {
    localStorage.setItem('lexicon_lexemes', JSON.stringify(lexemes));
  }, [lexemes]);

  useEffect(() => {
    localStorage.setItem('lexicon_logs', JSON.stringify(logs));
  }, [logs]);

  // ---- 4. REACTIVE HELPER ACTIONS ----
  const handleLogAction = (
    title: string,
    desc: string,
    domain: 'Account & Identity' | 'Economy Center' | 'Membership Hub' | 'Lexis Core' | 'General',
    type: 'info' | 'warning' | 'error' | 'success'
  ) => {
    const newLog: SystemEvent = {
      id: 'log_' + Math.random().toString(36).substring(2, 9),
      title,
      description: desc,
      domain,
      type,
      timestamp: new Date(),
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  // Simulated Login
  const handleSimulateLogin = () => {
    handleLogAction(
      'Session Login Simulated',
      `Administrative session initiated successfully by user [${profile.name}]`,
      'Account & Identity',
      'success'
    );
    // Briefly increase API traffic
    setStats((prev) => ({
      ...prev,
      apiUsage: prev.apiUsage + 0.1,
      identityHealth: Math.min(100, prev.identityHealth + 0.05),
    }));
  };

  // Simulate API Request
  const handleSimulateApiRequest = () => {
    setStats((prev) => ({
      ...prev,
      apiUsage: prev.apiUsage + 0.2,
    }));
    handleLogAction(
      'Gateway API Call Request',
      `Client namespace routing handled 200 payload query safely`,
      'Account & Identity',
      'info'
    );
  };

  // Upgrade or toggle membership tier
  const handleToggleMembership = () => {
    const tiers = ['Developer', 'Pro', 'Enterprise'];
    const currentIdx = tiers.indexOf(membershipTier);
    const nextTier = tiers[(currentIdx + 1) % tiers.length];
    setMembershipTier(nextTier);
    handleLogAction(
      `Membership Level Transitioned`,
      `Security authorization limit migrated from ${membershipTier} to ${nextTier} tier`,
      'Membership Hub',
      'success'
    );
  };

  // Run a simulated background task (rewards or consumes credit)
  const handleSimulateTask = () => {
    const costs = 40;
    if (stats.creditBalance < costs) {
      handleLogAction(
        `Task Execution Terminated`,
        `Insufficient credit balance. Requested task needs ${costs} CRD`,
        'Economy Center',
        'error'
      );
      return;
    }

    // Spend credits and process
    setStats((prev) => ({
      ...prev,
      creditBalance: prev.creditBalance - costs,
      apiUsage: prev.apiUsage + 0.5,
    }));

    handleLogAction(
      `Security Scan Initiated`,
      `Spent -${costs} CRD to verify index tables consistency check. All records clean.`,
      'Economy Center',
      'success'
    );
  };

  // Profile Save
  const handleSaveProfile = (newProfile: Profile) => {
    setProfile(newProfile);
    handleLogAction(
      'Profile Metadata Saved',
      `Administrator info updated: name set to [${newProfile.name}], role set to [${newProfile.role}]`,
      'Account & Identity',
      'info'
    );
  };

  // Add Word / Lexeme
  const handleAddLexeme = (word: string, translation: string, pos: string) => {
    const newWord: Lexeme = {
      id: 'lex_' + Math.random().toString(36).substring(2, 9),
      word,
      translation,
      partOfSpeech: pos,
      addedAt: new Date(),
    };

    setLexemes((prev) => [newWord, ...prev]);
    setStats((prev) => ({
      ...prev,
      totalLexemes: prev.totalLexemes + 1,
    }));

    handleLogAction(
      'New Lexeme Added',
      `Added word [${word}] (${pos}) into Lexis Core workspace namespace`,
      'Lexis Core',
      'success'
    );
  };

  // Remove Word / Lexeme
  const handleRemoveLexeme = (id: string) => {
    const target = lexemes.find((item) => item.id === id);
    if (!target) return;

    setLexemes((prev) => prev.filter((item) => item.id !== id));
    setStats((prev) => ({
      ...prev,
      totalLexemes: Math.max(0, prev.totalLexemes - 1),
    }));

    handleLogAction(
      'Lexeme Removed',
      `Deleted word [${target.word}] from the private Lexis storage namespaces`,
      'Lexis Core',
      'warning'
    );
  };

  // Generate Key
  const handleGenerateKey = (name: string) => {
    const randomHex = Array.from({ length: 24 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('');
    const newKey: ApiKey = {
      id: 'key_' + Math.random().toString(36).substring(2, 7),
      name,
      key: `lex_live_${randomHex}`,
      created: new Date(),
    };

    setApiKeys((prev) => [newKey, ...prev]);
    handleLogAction(
      'API Key Generated',
      `New production token credential [${name}] initialized successfully`,
      'Account & Identity',
      'success'
    );
  };

  // Revoke Key
  const handleRevokeKey = (id: string) => {
    const target = apiKeys.find((item) => item.id === id);
    if (!target) return;

    setApiKeys((prev) => prev.filter((item) => item.id !== id));
    handleLogAction(
      'API Token Revoked',
      `Security token [${target.name}] deprecated and blocked from query access.`,
      'Account & Identity',
      'warning'
    );
  };

  // Adjust Credit Balance
  const handleCreditTransaction = (amount: number, reason: string) => {
    setStats((prev) => ({
      ...prev,
      creditBalance: Math.max(0, prev.creditBalance + amount),
    }));

    handleLogAction(
      amount >= 0 ? `Credits Granted` : `Credits Deducted`,
      `Adjusted ${amount >= 0 ? '+' : ''}${amount} CRD for: ${reason}`,
      'Economy Center',
      amount >= 0 ? 'success' : 'warning'
    );
  };

  // Security Protocols Update
  const handleUpdateSecurity = (mfa: boolean, timeout: number) => {
    setMfaEnabled(mfa);
    setSessionTimeout(timeout);
    handleLogAction(
      'Access Policies Updated',
      `Multi-factor Auth set to ${mfa ? 'ENABLED' : 'DISABLED'}. Idle timeout updated to ${timeout} mins.`,
      'Account & Identity',
      'info'
    );
  };

  // Clear Logs
  const handleClearLogs = () => {
    setLogs([]);
    handleLogAction(
      'Security Audit Log Cleared',
      'All security timeline actions and event metadata cleared by administrator.',
      'General',
      'warning'
    );
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#FAF9F6] text-[#1A212B] antialiased">
      {/* 1. Side Navigation Column */}
      <Sidebar
        profile={profile}
        activeTab={activeSidebarTab}
        setActiveTab={(tab) => {
          setActiveSidebarTab(tab);
          setCurrentHeaderTab(tab);
        }}
        onEditProfile={() => setIsProfileOpen(true)}
        isMobileOpen={isMobileSidebarOpen}
        setIsMobileOpen={setIsMobileSidebarOpen}
      />

      {/* 2. Main Content View Router */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Navbar Header */}
        <Header
          currentTab={currentHeaderTab}
          setCurrentTab={setCurrentHeaderTab}
          recentLogs={logs}
          onOpenSettings={() => setIsSecurityOpen(true)}
          onClearLogs={handleClearLogs}
        />

        {/* Scrollable Canvas Body */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-12">
          {currentHeaderTab === 'identity' && (
            <IdentityConsole
              profile={profile}
              onSaveProfile={handleSaveProfile}
              mfaEnabled={mfaEnabled}
              setMfaEnabled={setMfaEnabled}
              sessionTimeout={sessionTimeout}
              setSessionTimeout={setSessionTimeout}
              apiKeys={apiKeys}
              onGenerateKey={handleGenerateKey}
              onRevokeKey={handleRevokeKey}
              onLogAction={handleLogAction}
            />
          )}

          {currentHeaderTab === 'dashboard' && (
            <div className="max-w-[1280px] mx-auto space-y-8 animate-fadeIn">
              {/* Header Title section */}
              <header className="mb-8">
                <h2 className="font-headline text-3xl font-semibold tracking-tight text-[#1A212B]">
                  首页工作台
                </h2>
                <p className="font-label text-base text-[#585f6a] mt-2">
                  Lexicon 总览域 - Global Overview
                </p>
              </header>

              {/* Stats Bento Grid Top Row */}
              <Metrics
                stats={stats}
                onOpenCreditModal={() => {
                  setActiveSidebarTab('economy');
                  setCurrentHeaderTab('economy');
                }}
                onSimulateApiRequest={handleSimulateApiRequest}
                onQuickAddWord={() => {
                  setActiveSidebarTab('lexis');
                  setCurrentHeaderTab('lexis');
                }}
              />

              {/* Main Grid Layout: Quick Access domains + Recent activity ledger */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Domain Quick Access (Left 2 Columns) */}
                <div className="lg:col-span-2">
                  <DomainCards
                    onSimulateLogin={handleSimulateLogin}
                    onOpenSecurity={() => {
                      setActiveSidebarTab('identity');
                      setCurrentHeaderTab('identity');
                    }}
                    onOpenProfile={() => {
                      setActiveSidebarTab('identity');
                      setCurrentHeaderTab('identity');
                    }}
                    onOpenCredits={() => {
                      setActiveSidebarTab('economy');
                      setCurrentHeaderTab('economy');
                    }}
                    onSimulateTask={handleSimulateTask}
                    membershipTier={membershipTier}
                    onToggleMembership={() => {
                      setActiveSidebarTab('membership');
                      setCurrentHeaderTab('membership');
                    }}
                    onOpenAddLexeme={() => {
                      setActiveSidebarTab('lexis');
                      setCurrentHeaderTab('lexis');
                    }}
                    onOpenDictionary={() => {
                      setActiveSidebarTab('lexis');
                      setCurrentHeaderTab('lexis');
                    }}
                  />
                </div>

                {/* System Events log feed (Right 1 Column) */}
                <div className="lg:col-span-1">
                  <SystemEvents logs={logs} onViewFullLog={() => setIsFullLogOpen(true)} />
                </div>
              </div>
            </div>
          )}

          {currentHeaderTab === 'economy' && (
            <EconomyConsole
              creditBalance={stats.creditBalance}
              onTransaction={handleCreditTransaction}
              logs={logs}
              onLogAction={handleLogAction}
            />
          )}

          {currentHeaderTab === 'membership' && (
            <MembershipConsole
              membershipTier={membershipTier}
              setMembershipTier={setMembershipTier}
              creditBalance={stats.creditBalance}
              onTransaction={handleCreditTransaction}
              onLogAction={handleLogAction}
            />
          )}

          {currentHeaderTab === 'lexis' && (
            <LexisConsole
              lexemes={lexemes}
              onAddLexeme={handleAddLexeme}
              onRemoveLexeme={handleRemoveLexeme}
            />
          )}

          {currentHeaderTab === 'notifications' && (
            <NotificationsConsole
              logs={logs}
              onClearLogs={handleClearLogs}
              onLogAction={handleLogAction}
            />
          )}
        </div>
      </main>

      {/* ---- 5. INTERACTIVE POPUPS MODALS REGISTRY ---- */}
      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        profile={profile}
        onSave={handleSaveProfile}
      />

      <AddLexemeModal
        isOpen={isAddLexemeOpen}
        onClose={() => setIsAddLexemeOpen(false)}
        onAdd={handleAddLexeme}
      />

      <GenerateApiKeyModal
        isOpen={isGenerateApiKeyOpen}
        onClose={() => setIsGenerateApiKeyOpen(false)}
        onGenerate={handleGenerateKey}
      />

      <CreditModal
        isOpen={isCreditOpen}
        onClose={() => setIsCreditOpen(false)}
        currentBalance={stats.creditBalance}
        onTransaction={handleCreditTransaction}
      />

      <SecurityModal
        isOpen={isSecurityOpen}
        onClose={() => setIsSecurityOpen(false)}
        currentMfa={mfaEnabled}
        currentTimeout={sessionTimeout}
        onUpdate={handleUpdateSecurity}
      />

      <FullLogModal
        isOpen={isFullLogOpen}
        onClose={() => setIsFullLogOpen(false)}
        logs={logs}
        onClear={handleClearLogs}
      />

      <LexisCoreDrawer
        isOpen={isLexisDrawerOpen}
        onClose={() => setIsLexisDrawerOpen(false)}
        lexemes={lexemes}
        onAddLexeme={handleAddLexeme}
        onRemoveLexeme={handleRemoveLexeme}
      />
    </div>
  );
}
