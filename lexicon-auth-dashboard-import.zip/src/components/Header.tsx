import React, { useState } from 'react';
import { Settings, HelpCircle, Bell, Shield, Key, History, Activity } from 'lucide-react';
import { SystemEvent } from '../types';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  recentLogs: SystemEvent[];
  onOpenSettings: () => void;
  onClearLogs: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  recentLogs,
  onOpenSettings,
  onClearLogs,
}) => {
  const [showNotificationDropdown, setShowNotificationDropdown] = useState(false);

  const unreadCount = recentLogs.filter((log) => log.type === 'warning' || log.type === 'error').length;

  return (
    <header className="w-full bg-[#FAF9F6] border-b border-[#E5E1D5] sticky top-0 z-20 shrink-0">
      <div className="flex justify-between items-center w-full px-6 md:px-12 py-3.5 max-w-[1280px] mx-auto">
        {/* Navigation Tabs */}
        <div className="flex items-center space-x-3">
          <span className="font-headline text-sm font-bold text-[#1A212B] tracking-tight uppercase">
            {currentTab === 'dashboard' && '二、首页总览域：工作台聚合入口'}
            {currentTab === 'identity' && '一、账号身份域：用户身份校验与凭证管理'}
            {currentTab === 'economy' && '三、积分经济域：全链路积分账户明细'}
            {currentTab === 'membership' && '四、会员增值域：付费订阅与特权管理'}
            {currentTab === 'lexis' && '五、单词核心业务域：词库查询与生词管理'}
            {currentTab === 'notifications' && '六、消息通知域：系统公告与安全报警'}
          </span>
        </div>

        {/* Right Side Controls */}
        <div className="flex items-center space-x-4 relative">
          {/* Settings Trigger */}
          <button
            onClick={onOpenSettings}
            className="text-[#585f6a] hover:text-[#1A212B] transition-colors p-1"
            title="System Settings"
          >
            <Settings size={20} />
          </button>

          {/* Help Button */}
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#585f6a] hover:text-[#1A212B] transition-colors p-1"
            title="Documentation & Help"
          >
            <HelpCircle size={20} />
          </a>

          {/* Notifications Trigger */}
          <div className="relative">
            <button
              onClick={() => setShowNotificationDropdown(!showNotificationDropdown)}
              className="text-[#585f6a] hover:text-[#1A212B] transition-colors p-1 relative focus:outline-none"
              title="Recent Alerts"
            >
              <Bell size={20} />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-[#ba1a1a] rounded-full animate-pulse" />
              )}
            </button>

            {/* Notification Dropdown Popover */}
            {showNotificationDropdown && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setShowNotificationDropdown(false)}
                />
                <div className="absolute right-0 mt-2 w-80 bg-[#FAF9F6] border border-[#E5E1D5] rounded-md shadow-lg overflow-hidden z-50">
                  <div className="px-4 py-3 border-b border-[#E5E1D5] bg-[#F9F7F2] flex justify-between items-center">
                    <span className="font-headline text-sm font-semibold text-[#1A212B]">
                      Recent Activity Notification
                    </span>
                    <button
                      onClick={() => {
                        onClearLogs();
                        setShowNotificationDropdown(false);
                      }}
                      className="font-label text-xs text-[#585f6a] hover:text-[#1A212B] underline"
                    >
                      Clear All
                    </button>
                  </div>
                  <div className="max-h-64 overflow-y-auto custom-scrollbar divide-y divide-[#E5E1D5]">
                    {recentLogs.length === 0 ? (
                      <div className="p-4 text-center font-body text-xs text-[#585f6a]">
                        No recent event notifications
                      </div>
                    ) : (
                      recentLogs.slice(0, 5).map((log) => (
                        <div key={log.id} className="p-3 hover:bg-[#F9F7F2]/50 transition-colors">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-headline text-xs font-semibold text-[#1A212B]">
                              {log.title}
                            </span>
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                log.type === 'error'
                                  ? 'bg-[#ba1a1a]'
                                  : log.type === 'warning'
                                  ? 'bg-amber-500'
                                  : log.type === 'success'
                                  ? 'bg-emerald-600'
                                  : 'bg-[#1A212B]'
                              }`}
                            />
                          </div>
                          <p className="font-body text-[11px] text-[#585f6a] leading-relaxed">
                            {log.description}
                          </p>
                          <span className="font-label text-[10px] text-[#585f6a] opacity-60">
                            {new Date(log.timestamp).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                              second: '2-digit',
                            })}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                  <div className="p-2 border-t border-[#E5E1D5] bg-[#F9F7F2] text-center">
                    <button
                      onClick={() => {
                        setCurrentTab('notifications');
                        setShowNotificationDropdown(false);
                      }}
                      className="font-headline text-xs text-[#1A212B] hover:underline"
                    >
                      查看全部安全通知与公告
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
