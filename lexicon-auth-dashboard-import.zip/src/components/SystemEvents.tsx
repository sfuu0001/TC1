import React from 'react';
import { SystemEvent } from '../types';

interface SystemEventsProps {
  logs: SystemEvent[];
  onViewFullLog: () => void;
}

export const SystemEvents: React.FC<SystemEventsProps> = ({ logs, onViewFullLog }) => {
  // Format the relative time or a neat brief time
  const formatTime = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffMins = Math.floor(diffMs / 60000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} mins ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    return new Date(date).toLocaleDateString();
  };

  return (
    <section className="space-y-6">
      <h3 className="font-label text-lg text-[#1A212B] border-b border-[#E5E1D5] pb-2">
        System Events
      </h3>
      <div className="bento-card rounded-md p-6 h-[440px] flex flex-col justify-between">
        <div className="space-y-4 flex-1 overflow-y-auto pr-2 custom-scrollbar">
          {logs.length === 0 ? (
            <div className="h-full flex items-center justify-center text-center">
              <p className="font-body text-xs text-[#585f6a]">
                No security system logs generated yet.
              </p>
            </div>
          ) : (
            logs.slice(0, 8).map((log) => {
              // Custom colors based on log type
              const bulletColor =
                log.type === 'error'
                  ? 'bg-[#ba1a1a]'
                  : log.type === 'warning'
                  ? 'bg-amber-500'
                  : log.type === 'success'
                  ? 'bg-[#1A212B]'
                  : 'bg-[#E5E1D5]';

              return (
                <div
                  key={log.id}
                  className="flex space-x-3 pb-4 border-b border-[#E5E1D5] last:border-0 last:pb-0"
                >
                  <div className={`mt-1.5 w-2 h-2 rounded-sm ${bulletColor} shrink-0`} />
                  <div className="flex-1">
                    <p className="font-headline text-sm font-semibold text-[#1A212B]">
                      {log.title}
                    </p>
                    <p className="font-body text-xs text-[#585f6a] mt-1">
                      {log.description}
                    </p>
                    <p className="font-label text-xs text-[#585f6a] mt-1 opacity-70">
                      {formatTime(log.timestamp)}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <button
          onClick={onViewFullLog}
          className="mt-4 w-full py-2.5 border border-[#1A212B] rounded-sm text-xs font-headline font-semibold text-[#1A212B] hover:bg-[#1A212B] hover:text-[#FAF9F6] transition-colors"
        >
          View Full Log
        </button>
      </div>
    </section>
  );
};
