import React, { useState } from 'react';
import {
  Bell,
  Volume2,
  ShieldAlert,
  Inbox,
  CheckCheck,
  Megaphone,
  AlertCircle,
  Clock,
  Trash2,
  ShieldCheck,
  Eye
} from 'lucide-react';
import { SystemEvent } from '../types';

interface NotificationsConsoleProps {
  logs: SystemEvent[];
  onClearLogs: () => void;
  onLogAction: (
    title: string,
    desc: string,
    domain: 'Account & Identity' | 'Economy Center' | 'Membership Hub' | 'Lexis Core' | 'General',
    type: 'info' | 'warning' | 'error' | 'success'
  ) => void;
}

export const NotificationsConsole: React.FC<NotificationsConsoleProps> = ({
  logs,
  onClearLogs,
  onLogAction,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'announcements' | 'business'>('all');
  const [toast, setToast] = useState<string | null>(null);

  // Hardcoded official announcements list
  const announcements = [
    {
      id: 'ann_1',
      title: '关于 Lexicon Auth 全域安全升级与对账声明',
      content: '系统即日起全面接入强校验多因素硬件认证（MFA），优化数据传输链路，保障每一位用户和管理账号的信息物理屏障。如有异常，请及时调用身份隔离兜底通道。',
      date: '2026-07-06',
      badge: '安全公告',
      severity: 'high'
    },
    {
      id: 'ann_2',
      title: '系统关于积分兑换中心与增值服务正式上线的通知',
      content: '积分经济域全面贯通！目前官方新年特权礼包兑换码（LEXICON2026）已面向所有管理员发放。您可以使用积分自由在会员中心升级Pro/Ultimate套餐，解锁高级专属计算资源。',
      date: '2026-07-05',
      badge: '业务更新',
      severity: 'info'
    },
    {
      id: 'ann_3',
      title: '关于云端第三方 PostgreSQL 数据库配置及接口标准变更',
      content: '根据业务发展，身份账号域正式引入“显示与配置当前使用的API”功能。管理员可自由选取系统自带接口，或配置专属的自定义云数据库端点，以实现去中心化对账。',
      date: '2026-07-02',
      badge: '配置迁移',
      severity: 'warning'
    }
  ];

  const triggerToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const triggerEmergencyWarning = () => {
    onLogAction(
      '🔴 检测到系统会话异地访问警告',
      '检测到来自未知自治域 IP (104.244.75.12) 的暴力破解握手尝试，高安全等级拦截保护已激活。建议前往账号身份域激活隔离兜底！',
      'Account & Identity',
      'error'
    );
    triggerToast('已在消息中控台触发异地会话红色警告！');
  };

  const triggerBonusGift = () => {
    onLogAction(
      '🎁 官方发放系统运行关怀礼包',
      '恭喜！由于您持续保持高安全等级的多因素接入，系统赠送您 +100 积分关怀礼包，已自动记入账目对账单。',
      'Economy Center',
      'success'
    );
    triggerToast('已成功下发 100 积分大礼包业务提醒！');
  };

  return (
    <div className="space-y-8 max-w-[1280px] mx-auto animate-fadeIn relative pb-12">
      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 right-6 bg-[#ba1a1a] text-[#FAF9F6] border border-[#E5E1D5]/20 font-headline text-xs py-3 px-5 rounded-sm shadow-xl z-50 flex items-center space-x-2 animate-fadeIn">
          <AlertCircle size={14} className="animate-bounce" />
          <span>{toast}</span>
        </div>
      )}

      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-[#E5E1D5] pb-6">
        <div>
          <div className="flex items-center space-x-2.5">
            <h2 className="font-headline text-3xl font-semibold tracking-tight text-[#1A212B]">
              消息通知域
            </h2>
            <span className="px-2 py-0.5 bg-[#1A212B] text-[10px] font-headline font-semibold text-[#FAF9F6] rounded-sm tracking-wider">
              DOMAIN-NOTIFICATIONS
            </span>
          </div>
          <p className="font-label text-sm text-[#585f6a] mt-2">
            提供系统广播、操作审计痕迹以及全域业务安全异动报警日志的统一流转、阅读与拦截归档
          </p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center space-x-2.5">
          <button
            onClick={triggerBonusGift}
            className="px-3 py-1.5 border border-[#1A212B] text-[#1A212B] hover:bg-[#1A212B]/5 font-headline text-xs font-semibold rounded-sm transition-all"
          >
            模拟关怀礼包提醒
          </button>
          <button
            onClick={triggerEmergencyWarning}
            className="px-3 py-1.5 bg-[#ba1a1a] text-[#FAF9F6] hover:bg-[#ba1a1a]/95 font-headline text-xs font-semibold rounded-sm shadow-sm transition-all flex items-center space-x-1"
          >
            <ShieldAlert size={14} />
            <span>模拟威胁红色预警</span>
          </button>
        </div>
      </header>

      {/* Main Grid: Left lists, Right Quick triggers & statuses */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Notification list (8 Columns) */}
        <div className="lg:col-span-8 space-y-6">
          {/* Sub tabs filtering */}
          <div className="flex space-x-2 border-b border-[#E5E1D5] pb-3">
            <button
              onClick={() => setActiveTab('all')}
              className={`pb-2 px-4 font-headline text-xs font-bold border-b-2 transition-all ${
                activeTab === 'all'
                  ? 'border-[#1A212B] text-[#1A212B]'
                  : 'border-transparent text-[#585f6a] hover:text-[#1A212B]'
              }`}
            >
              全部消息 ({announcements.length + logs.length})
            </button>
            <button
              onClick={() => setActiveTab('announcements')}
              className={`pb-2 px-4 font-headline text-xs font-bold border-b-2 transition-all ${
                activeTab === 'announcements'
                  ? 'border-[#1A212B] text-[#1A212B]'
                  : 'border-transparent text-[#585f6a] hover:text-[#1A212B]'
              }`}
            >
              系统官方公告 ({announcements.length})
            </button>
            <button
              onClick={() => setActiveTab('business')}
              className={`pb-2 px-4 font-headline text-xs font-bold border-b-2 transition-all ${
                activeTab === 'business'
                  ? 'border-[#1A212B] text-[#1A212B]'
                  : 'border-transparent text-[#585f6a] hover:text-[#1A212B]'
              }`}
            >
              业务异动报警 ({logs.length})
            </button>
          </div>

          {/* Rendering Lists */}
          <div className="space-y-4">
            
            {/* Announcements Section */}
            {(activeTab === 'all' || activeTab === 'announcements') && (
              <div className="space-y-4">
                {activeTab === 'all' && (
                  <span className="block font-headline text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2">
                    广播级系统公告
                  </span>
                )}
                
                {announcements.map((ann) => (
                  <div key={ann.id} className="bento-card p-5 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-3 hover:border-[#1A212B] transition-all">
                    <div className="flex justify-between items-start gap-4">
                      <div className="flex items-center space-x-2">
                        <Megaphone size={16} className="text-[#1A212B]" />
                        <h4 className="font-headline text-sm font-bold text-[#1A212B]">{ann.title}</h4>
                      </div>
                      <span className={`px-2 py-0.5 text-[9px] font-mono rounded-sm shrink-0 border ${
                        ann.severity === 'high'
                          ? 'bg-red-50 text-red-800 border-red-200'
                          : ann.severity === 'warning'
                          ? 'bg-amber-50 text-amber-800 border-amber-200'
                          : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      }`}>
                        {ann.badge}
                      </span>
                    </div>
                    <p className="font-body text-xs text-[#585f6a] leading-relaxed">
                      {ann.content}
                    </p>
                    <div className="flex items-center space-x-1 font-mono text-[9px] text-gray-400">
                      <Clock size={10} />
                      <span>公告发布时间: {ann.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Dynamic Logs / Business Warnings Section */}
            {(activeTab === 'all' || activeTab === 'business') && (
              <div className="space-y-4 pt-2">
                {activeTab === 'all' && (
                  <span className="block font-headline text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2">
                    审计及安全操作痕迹
                  </span>
                )}

                {logs.length === 0 ? (
                  <div className="py-12 text-center text-xs font-body text-[#585f6a]">
                    暂无动态业务报警提醒消息
                  </div>
                ) : (
                  <div className="divide-y divide-[#E5E1D5]/60 border border-[#E5E1D5]/60 rounded-sm">
                    {logs.map((log) => (
                      <div key={log.id} className="p-4 bg-[#FAF9F6] hover:bg-[#F9F7F2]/30 transition-colors flex justify-between items-start gap-4">
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                            <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                              log.type === 'error'
                                ? 'bg-[#ba1a1a]'
                                : log.type === 'warning'
                                ? 'bg-amber-500'
                                : log.type === 'success'
                                ? 'bg-emerald-600'
                                : 'bg-[#1A212B]'
                            }`} />
                            <h4 className="font-headline text-xs font-semibold text-[#1A212B]">
                              {log.title}
                            </h4>
                            <span className="text-[9px] px-1.5 py-0.2 bg-[#FAF9F6] text-[#585f6a] border border-[#E5E1D5] rounded-full">
                              {log.domain}
                            </span>
                          </div>
                          <p className="font-body text-[11px] text-[#585f6a] leading-relaxed">
                            {log.description}
                          </p>
                        </div>

                        <span className="font-mono text-[9px] text-gray-400 shrink-0">
                          {new Date(log.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

          </div>
        </div>

        {/* Right Column: unified inbox actions (4 Columns) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-4">
            <div className="flex items-center space-x-2.5 border-b border-[#E5E1D5] pb-2">
              <Inbox size={18} className="text-[#1A212B]" />
              <h3 className="font-headline text-sm font-bold text-[#1A212B]">消息管理中心</h3>
            </div>
            
            <p className="font-body text-xs text-[#585f6a] leading-relaxed">
              这里是 Lexicon 的消息和通告汇总网关。所有涉及密匙泄露、多因素修改、积分流水异动或级别续期事件均会自动汇总呈报，供管理员实时排查。
            </p>

            <div className="space-y-3 pt-2">
              <button
                onClick={() => {
                  onClearLogs();
                  triggerToast('已成功清理全域本地操作报警痕迹');
                }}
                className="w-full flex items-center justify-center space-x-2 py-2 border border-[#ba1a1a] text-[#ba1a1a] bg-transparent hover:bg-red-50 font-headline text-xs font-semibold rounded-sm transition-all"
              >
                <Trash2 size={13} />
                <span>清空全部安全痕迹</span>
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
