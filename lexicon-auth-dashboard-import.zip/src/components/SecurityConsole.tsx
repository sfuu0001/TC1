import React, { useState } from 'react';
import { Shield, Settings2, Key, HelpCircle, ToggleLeft, ToggleRight, CheckSquare, Square, RefreshCw } from 'lucide-react';

interface SecurityConsoleProps {
  mfaEnabled: boolean;
  setMfaEnabled: (mfa: boolean) => void;
  sessionTimeout: number;
  setSessionTimeout: (timeout: number) => void;
  onLogAction: (title: string, desc: string, domain: 'Account & Identity' | 'Economy Center' | 'Membership Hub' | 'Lexis Core' | 'General', type: 'info' | 'warning' | 'error' | 'success') => void;
}

export const SecurityConsole: React.FC<SecurityConsoleProps> = ({
  mfaEnabled,
  setMfaEnabled,
  sessionTimeout,
  setSessionTimeout,
  onLogAction,
}) => {
  const [policies, setPolicies] = useState({
    forceRotation: true,
    blockUntrustedIps: false,
    auditPayloads: true,
    enableAnomaliesDetection: false,
  });

  const togglePolicy = (key: keyof typeof policies) => {
    const newVal = !policies[key];
    setPolicies((prev) => ({ ...prev, [key]: newVal }));
    onLogAction(
      `Policy Configuration Updated`,
      `Security setting '${String(key)}' was set to ${newVal ? 'ENABLED' : 'DISABLED'}`,
      'Account & Identity',
      'info'
    );
  };

  const handleMfaToggle = () => {
    const newVal = !mfaEnabled;
    setMfaEnabled(newVal);
    onLogAction(
      `MFA Requirement ${newVal ? 'Enforced' : 'Relaxed'}`,
      `Multi-Factor Authentication policy updated for all root access domains`,
      'Account & Identity',
      newVal ? 'success' : 'warning'
    );
  };

  const handleTimeoutChange = (timeout: number) => {
    setSessionTimeout(timeout);
    onLogAction(
      `Session Lifetime Configured`,
      `Idle timeout limit updated to ${timeout} minutes`,
      'Account & Identity',
      'info'
    );
  };

  return (
    <div className="space-y-6 max-w-[1280px] mx-auto animate-fadeIn">
      {/* Header */}
      <header className="mb-8">
        <h2 className="font-headline text-3xl font-semibold tracking-tight text-[#1A212B]">
          Security Center
        </h2>
        <p className="font-label text-base text-[#585f6a] mt-2">
          Lexicon 安全管控域 - Active Security Controls &amp; Access Control
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Policy Checklist */}
        <section className="lg:col-span-2 space-y-6">
          <h3 className="font-label text-lg text-[#1A212B] border-b border-[#E5E1D5] pb-2">
            Access Controls &amp; Policies
          </h3>
          <div className="space-y-4">
            {/* Policy item 1 */}
            <div
              onClick={() => togglePolicy('forceRotation')}
              className="bento-card p-5 rounded-md flex items-start justify-between cursor-pointer select-none group"
            >
              <div className="space-y-1">
                <span className="font-headline text-sm font-semibold text-[#1A212B] group-hover:underline">
                  Force Periodic API Key Rotation
                </span>
                <p className="font-body text-xs text-[#585f6a]">
                  Enforces key deprecation every 90 days. Non-rotated tokens will throw standard auth payloads.
                </p>
              </div>
              <span className="text-[#1A212B] mt-0.5">
                {policies.forceRotation ? <CheckSquare size={18} /> : <Square size={18} />}
              </span>
            </div>

            {/* Policy item 2 */}
            <div
              onClick={() => togglePolicy('blockUntrustedIps')}
              className="bento-card p-5 rounded-md flex items-start justify-between cursor-pointer select-none group"
            >
              <div className="space-y-1">
                <span className="font-headline text-sm font-semibold text-[#1A212B] group-hover:underline">
                  Block Suspicious IP / Subnet Ranges
                </span>
                <p className="font-body text-xs text-[#585f6a]">
                  Instantly restrict dashboard or database query attempts originating from flagged VPN nodes.
                </p>
              </div>
              <span className="text-[#1A212B] mt-0.5">
                {policies.blockUntrustedIps ? <CheckSquare size={18} /> : <Square size={18} />}
              </span>
            </div>

            {/* Policy item 3 */}
            <div
              onClick={() => togglePolicy('auditPayloads')}
              className="bento-card p-5 rounded-md flex items-start justify-between cursor-pointer select-none group"
            >
              <div className="space-y-1">
                <span className="font-headline text-sm font-semibold text-[#1A212B] group-hover:underline">
                  Full Audit Trail Logging
                </span>
                <p className="font-body text-xs text-[#585f6a]">
                  Logs all non-read REST/gRPC actions in detail, including caller credentials and target metadata.
                </p>
              </div>
              <span className="text-[#1A212B] mt-0.5">
                {policies.auditPayloads ? <CheckSquare size={18} /> : <Square size={18} />}
              </span>
            </div>

            {/* Policy item 4 */}
            <div
              onClick={() => togglePolicy('enableAnomaliesDetection')}
              className="bento-card p-5 rounded-md flex items-start justify-between cursor-pointer select-none group"
            >
              <div className="space-y-1">
                <span className="font-headline text-sm font-semibold text-[#1A212B] group-hover:underline">
                  Heuristic Threat Analysis Engine
                </span>
                <p className="font-body text-xs text-[#585f6a]">
                  Detect anomalous token consumption frequency or weird biometric profile access times automatically.
                </p>
              </div>
              <span className="text-[#1A212B] mt-0.5">
                {policies.enableAnomaliesDetection ? <CheckSquare size={18} /> : <Square size={18} />}
              </span>
            </div>
          </div>
        </section>

        {/* Global Security Parameters Settings */}
        <section className="space-y-6">
          <h3 className="font-label text-lg text-[#1A212B] border-b border-[#E5E1D5] pb-2">
            Active Parameters
          </h3>
          <div className="bento-card rounded-md p-6 space-y-6">
            {/* MFA Switcher */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="font-headline text-sm font-semibold text-[#1A212B]">
                  Required Root MFA
                </span>
                <button
                  onClick={handleMfaToggle}
                  className="text-[#1A212B] transition-transform active:scale-95"
                  aria-label="Toggle MFA Policy"
                >
                  {mfaEnabled ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
                </button>
              </div>
              <p className="font-body text-xs text-[#585f6a]">
                When enabled, administrative operations require fingerprint confirmation before executing state mutations.
              </p>
            </div>

            {/* Timeout Selection */}
            <div className="space-y-2 pt-4 border-t border-[#E5E1D5]">
              <label className="block font-headline text-sm font-semibold text-[#1A212B]">
                Administrative Session Timeout
              </label>
              <select
                value={sessionTimeout}
                onChange={(e) => handleTimeoutChange(Number(e.target.value))}
                className="w-full bg-[#FAF9F6] border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2.5 py-2 rounded-sm focus:outline-none focus:border-[#1A212B]"
              >
                <option value={15}>15 Minutes (High Safety)</option>
                <option value={30}>30 Minutes</option>
                <option value={60}>60 Minutes (Standard)</option>
                <option value={120}>120 Minutes (Extended)</option>
              </select>
              <p className="font-body text-xs text-[#585f6a]">
                Sessions remaining idle for longer than this limit will automatically disconnect and request authentication.
              </p>
            </div>

            {/* Encryption Level Indicator */}
            <div className="pt-4 border-t border-[#E5E1D5] space-y-1">
              <span className="block font-headline text-xs font-semibold text-[#1A212B] uppercase tracking-wider">
                System Encryption Cipher
              </span>
              <div className="flex items-center space-x-2 text-emerald-600">
                <Shield size={14} />
                <span className="font-body text-xs font-semibold">AES-256-GCM / SHA-512</span>
              </div>
              <p className="font-body text-[11px] text-[#585f6a]">
                All database query indices, secret API keystores, and dictionary profiles are stored encrypted at rest.
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
