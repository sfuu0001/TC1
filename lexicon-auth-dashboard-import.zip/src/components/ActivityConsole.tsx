import React, { useState, useMemo } from 'react';
import { Search, Filter, Trash2, Download, Copy, Check, FileText } from 'lucide-react';
import { SystemEvent } from '../types';

interface ActivityConsoleProps {
  logs: SystemEvent[];
  onClearLogs: () => void;
  onLogAction: (title: string, desc: string, domain: 'Account & Identity' | 'Economy Center' | 'Membership Hub' | 'Lexis Core' | 'General', type: 'info' | 'warning' | 'error' | 'success') => void;
}

export const ActivityConsole: React.FC<ActivityConsoleProps> = ({
  logs,
  onClearLogs,
  onLogAction,
}) => {
  const [query, setQuery] = useState('');
  const [domainFilter, setDomainFilter] = useState('all');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [copied, setCopied] = useState(false);

  const filtered = useMemo(() => {
    return logs.filter((log) => {
      const matchesSearch =
        log.title.toLowerCase().includes(query.toLowerCase()) ||
        log.description.toLowerCase().includes(query.toLowerCase());
      const matchesDomain = domainFilter === 'all' || log.domain === domainFilter;
      const matchesSeverity = severityFilter === 'all' || log.type === severityFilter;
      return matchesSearch && matchesDomain && matchesSeverity;
    });
  }, [logs, query, domainFilter, severityFilter]);

  const handleCopy = () => {
    const text = JSON.stringify(logs, null, 2);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(logs, null, 2));
    const dlAnchor = document.createElement('a');
    dlAnchor.setAttribute('href', dataStr);
    dlAnchor.setAttribute('download', 'lexicon_comprehensive_audit_trail.json');
    document.body.appendChild(dlAnchor);
    dlAnchor.click();
    dlAnchor.remove();
  };

  return (
    <div className="space-y-6 max-w-[1280px] mx-auto animate-fadeIn">
      {/* Header */}
      <header className="mb-8">
        <h2 className="font-headline text-3xl font-semibold tracking-tight text-[#1A212B]">
          Audit Timeline
        </h2>
        <p className="font-label text-base text-[#585f6a] mt-2">
          Lexicon 审计台 - Full comprehensive audit logs of security actions, payload transactions, and dictionary lookups.
        </p>
      </header>

      {/* Control Actions & Filtering Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <div className="bento-card rounded-md p-5 space-y-4">
            <span className="block font-headline text-sm font-semibold text-[#1A212B]">
              Refine Search
            </span>

            {/* Keyword search */}
            <div className="space-y-1">
              <label className="block font-headline text-[10px] text-[#585f6a] uppercase tracking-wider">
                Keyword
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-2.5 pointer-events-none text-[#585f6a]">
                  <Search size={14} />
                </span>
                <input
                  type="text"
                  placeholder="Query parameters..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="w-full bg-[#FAF9F6] border border-[#E5E1D5] text-[#1A212B] font-body text-xs pl-8 pr-3 py-1.5 rounded-sm focus:outline-none"
                />
              </div>
            </div>

            {/* Domain selector */}
            <div className="space-y-1">
              <label className="block font-headline text-[10px] text-[#585f6a] uppercase tracking-wider">
                Domain Space
              </label>
              <select
                value={domainFilter}
                onChange={(e) => setDomainFilter(e.target.value)}
                className="w-full bg-[#FAF9F6] border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2 py-1.5 rounded-sm focus:outline-none"
              >
                <option value="all">All Domains</option>
                <option value="Account & Identity">Account & Identity</option>
                <option value="Economy Center">Economy Center</option>
                <option value="Membership Hub">Membership Hub</option>
                <option value="Lexis Core">Lexis Core</option>
                <option value="General">General</option>
              </select>
            </div>

            {/* Severity selector */}
            <div className="space-y-1">
              <label className="block font-headline text-[10px] text-[#585f6a] uppercase tracking-wider">
                Severity Level
              </label>
              <select
                value={severityFilter}
                onChange={(e) => setSeverityFilter(e.target.value)}
                className="w-full bg-[#FAF9F6] border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2 py-1.5 rounded-sm focus:outline-none"
              >
                <option value="all">All Levels</option>
                <option value="success">Success (Ink)</option>
                <option value="info">Info (Muted)</option>
                <option value="warning">Warning (Amber)</option>
                <option value="error">Error (Red)</option>
              </select>
            </div>

            {/* Utility actions */}
            <div className="pt-4 border-t border-[#E5E1D5] space-y-2">
              <button
                onClick={handleCopy}
                className="w-full py-2 bg-[#FAF9F6] border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm text-xs font-headline font-semibold text-[#1A212B] transition-colors flex items-center justify-center space-x-1.5"
              >
                {copied ? <Check size={14} /> : <Copy size={14} />}
                <span>{copied ? 'Copied Timeline' : 'Copy All Logs'}</span>
              </button>

              <button
                onClick={handleDownload}
                className="w-full py-2 bg-[#FAF9F6] border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm text-xs font-headline font-semibold text-[#1A212B] transition-colors flex items-center justify-center space-x-1.5"
              >
                <Download size={14} />
                <span>Download JSON Payload</span>
              </button>

              <button
                onClick={onClearLogs}
                className="w-full py-2 bg-transparent hover:bg-brand-error/5 border border-transparent hover:border-brand-error/30 rounded-sm text-xs font-headline font-semibold text-brand-error transition-colors flex items-center justify-center space-x-1.5"
              >
                <Trash2 size={14} />
                <span>Clear Audit Ledger</span>
              </button>
            </div>
          </div>
        </div>

        {/* Audit ledger spreadsheet */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bento-card rounded-md p-5 min-h-[480px] flex flex-col justify-between">
            <div className="overflow-x-auto custom-scrollbar">
              <table className="w-full text-left font-body text-xs border-collapse min-w-[550px]">
                <thead>
                  <tr className="border-b border-[#E5E1D5] text-[#1A212B]">
                    <th className="pb-3.5 font-headline font-semibold">Timestamp</th>
                    <th className="pb-3.5 font-headline font-semibold">Domain Sector</th>
                    <th className="pb-3.5 font-headline font-semibold">Security Event</th>
                    <th className="pb-3.5 font-headline font-semibold">Metadata payload</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5E1D5]/60 text-[#1A212B]">
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="py-12 text-center text-[#585f6a]">
                        <p className="font-headline font-semibold">No transactions match the filter parameters.</p>
                        <p className="font-label text-xs mt-1">Refine your search parameters or log a new action on the Dashboard.</p>
                      </td>
                    </tr>
                  ) : (
                    filtered.map((log) => {
                      const badgeBg =
                        log.type === 'error'
                          ? 'border-brand-error/20 text-brand-error bg-brand-error/5'
                          : log.type === 'warning'
                          ? 'border-amber-500/20 text-amber-600 bg-amber-500/5'
                          : log.type === 'success'
                          ? 'border-emerald-600/20 text-emerald-600 bg-emerald-600/5'
                          : 'border-[#E5E1D5] text-[#1A212B] bg-[#FAF9F6]';

                      return (
                        <tr key={log.id} className="hover:bg-[#F9F7F2]/40 transition-colors">
                          <td className="py-3 text-[11px] text-[#585f6a]">
                            {new Date(log.timestamp).toLocaleString()}
                          </td>
                          <td className="py-3">
                            <span className="px-1.5 py-0.5 bg-[#F9F7F2] border border-[#E5E1D5] text-[10px] font-label rounded-sm text-[#1A212B]">
                              {log.domain}
                            </span>
                          </td>
                          <td className="py-3">
                            <div className="flex items-center space-x-2">
                              <span
                                className={`px-1 py-0.5 border rounded-xs text-[9px] font-headline font-semibold ${badgeBg}`}
                              >
                                {log.type.toUpperCase()}
                              </span>
                              <span className="font-semibold text-[#1A212B]">{log.title}</span>
                            </div>
                          </td>
                          <td className="py-3 text-[11px] text-[#585f6a]">
                            {log.description}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            <div className="pt-4 border-t border-[#E5E1D5] flex justify-between items-center text-xs font-label text-[#585f6a]">
              <span>LEDGER HASH: SHA256:{logs.length * 1337}</span>
              <span>PAGE 1 OF 1</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
