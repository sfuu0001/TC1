import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  Search,
  BookMarked,
  FileText,
  Trash2,
  CheckCircle2,
  HelpCircle,
  FolderPlus,
  Sparkles,
  ArrowRightLeft,
  Filter
} from 'lucide-react';
import { Lexeme } from '../types';

interface LexisConsoleProps {
  lexemes: Lexeme[];
  onAddLexeme: (word: string, translation: string, pos: string) => void;
  onRemoveLexeme: (id: string) => void;
}

export const LexisConsole: React.FC<LexisConsoleProps> = ({
  lexemes,
  onAddLexeme,
  onRemoveLexeme,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeSubTab, setActiveSubTab] = useState<'official' | 'custom'>('official');
  const [selectedLevel, setSelectedLevel] = useState('ALL');

  // Local state for adding word
  const [newWord, setNewWord] = useState('');
  const [newTranslation, setNewTranslation] = useState('');
  const [newPos, setNewPos] = useState('noun');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Hardcoded highly aesthetic official word list
  const officialWords = [
    { word: 'Protocol', translation: '协议 / 规程：数据传输及通讯握手约定的格式集', pos: 'noun', level: 'CET-4' },
    { word: 'Biometrics', translation: '生物识别技术：利用人脸、指纹或声纹建立的多因素凭证身份验证', pos: 'noun', level: 'GRE' },
    { word: 'Credentials', translation: '凭证 / 证书：可用于安全节点匹配、会话授信的令牌和密钥载体', pos: 'noun', level: 'CET-6' },
    { word: 'Telemetry', translation: '遥测系统：全自动高负荷 API 请求调用、流控流量与安全诊断监控', pos: 'noun', level: 'GRE' },
    { word: 'Handshake', translation: '握手：网络连接初始化时，服务器与客户端交换物理安全因子的流程', pos: 'noun', level: 'CET-4' },
    { word: 'Symmetric', translation: '对称的：在全域安全备份与异常恢复中使用的快速高强度对称型加密', pos: 'adj', level: 'CET-6' },
    { word: 'Immutable', translation: '不可变的：在区块链对账或不可篡改日志中，记录不被覆写的属性', pos: 'adj', level: 'GRE' },
    { word: 'Signature', translation: '签名：利用公钥密码学哈希计算，来对会话完整性进行校验的标识', pos: 'noun', level: 'CET-4' },
    { word: 'Gateway', translation: '网关：全域系统流量和API请求的统一安全过滤与防护转发中控台', pos: 'noun', level: 'CET-6' },
    { word: 'Audit', translation: '审计：对操作日志、API密钥变更、积分交易流水进行的全局透明追踪检查', pos: 'verb', level: 'CET-4' },
  ];

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleImportWord = (word: string, translation: string, pos: string) => {
    // Check if already in custom
    const exists = lexemes.some(item => item.word.toLowerCase() === word.toLowerCase());
    if (exists) {
      triggerToast(`⚠️ "${word}" 已经存在于您的自定义单词库中`);
      return;
    }

    onAddLexeme(word, translation, pos);
    triggerToast(`📥 成功导入词汇 "${word}" 到您的自定义单词库！`);
  };

  const handleCreateCustomWord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWord.trim() || !newTranslation.trim()) {
      triggerToast('⚠️ 请填写完整的单词和中文释义');
      return;
    }

    onAddLexeme(newWord.trim(), newTranslation.trim(), newPos);
    triggerToast(`✨ 成功创建私有词汇 "${newWord}"`);
    setNewWord('');
    setNewTranslation('');
  };

  // Filter official words
  const filteredOfficial = officialWords.filter(item => {
    const matchesSearch = item.word.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          item.translation.includes(searchTerm);
    const matchesLevel = selectedLevel === 'ALL' || item.level === selectedLevel;
    return matchesSearch && matchesLevel;
  });

  // Filter custom words
  const filteredCustom = lexemes.filter(item => {
    return item.word.toLowerCase().includes(searchTerm.toLowerCase()) || 
           item.translation.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="space-y-8 max-w-[1280px] mx-auto animate-fadeIn relative pb-12">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 bg-[#1A212B] text-[#FAF9F6] border border-[#E5E1D5]/20 font-headline text-xs py-3 px-5 rounded-sm shadow-xl z-50 flex items-center space-x-2 animate-fadeIn">
          <BookMarked size={14} className="text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-[#E5E1D5] pb-6">
        <div>
          <div className="flex items-center space-x-2.5">
            <h2 className="font-headline text-3xl font-semibold tracking-tight text-[#1A212B]">
              单词核心业务域
            </h2>
            <span className="px-2 py-0.5 bg-[#1A212B] text-[10px] font-headline font-semibold text-[#FAF9F6] rounded-sm tracking-wider">
              DOMAIN-LEXIS
            </span>
          </div>
          <p className="font-label text-sm text-[#585f6a] mt-2">
            集成多维释义官方考研学术词库，提供全功能自定义生词导入、管理与归档熟词状态
          </p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center space-x-4">
          <div className="bg-[#FAF9F6] border border-[#E5E1D5] px-4 py-1.5 rounded-sm flex items-center space-x-2">
            <BookOpen size={14} className="text-[#1A212B]" />
            <span className="font-mono text-xs font-semibold">
              自定义词量: {lexemes.length} 个
            </span>
          </div>
        </div>
      </header>

      {/* Search and Tab filter bar */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-center bg-[#E5E1D5]/25 p-4 rounded-sm border border-[#E5E1D5]/50">
        {/* Tabs switcher */}
        <div className="flex space-x-2 w-full md:w-auto">
          <button
            onClick={() => {
              setActiveSubTab('official');
              setSearchTerm('');
            }}
            className={`flex-1 md:flex-initial flex items-center justify-center space-x-2 px-5 py-2 rounded-sm font-headline text-xs font-semibold border transition-all ${
              activeSubTab === 'official'
                ? 'bg-[#1A212B] text-[#FAF9F6] border-[#1A212B]'
                : 'bg-white text-[#585f6a] border-[#E5E1D5] hover:bg-black/5'
            }`}
          >
            <BookOpen size={14} />
            <span>官方单词库</span>
          </button>
          <button
            onClick={() => {
              setActiveSubTab('custom');
              setSearchTerm('');
            }}
            className={`flex-1 md:flex-initial flex items-center justify-center space-x-2 px-5 py-2 rounded-sm font-headline text-xs font-semibold border transition-all ${
              activeSubTab === 'custom'
                ? 'bg-[#1A212B] text-[#FAF9F6] border-[#1A212B]'
                : 'bg-white text-[#585f6a] border-[#E5E1D5] hover:bg-black/5'
            }`}
          >
            <BookMarked size={14} />
            <span>自定义生词本 ({lexemes.length})</span>
          </button>
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder={activeSubTab === 'official' ? "搜索官方高频学术单词..." : "搜索我的私有生词..."}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-body text-xs pl-9 pr-4 py-2 rounded-sm focus:outline-none focus:border-[#1A212B]"
          />
        </div>
      </div>

      {/* Grid Layout depending on active SubTab */}
      {activeSubTab === 'official' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Main Official Words Grid (8 Columns) */}
          <div className="lg:col-span-8 space-y-4">
            <div className="flex justify-between items-center border-b border-[#E5E1D5]/60 pb-2">
              <span className="font-headline text-xs font-bold text-[#1A212B]">
                官方考研学术核心生词表
              </span>
              
              {/* Level select */}
              <div className="flex items-center space-x-2">
                <Filter size={12} className="text-gray-400" />
                <select
                  value={selectedLevel}
                  onChange={(e) => setSelectedLevel(e.target.value)}
                  className="bg-transparent text-xs font-headline font-semibold text-[#1A212B] focus:outline-none"
                >
                  <option value="ALL">全段位词汇</option>
                  <option value="CET-4">CET-4 基础级别</option>
                  <option value="CET-6">CET-6 进阶级别</option>
                  <option value="GRE">GRE 难点冲刺</option>
                </select>
              </div>
            </div>

            {/* List */}
            {filteredOfficial.length === 0 ? (
              <div className="py-12 border border-dashed border-[#E5E1D5] rounded-sm text-center text-xs text-[#585f6a] bg-[#FAF9F6]">
                没有匹配到官方库里的单词
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredOfficial.map((item) => (
                  <div key={item.word} className="bento-card p-4 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] flex flex-col justify-between space-y-3 hover:border-[#1A212B] transition-all">
                    <div>
                      <div className="flex justify-between items-center">
                        <h4 className="font-headline text-base font-bold text-[#1A212B] tracking-tight">{item.word}</h4>
                        <span className="px-1.5 py-0.5 bg-[#E5E1D5] text-[#1A212B] text-[8px] font-mono rounded-sm">
                          {item.level}
                        </span>
                      </div>
                      <span className="inline-block mt-0.5 font-mono text-[9px] italic text-[#585f6a]">
                        ({item.pos}.)
                      </span>
                      <p className="font-body text-xs text-[#585f6a] mt-2 leading-relaxed">
                        {item.translation}
                      </p>
                    </div>

                    <button
                      onClick={() => handleImportWord(item.word, item.translation, item.pos)}
                      className="w-full py-1.5 bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90 font-headline text-[10px] font-bold rounded-sm transition-all flex items-center justify-center space-x-1"
                    >
                      <FolderPlus size={11} />
                      <span>导入到自定义单词库</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Guide Widget (4 Columns) */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-4">
              <h3 className="font-headline text-sm font-bold text-[#1A212B]">单词导入说明</h3>
              <p className="font-body text-xs text-[#585f6a] leading-relaxed">
                1. 官方单词库汇集了考研、学术阅读高频核心安全及通用词汇。<br />
                2. 支持一键导入：点击“导入”可将官方重点词添加至生词本，方便随时复习。<br />
                3. 重复检测：已导入词汇无法重复添加，保证数据的简洁。
              </p>
              <div className="bg-[#E5E1D5]/20 p-3 rounded-sm text-[11px] font-body text-[#585f6a] border border-[#E5E1D5]/40 leading-normal">
                提示：升级为 <strong className="text-[#1A212B]">Pro 会员</strong> 后，可以导入学术高级包并解除单词上限限制！
              </div>
            </div>
          </div>

        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Main Custom Words List (8 Columns) */}
          <div className="lg:col-span-8 space-y-4">
            <div className="flex justify-between items-center border-b border-[#E5E1D5]/60 pb-2">
              <span className="font-headline text-xs font-bold text-[#1A212B]">
                我的私有生词本
              </span>
              <span className="font-mono text-[10px] text-gray-500">
                共计 {filteredCustom.length} 个
              </span>
            </div>

            {filteredCustom.length === 0 ? (
              <div className="py-16 border border-dashed border-[#E5E1D5] rounded-sm text-center text-xs text-[#585f6a] bg-[#FAF9F6]">
                这里空空如也。在左侧“官方词库”里导入，或者利用右侧表单手动录入生词！
              </div>
            ) : (
              <div className="space-y-3">
                {filteredCustom.map((item) => (
                  <div key={item.id} className="p-4 border border-[#E5E1D5] rounded-sm bg-[#FAF9F6] flex justify-between items-center hover:bg-[#F9F7F2] transition-colors">
                    <div>
                      <div className="flex items-center space-x-2">
                        <h4 className="font-headline text-sm font-bold text-[#1A212B]">{item.word}</h4>
                        <span className="font-mono text-[9px] text-[#585f6a] italic">({item.partOfSpeech}.)</span>
                      </div>
                      <p className="font-body text-xs text-[#585f6a] mt-1">{item.translation}</p>
                      <span className="font-mono text-[9px] text-gray-400 mt-1 block">
                        添加日期: {new Date(item.addedAt).toLocaleDateString()}
                      </span>
                    </div>

                    <button
                      onClick={() => onRemoveLexeme(item.id)}
                      className="p-1.5 text-red-700 hover:bg-red-50 rounded-sm transition-colors border border-transparent hover:border-red-200"
                      title="删除单词"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Add custom word Form (4 Columns) */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-4">
              <h3 className="font-headline text-sm font-bold text-[#1A212B] border-b border-[#E5E1D5] pb-2">手动创建新单词</h3>
              
              <form onSubmit={handleCreateCustomWord} className="space-y-4">
                <div className="space-y-1">
                  <label className="block font-headline text-xs font-semibold text-[#1A212B]">单词拼写 (Word)</label>
                  <input
                    type="text"
                    placeholder="e.g. Encapsulation"
                    value={newWord}
                    onChange={(e) => setNewWord(e.target.value)}
                    className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2.5 py-2 rounded-sm focus:outline-none focus:border-[#1A212B]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-headline text-xs font-semibold text-[#1A212B]">中文词性</label>
                  <select
                    value={newPos}
                    onChange={(e) => setNewPos(e.target.value)}
                    className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2 py-1.5 rounded-sm focus:outline-none focus:border-[#1A212B]"
                  >
                    <option value="noun">noun (名词)</option>
                    <option value="verb">verb (动词)</option>
                    <option value="adj">adj. (形容词)</option>
                    <option value="adv">adv. (副词)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block font-headline text-xs font-semibold text-[#1A212B]">中文释义 (Translation)</label>
                  <textarea
                    rows={2}
                    placeholder="e.g. 封装：隐藏对象的属性和实现细节"
                    value={newTranslation}
                    onChange={(e) => setNewTranslation(e.target.value)}
                    className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2.5 py-2 rounded-sm focus:outline-none focus:border-[#1A212B]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90 font-headline text-xs font-semibold rounded-sm transition-all flex items-center justify-center space-x-1"
                >
                  <Plus size={14} />
                  <span>添加至生词本</span>
                </button>
              </form>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
