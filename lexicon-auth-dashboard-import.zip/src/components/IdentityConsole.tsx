import React, { useState } from 'react';
import {
  User,
  Shield,
  Fingerprint,
  Lock,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Key,
  Clock,
  Unlock,
  Clipboard,
  Database,
  Globe,
  Plus,
  Trash2,
  Cpu,
  Server
} from 'lucide-react';
import { Profile, ApiKey } from '../types';

interface IdentityConsoleProps {
  profile: Profile;
  onSaveProfile: (newProfile: Profile) => void;
  mfaEnabled: boolean;
  setMfaEnabled: (mfa: boolean) => void;
  sessionTimeout: number;
  setSessionTimeout: (timeout: number) => void;
  apiKeys: ApiKey[];
  onGenerateKey: (name: string) => void;
  onRevokeKey: (id: string) => void;
  onLogAction: (
    title: string,
    desc: string,
    domain: 'Account & Identity' | 'Economy Center' | 'Membership Hub' | 'Lexis Core' | 'General',
    type: 'info' | 'warning' | 'error' | 'success'
  ) => void;
}

export const IdentityConsole: React.FC<IdentityConsoleProps> = ({
  profile,
  onSaveProfile,
  mfaEnabled,
  setMfaEnabled,
  sessionTimeout,
  setSessionTimeout,
  apiKeys,
  onGenerateKey,
  onRevokeKey,
  onLogAction,
}) => {
  // Local state for profile editing
  const [isEditing, setIsEditing] = useState(false);
  const [tempName, setTempName] = useState(profile.name);
  const [tempRole, setTempRole] = useState(profile.role);
  
  // Local states for simulations
  const [loginProgress, setLoginProgress] = useState<'idle' | 'checking' | 'verified'>('idle');
  const [activeStep, setActiveStep] = useState(1);
  const [showToast, setShowToast] = useState<string | null>(null);
  const [fallbackActivated, setFallbackActivated] = useState(false);
  const [backupKeysCopied, setBackupKeysCopied] = useState(false);

  // New API connection database states
  const [apiMode, setApiMode] = useState<'website' | 'custom'>('website');
  const [customApiUrl, setCustomApiUrl] = useState('https://postgres-db.cloud.net/api/v1');
  const [customApiToken, setCustomApiToken] = useState('db_token_live_a98f12c98d7f');
  const [customDbName, setCustomDbName] = useState('lexicon_production_pool');
  const [forceSsl, setForceSsl] = useState(true);
  const [testingConnection, setTestingConnection] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'success' | 'failed'>('idle');

  // API Key creation
  const [newKeyName, setNewKeyName] = useState('');

  const triggerToast = (msg: string) => {
    setShowToast(msg);
    setTimeout(() => {
      setShowToast(null);
    }, 3000);
  };

  const handleProfileSave = () => {
    onSaveProfile({
      ...profile,
      name: tempName,
      role: tempRole,
    });
    setIsEditing(false);
    triggerToast('个人基础信息更新成功');
    onLogAction(
      '账号资料已修改',
      `管理员个人资料更新：姓名 [${tempName}]，职位 [${tempRole}]`,
      'Account & Identity',
      'success'
    );
  };

  // Simulate verification and login onboarding guide
  const handleSimulateVerification = () => {
    setLoginProgress('checking');
    setActiveStep(2);
    onLogAction(
      '启动身份校验流程',
      '检测到身份校验信号，正在提取生物识别特征与安全盾证书...',
      'Account & Identity',
      'info'
    );

    setTimeout(() => {
      setActiveStep(3);
      onLogAction(
        '多因素设备验证通过',
        '安全盾物理加密芯片（YubiKey/MFA）握手成功',
        'Account & Identity',
        'info'
      );
    }, 1000);

    setTimeout(() => {
      setLoginProgress('verified');
      setActiveStep(4);
      triggerToast('身份校验与引导成功！已进入授信环境');
      onLogAction(
        '身份验证与授信引导完成',
        '身份凭证校验 100% 通过。异常兜底规则已加载，主控会话建立。',
        'Account & Identity',
        'success'
      );
    }, 2200);
  };

  const handleResetVerification = () => {
    setLoginProgress('idle');
    setActiveStep(1);
    onLogAction(
      '用户会话已注销',
      '身份会话已安全主动注销，清除当前上下文缓存',
      'Account & Identity',
      'warning'
    );
    triggerToast('当前会话已重置，等待下一次登录与引导');
  };

  const handleCopyBackupKeys = () => {
    setBackupKeysCopied(true);
    triggerToast('安全备份密钥已复制到剪贴板 (SHA-512 Hash)');
    onLogAction(
      '安全备份导出',
      '管理员执行了主备份密钥哈希导出行为，用于异常紧急恢复。',
      'Account & Identity',
      'success'
    );
    setTimeout(() => setBackupKeysCopied(false), 3000);
  };

  const handleEmergencyFallback = () => {
    setFallbackActivated(true);
    onLogAction(
      '触发紧急安全兜底机制',
      '警告：正在启动异常兜底。系统将重置所有未锁定连接，强制全域会话过期，并启用备份通道进行离线环境对账。',
      'Account & Identity',
      'error'
    );
    triggerToast('🔴 异常兜底策略已激活！全域会话已收紧防护');
    
    // Simulate recovery back to safe state after 3 seconds
    setTimeout(() => {
      setFallbackActivated(false);
      onLogAction(
        '异常兜底恢复就绪',
        '全域安全校验自动核验完毕。异常环境已自动隔离，会话正常恢复。',
        'Account & Identity',
        'success'
      );
      triggerToast('🟢 兜底核验完毕，系统恢复安全状态');
    }, 3500);
  };

  // Test custom cloud connection API
  const handleTestConnection = () => {
    setTestingConnection(true);
    setConnectionStatus('idle');
    onLogAction(
      '发起云端数据库API链路探测',
      `探测目标端点: [${customApiUrl}]，正在校验对称密钥与安全握手参数...`,
      'Account & Identity',
      'info'
    );

    setTimeout(() => {
      setTestingConnection(false);
      setConnectionStatus('success');
      triggerToast('🟢 数据库API握手成功！延迟：36ms，连接池安全');
      onLogAction(
        '数据库API连通性探测通过',
        `连接到云数据库 [${customDbName}]，握手成功。连接协议：PostgreSQL over HTTPS, SSL: ${forceSsl ? '强制启用' : '未启用'}`,
        'Account & Identity',
        'success'
      );
    }, 2000);
  };

  const handleAddKeySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyName.trim()) {
      triggerToast('请输入 API 密匙名称');
      return;
    }
    onGenerateKey(newKeyName.trim());
    triggerToast(`🔑 API 密匙 [${newKeyName}] 创建成功`);
    setNewKeyName('');
  };

  return (
    <div className="space-y-8 max-w-[1280px] mx-auto animate-fadeIn relative pb-12">
      {/* Toast Notification */}
      {showToast && (
        <div className="fixed bottom-6 right-6 bg-[#1A212B] text-[#FAF9F6] border border-[#E5E1D5]/20 font-headline text-xs py-3 px-5 rounded-sm shadow-xl z-50 flex items-center space-x-2 animate-fadeIn">
          <CheckCircle2 size={14} className="text-emerald-400" />
          <span>{showToast}</span>
        </div>
      )}

      {/* Header Title Section */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-[#E5E1D5] pb-6">
        <div>
          <div className="flex items-center space-x-2.5">
            <h2 className="font-headline text-3xl font-semibold tracking-tight text-[#1A212B]">
              账号身份域
            </h2>
            <span className="px-2 py-0.5 bg-[#1A212B] text-[10px] font-headline font-semibold text-[#FAF9F6] rounded-sm tracking-wider">
              DOMAIN-IDENTITY
            </span>
          </div>
          <p className="font-label text-sm text-[#585f6a] mt-2">
            负责全域用户身份校验、账号资料合规、云端API/数据库连接控制、高安全等级备份以及突发异常状态兜底恢复
          </p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center space-x-2 text-[#585f6a] bg-[#E5E1D5]/40 px-3 py-1.5 rounded-sm border border-[#E5E1D5]/60">
          <Shield size={14} className="text-[#1A212B]" />
          <span className="font-mono text-xs font-semibold">STATUS: SECURE_SHIELD</span>
        </div>
      </header>

      {/* Bento Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: LOGIN & ONBOARDING GUIDE (7 Columns) */}
        <div className="lg:col-span-7 space-y-6">
          {/* 登录与身份引导 */}
          <section className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-5">
            <div className="flex justify-between items-start border-b border-[#E5E1D5]/60 pb-3">
              <div>
                <h3 className="font-headline text-base font-semibold text-[#1A212B]">
                  登录与身份引导
                </h3>
                <p className="font-body text-xs text-[#585f6a] mt-0.5">
                  全自动高安全校验工作流：执行系统身份认证及首次接入策略
                </p>
              </div>
              <Fingerprint size={20} className="text-[#1A212B]" />
            </div>

            {/* Interactive Stepper Guide */}
            <div className="space-y-4">
              <span className="block font-headline text-xs font-semibold text-[#1A212B] uppercase tracking-wider">
                身份验证引导路径 (错误与引导)
              </span>
              <div className="grid grid-cols-4 gap-2 relative">
                {/* Step 1 */}
                <div className={`p-3 rounded-sm border text-center transition-all ${
                  activeStep >= 1 ? 'border-[#1A212B] bg-[#E5E1D5]/20' : 'border-[#E5E1D5] bg-transparent opacity-50'
                }`}>
                  <div className="font-mono text-[10px] font-semibold text-[#585f6a]">STEP 01</div>
                  <div className="font-headline text-xs font-bold text-[#1A212B] mt-1">基础注册</div>
                  <div className="font-body text-[9px] text-[#585f6a] mt-0.5 hidden sm:block">凭证匹配</div>
                </div>

                {/* Step 2 */}
                <div className={`p-3 rounded-sm border text-center transition-all ${
                  activeStep >= 2 ? 'border-[#1A212B] bg-[#E5E1D5]/20' : 'border-[#E5E1D5] bg-transparent opacity-50'
                }`}>
                  <div className="font-mono text-[10px] font-semibold text-[#585f6a]">STEP 02</div>
                  <div className="font-headline text-xs font-bold text-[#1A212B] mt-1">特征绑定</div>
                  <div className="font-body text-[9px] text-[#585f6a] mt-0.5 hidden sm:block">生物硬核对接</div>
                </div>

                {/* Step 3 */}
                <div className={`p-3 rounded-sm border text-center transition-all ${
                  activeStep >= 3 ? 'border-[#1A212B] bg-[#E5E1D5]/20' : 'border-[#E5E1D5] bg-transparent opacity-50'
                }`}>
                  <div className="font-mono text-[10px] font-semibold text-[#585f6a]">STEP 03</div>
                  <div className="font-headline text-xs font-bold text-[#1A212B] mt-1">多级授信</div>
                  <div className="font-body text-[9px] text-[#585f6a] mt-0.5 hidden sm:block">MFA策略验证</div>
                </div>

                {/* Step 4 */}
                <div className={`p-3 rounded-sm border text-center transition-all ${
                  activeStep >= 4 ? 'border-[#1A212B] bg-[#E5E1D5]/20' : 'border-[#E5E1D5] bg-transparent opacity-50'
                }`}>
                  <div className="font-mono text-[10px] font-semibold text-[#585f6a]">STEP 04</div>
                  <div className="font-headline text-xs font-bold text-[#1A212B] mt-1">全域放行</div>
                  <div className="font-body text-[9px] text-[#585f6a] mt-0.5 hidden sm:block">兜底激活</div>
                </div>
              </div>
            </div>

            {/* Simulated Live Action Terminal */}
            <div className="bg-[#1A212B] text-[#FAF9F6] p-4 rounded-sm font-mono text-xs space-y-2.5">
              <div className="flex justify-between items-center text-gray-400 border-b border-gray-800 pb-1.5 mb-1.5">
                <span>IDENTITY VALIDATOR SHIELD v1.2</span>
                <span className="flex items-center space-x-1.5">
                  <span className={`w-2 h-2 rounded-full ${loginProgress === 'checking' ? 'bg-amber-500 animate-ping' : loginProgress === 'verified' ? 'bg-emerald-500' : 'bg-gray-600'}`} />
                  <span className="text-[10px] uppercase">{loginProgress}</span>
                </span>
              </div>
              
              {loginProgress === 'idle' && (
                <div className="py-2 text-center text-gray-400">
                  <p>🔴 当前未建立授信校验会话</p>
                  <p className="text-[10px] mt-1">点击下方按钮执行系统登录与环境引导测试</p>
                </div>
              )}

              {loginProgress === 'checking' && (
                <div className="space-y-1">
                  <p className="text-amber-400 flex items-center space-x-1.5">
                    <RefreshCw size={12} className="animate-spin" />
                    <span>[RUNNING] Checking local biometric metadata payload...</span>
                  </p>
                  <p className="text-gray-400">⚡ Decrypting private keys with local security chip...</p>
                  <p className="text-gray-400">⏳ Waiting for Multi-factor (MFA) token handshake confirmation...</p>
                </div>
              )}

              {loginProgress === 'verified' && (
                <div className="space-y-1">
                  <p className="text-emerald-400">✔ [SUCCESS] Credential validation: 100% matched.</p>
                  <p className="text-gray-300">✔ Multi-Factor Access: Authorized.</p>
                  <p className="text-gray-300">✔ Session Active: TTL {sessionTimeout} minutes.</p>
                  <p className="text-gray-400">👉 Local admin initialized: {profile.name} ({profile.role})</p>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex items-center space-x-3 pt-2">
              {loginProgress !== 'checking' && (
                <button
                  onClick={loginProgress === 'verified' ? handleResetVerification : handleSimulateVerification}
                  className={`flex-1 flex items-center justify-center space-x-2 py-2.5 px-4 rounded-sm font-headline text-xs font-semibold transition-all shadow-sm ${
                    loginProgress === 'verified'
                      ? 'bg-transparent text-[#1A212B] border border-[#1A212B] hover:bg-[#1A212B]/5'
                      : 'bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90'
                  }`}
                >
                  {loginProgress === 'verified' ? (
                    <>
                      <Unlock size={14} />
                      <span>重置会话与引导 (Reset Session)</span>
                    </>
                  ) : (
                    <>
                      <Fingerprint size={14} />
                      <span>立即执行身份校验与引导</span>
                    </>
                  )}
                </button>
              )}
              {loginProgress === 'checking' && (
                <div className="flex-1 text-center py-2.5 text-xs font-headline font-semibold text-[#585f6a] bg-[#E5E1D5]/40 rounded-sm animate-pulse">
                  正在进行身份双重认证，请在硬件上确认...
                </div>
              )}
            </div>
          </section>

          {/* Database API Connection Mode (Selected connection model entry point) */}
          <section className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-5">
            <div className="flex justify-between items-start border-b border-[#E5E1D5]/60 pb-3">
              <div>
                <h3 className="font-headline text-base font-semibold text-[#1A212B]">
                  云端对账数据库 API 连通配置
                </h3>
                <p className="font-body text-xs text-[#585f6a] mt-0.5">
                  显示当前系统所用API端点并决定是否桥接到自定义物理 SQL 关系型数据库 API
                </p>
              </div>
              <Database size={20} className="text-[#1A212B]" />
            </div>

            {/* API SELECTOR: WEBSITE OR CUSTOM */}
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="block font-headline text-xs font-bold text-[#1A212B]">
                  选择当前的对账 API 通信通道 (当前使用: {apiMode === 'website' ? '官方内建 API' : '自定义云端 API'})
                </label>
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <button
                    onClick={() => {
                      setApiMode('website');
                      onLogAction(
                        '通信通道切换: 官方默认 API',
                        '全局数据接口迁移至官方默认本地 Mock 数据中控台，延迟：<1ms',
                        'Account & Identity',
                        'info'
                      );
                      triggerToast('已切换至系统官方 API 默认端点');
                    }}
                    className={`p-3 border text-left rounded-sm transition-all ${
                      apiMode === 'website'
                        ? 'border-[#1A212B] bg-[#E5E1D5]/20 font-semibold'
                        : 'border-[#E5E1D5] bg-transparent text-[#585f6a] hover:bg-[#E5E1D5]/10'
                    }`}
                  >
                    <div className="flex items-center space-x-1.5">
                      <Globe size={13} />
                      <span className="font-headline text-xs">系统默认 API</span>
                    </div>
                    <span className="block font-body text-[10px] text-gray-500 mt-1">
                      https://lexicon.auth.api/local
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      setApiMode('custom');
                      onLogAction(
                        '通信通道切换: 自定义云数据库 API',
                        '激活自定义云数据库接口连通面板，准备接入手动配置的 PostgreSQL/SQL 数据库端点',
                        'Account & Identity',
                        'warning'
                      );
                      triggerToast('已切换至自定义云数据库接口连通模式');
                    }}
                    className={`p-3 border text-left rounded-sm transition-all ${
                      apiMode === 'custom'
                        ? 'border-[#1A212B] bg-[#E5E1D5]/20 font-semibold'
                        : 'border-[#E5E1D5] bg-transparent text-[#585f6a] hover:bg-[#E5E1D5]/10'
                    }`}
                  >
                    <div className="flex items-center space-x-1.5">
                      <Server size={13} />
                      <span className="font-headline text-xs">自定义云端 API</span>
                    </div>
                    <span className="block font-body text-[10px] text-gray-500 mt-1 text-ellipsis overflow-hidden">
                      {customApiUrl}
                    </span>
                  </button>
                </div>
              </div>

              {/* CUSTOM API INPUTS */}
              {apiMode === 'custom' && (
                <div className="space-y-3 p-4 bg-[#E5E1D5]/20 border border-[#E5E1D5]/60 rounded-sm animate-fadeIn">
                  <span className="block font-headline text-xs font-bold text-[#1A212B] uppercase tracking-wider mb-2">
                    自定义云关系型数据库(Cloud SQL)连接模型参数
                  </span>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="block font-headline text-[11px] font-semibold text-[#1A212B]">API Gateway 端点 URL</label>
                      <input
                        type="text"
                        value={customApiUrl}
                        onChange={(e) => setCustomApiUrl(e.target.value)}
                        className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-mono text-xs px-2.5 py-1.5 rounded-sm focus:outline-none focus:border-[#1A212B]"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block font-headline text-[11px] font-semibold text-[#1A212B]">安全握手凭证 (Secret Key)</label>
                      <input
                        type="password"
                        value={customApiToken}
                        onChange={(e) => setCustomApiToken(e.target.value)}
                        className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-mono text-xs px-2.5 py-1.5 rounded-sm focus:outline-none focus:border-[#1A212B]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                    <div className="space-y-1">
                      <label className="block font-headline text-[11px] font-semibold text-[#1A212B]">目标物理数据库名称 (Database)</label>
                      <input
                        type="text"
                        value={customDbName}
                        onChange={(e) => setCustomDbName(e.target.value)}
                        className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-mono text-xs px-2.5 py-1.5 rounded-sm focus:outline-none focus:border-[#1A212B]"
                      />
                    </div>

                    <div className="flex items-center justify-between pt-5">
                      <span className="font-headline text-[11px] font-semibold text-[#1A212B]">强制 SSL 安全加密</span>
                      <button
                        onClick={() => setForceSsl(!forceSsl)}
                        className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          forceSsl ? 'bg-[#1A212B]' : 'bg-[#E5E1D5]'
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                            forceSsl ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>
                  </div>

                  {/* Actions connection buttons */}
                  <div className="flex items-center space-x-3 pt-3 border-t border-[#E5E1D5]/50 mt-2">
                    <button
                      disabled={testingConnection}
                      onClick={handleTestConnection}
                      className="flex-1 py-2 bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90 font-headline text-xs font-semibold rounded-sm flex items-center justify-center space-x-1.5 disabled:opacity-50"
                    >
                      {testingConnection ? (
                        <>
                          <RefreshCw size={12} className="animate-spin" />
                          <span>正在执行通信对账探测...</span>
                        </>
                      ) : (
                        <>
                          <Server size={12} />
                          <span>测试云数据库端点连通性</span>
                        </>
                      )}
                    </button>

                    {connectionStatus === 'success' && (
                      <span className="text-xs font-headline font-bold text-emerald-700 bg-emerald-50 px-2 py-2 border border-emerald-100 rounded-sm">
                        ✔ 校验匹配通过 (36ms)
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>
          </section>

          {/* 异常兜底与安全备份 */}
          <section className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-6">
            <div>
              <h3 className="font-headline text-base font-semibold text-[#1A212B]">
                安全备份与异常兜底
              </h3>
              <p className="font-body text-xs text-[#585f6a] mt-0.5">
                防止异常入侵、误操作，并提供灾备及秒级应急恢复方案
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Security Backup */}
              <div className="p-4 rounded-sm border border-[#E5E1D5] bg-transparent space-y-3">
                <div className="flex items-center space-x-2">
                  <Key size={16} className="text-[#1A212B]" />
                  <span className="font-headline text-xs font-bold text-[#1A212B]">
                    全域安全密匙备份
                  </span>
                </div>
                <p className="font-body text-[11px] text-[#585f6a] leading-relaxed">
                  一键备份全域凭证元数据与安全因子，供灾备时离线验证与异常重设。
                </p>
                <button
                  onClick={handleCopyBackupKeys}
                  className="w-full flex items-center justify-center space-x-1.5 py-1.5 px-3 border border-[#1A212B] text-[#1A212B] bg-transparent hover:bg-[#1A212B]/5 font-headline text-[11px] font-semibold rounded-sm transition-all"
                >
                  <Clipboard size={12} />
                  <span>{backupKeysCopied ? '已成功复制' : '复制安全备份密钥'}</span>
                </button>
              </div>

              {/* Exception Fallback */}
              <div className={`p-4 rounded-sm border transition-all space-y-3 ${
                fallbackActivated 
                  ? 'border-[#ba1a1a] bg-[#ba1a1a]/5' 
                  : 'border-[#E5E1D5] bg-transparent'
              }`}>
                <div className="flex items-center space-x-2">
                  <AlertTriangle size={16} className={fallbackActivated ? 'text-[#ba1a1a] animate-pulse' : 'text-[#1A212B]'} />
                  <span className="font-headline text-xs font-bold text-[#1A212B]">
                    极速异常保护兜底
                  </span>
                </div>
                <p className="font-body text-[11px] text-[#585f6a] leading-relaxed">
                  若会话异常泄露或遭受暴破，瞬间锁定账号状态，并安全回滚备份上下文。
                </p>
                <button
                  onClick={handleEmergencyFallback}
                  disabled={fallbackActivated}
                  className={`w-full flex items-center justify-center space-x-1.5 py-1.5 px-3 font-headline text-[11px] font-semibold rounded-sm transition-all ${
                    fallbackActivated 
                      ? 'bg-[#ba1a1a] text-[#FAF9F6] cursor-not-allowed'
                      : 'bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90'
                  }`}
                >
                  <Shield size={12} />
                  <span>{fallbackActivated ? '正在紧急兜底恢复中...' : '激活异常兜底机制'}</span>
                </button>
              </div>
            </div>
          </section>
        </div>

        {/* RIGHT COLUMN: ACCOUNT INFORMATION & PARAMETERS (5 Columns) */}
        <div className="lg:col-span-5 space-y-6">
          {/* 个人基础信息 */}
          <section className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-5">
            <div className="flex justify-between items-start border-b border-[#E5E1D5]/60 pb-3">
              <div>
                <h3 className="font-headline text-base font-semibold text-[#1A212B]">
                  个人设置 (基础信息)
                </h3>
                <p className="font-body text-xs text-[#585f6a] mt-0.5">
                  查看及编辑当前管理节点的账号身份标识与角色设定
                </p>
              </div>
              <User size={20} className="text-[#1A212B]" />
            </div>

            {/* Profile Card UI */}
            <div className="flex items-center space-x-4 p-4 bg-[#E5E1D5]/20 rounded-sm border border-[#E5E1D5]/40">
              <img
                src={profile.avatar}
                alt={profile.name}
                className="w-14 h-14 rounded-full border border-[#E5E1D5] p-0.5 bg-white"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0">
                <h4 className="font-headline text-sm font-semibold text-[#1A212B] truncate">
                  {profile.name}
                </h4>
                <p className="font-label text-xs text-[#585f6a] mt-0.5 truncate">
                  {profile.role}
                </p>
                <span className="inline-flex items-center space-x-1 mt-2 text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
                  <span>已验证所有权</span>
                </span>
              </div>
            </div>

            {/* Inline Editing Form */}
            {isEditing ? (
              <div className="space-y-3.5 pt-2 animate-fadeIn">
                <div className="space-y-1">
                  <label className="block font-headline text-xs font-semibold text-[#1A212B]">
                    姓名 (Account Owner)
                  </label>
                  <input
                    type="text"
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2.5 py-2 rounded-sm focus:outline-none focus:border-[#1A212B]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block font-headline text-xs font-semibold text-[#1A212B]">
                    管理职位 (Administrative Role)
                  </label>
                  <input
                    type="text"
                    value={tempRole}
                    onChange={(e) => setTempRole(e.target.value)}
                    className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2.5 py-2 rounded-sm focus:outline-none focus:border-[#1A212B]"
                  />
                </div>
                <div className="flex space-x-2 pt-2">
                  <button
                    onClick={handleProfileSave}
                    className="flex-1 py-1.5 bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90 font-headline text-xs font-semibold rounded-sm transition-all"
                  >
                    保存更新
                  </button>
                  <button
                    onClick={() => {
                      setTempName(profile.name);
                      setTempRole(profile.role);
                      setIsEditing(false);
                    }}
                    className="flex-1 py-1.5 border border-[#E5E1D5] text-[#585f6a] hover:bg-black/5 font-headline text-xs font-semibold rounded-sm transition-all"
                  >
                    取消
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3 pt-2">
                <div className="flex justify-between text-xs border-b border-[#E5E1D5]/40 pb-2">
                  <span className="font-headline text-[#585f6a]">用户唯一标识码:</span>
                  <span className="font-mono text-[#1A212B] font-semibold">UID-2092-ALPHA</span>
                </div>
                <div className="flex justify-between text-xs border-b border-[#E5E1D5]/40 pb-2">
                  <span className="font-headline text-[#585f6a]">授信校验状态:</span>
                  <span className="font-headline text-emerald-700 font-semibold">MFA HARDWARE PASS</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="font-headline text-[#585f6a]">最近会话握手:</span>
                  <span className="font-body text-[#585f6a] flex items-center space-x-1">
                    <Clock size={12} />
                    <span>刚刚已通过物理安全盾校验</span>
                  </span>
                </div>
                <button
                  onClick={() => setIsEditing(true)}
                  className="w-full mt-3 py-2 border border-[#1A212B] text-[#1A212B] bg-transparent hover:bg-[#1A212B]/5 font-headline text-xs font-semibold rounded-sm transition-all"
                >
                  修改个人基础信息
                </button>
              </div>
            )}
          </section>

          {/* API 密钥管理 (Credentials Vault integrated inside domain layout) */}
          <section className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-4">
            <div className="flex justify-between items-start border-b border-[#E5E1D5]/60 pb-3">
              <div>
                <h3 className="font-headline text-base font-semibold text-[#1A212B]">
                  API 密钥管理
                </h3>
                <p className="font-body text-xs text-[#585f6a] mt-0.5">
                  生成、查验并吊销提供外部对接的会话鉴权 Tokens
                </p>
              </div>
              <Key size={20} className="text-[#1A212B]" />
            </div>

            {/* List */}
            <div className="space-y-3 max-h-48 overflow-y-auto custom-scrollbar">
              {apiKeys.length === 0 ? (
                <div className="py-6 text-center text-xs font-body text-gray-400">
                  暂无生成 API 凭证
                </div>
              ) : (
                apiKeys.map((key) => (
                  <div key={key.id} className="p-3 bg-[#E5E1D5]/10 border border-[#E5E1D5]/40 rounded-sm flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <span className="font-headline text-xs font-bold text-[#1A212B] block truncate">{key.name}</span>
                      <span className="font-mono text-[10px] text-[#585f6a] block select-all mt-0.5">{key.key}</span>
                    </div>
                    <button
                      onClick={() => {
                        onRevokeKey(key.id);
                        triggerToast(`已成功注销凭证 [${key.name}]`);
                      }}
                      className="text-[#ba1a1a] hover:bg-red-50 p-1.5 rounded-sm transition-colors shrink-0"
                      title="吊销凭证"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* Generate form */}
            <form onSubmit={handleAddKeySubmit} className="space-y-2 pt-2 border-t border-[#E5E1D5]/40">
              <input
                type="text"
                placeholder="密匙对接标识名称 (如: iOS App Client)"
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
                className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-body text-[11px] px-2 py-1.5 rounded-sm focus:outline-none focus:border-[#1A212B]"
              />
              <button
                type="submit"
                className="w-full py-1.5 bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90 font-headline text-[11px] font-semibold rounded-sm flex items-center justify-center space-x-1.5"
              >
                <Plus size={11} />
                <span>生成新的 API 会话密匙</span>
              </button>
            </form>
          </section>

          {/* 账号安全参数 */}
          <section className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-5">
            <div className="flex justify-between items-start border-b border-[#E5E1D5]/60 pb-3">
              <div>
                <h3 className="font-headline text-base font-semibold text-[#1A212B]">
                  账号安全参数
                </h3>
                <p className="font-body text-xs text-[#585f6a] mt-0.5">
                  精细化控制身份校验强度与会话生命周期
                </p>
              </div>
              <Lock size={20} className="text-[#1A212B]" />
            </div>

            <div className="space-y-4">
              {/* MFA Switch */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="block font-headline text-xs font-bold text-[#1A212B]">
                    强校验多因素认证 (MFA)
                  </span>
                  <p className="font-body text-[10px] text-[#585f6a] mt-0.5">
                    进行管理员会话及敏感配置修改时强制验证
                  </p>
                </div>
                <button
                  onClick={() => {
                    const nextMfa = !mfaEnabled;
                    setMfaEnabled(nextMfa);
                    onLogAction(
                      nextMfa ? '强制全域MFA校验已启用' : '全域MFA策略已被放宽',
                      `多因素硬件验证条件变更为：${nextMfa ? '强制执行' : '可选择性跳过'}`,
                      'Account & Identity',
                      nextMfa ? 'success' : 'warning'
                    );
                    triggerToast(nextMfa ? '双因素验证规则已启用' : '双因素验证规则已暂时放宽');
                  }}
                  className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    mfaEnabled ? 'bg-[#1A212B]' : 'bg-[#E5E1D5]'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                      mfaEnabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Timeout selection */}
              <div className="space-y-1.5 pt-3 border-t border-[#E5E1D5]/40">
                <label className="block font-headline text-xs font-bold text-[#1A212B]">
                  账号安全会话生命周期
                </label>
                <select
                  value={sessionTimeout}
                  onChange={(e) => {
                    const nextTimeout = Number(e.target.value);
                    setSessionTimeout(nextTimeout);
                    onLogAction(
                      '会话生命周期策略调整',
                      `账号最长空闲保持周期被调整为 ${nextTimeout} 分钟`,
                      'Account & Identity',
                      'info'
                    );
                    triggerToast(`会话自动注销周期已更新为 ${nextTimeout} 分钟`);
                  }}
                  className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2 py-1.5 rounded-sm focus:outline-none focus:border-[#1A212B]"
                >
                  <option value={15}>15 分钟 (高安全防护)</option>
                  <option value={30}>30 分钟 (建议参数)</option>
                  <option value={60}>60 分钟 (标准参数)</option>
                  <option value={120}>120 分钟 (长期保存)</option>
                </select>
                <p className="font-body text-[10px] text-[#585f6a] leading-normal">
                  未产生交互操作时，在空闲达到该时长后将自动激活兜底策略注销并锁定。
                </p>
              </div>
            </div>
          </section>
        </div>

      </div>
    </div>
  );
};
