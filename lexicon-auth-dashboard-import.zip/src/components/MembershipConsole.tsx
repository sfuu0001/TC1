import React, { useState } from 'react';
import {
  Award,
  Crown,
  Sparkles,
  Check,
  Zap,
  Globe,
  Database,
  ArrowRight,
  ShieldCheck,
  HelpCircle,
  FileDown
} from 'lucide-react';
import { SystemEvent } from '../types';

interface MembershipConsoleProps {
  membershipTier: string;
  setMembershipTier: (tier: string) => void;
  creditBalance: number;
  onTransaction: (amount: number, reason: string) => void;
  onLogAction: (
    title: string,
    desc: string,
    domain: 'Account & Identity' | 'Economy Center' | 'Membership Hub' | 'Lexis Core' | 'General',
    type: 'info' | 'warning' | 'error' | 'success'
  ) => void;
}

export const MembershipConsole: React.FC<MembershipConsoleProps> = ({
  membershipTier,
  setMembershipTier,
  creditBalance,
  onTransaction,
  onLogAction,
}) => {
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  
  // Custom addon-service states (simulated purchases)
  const [addons, setAddons] = useState({
    aiTranslator: false,
    greVocab: false,
    dedicatedTunnel: false,
  });

  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const buyMembership = (tierName: string, cost: number) => {
    if (membershipTier === tierName) {
      triggerToast(`您当前已经是 ${tierName} 会员，无需重复订阅`);
      return;
    }

    if (creditBalance < cost) {
      triggerToast(`❌ 订阅失败：积分不足，订阅 ${tierName} 需要 ${cost} 积分`);
      onLogAction(
        '会员订阅失败',
        `试图订阅 [${tierName}] 会员，当前积分余额为 ${creditBalance} CRD，缺口 ${cost - creditBalance} CRD`,
        'Membership Hub',
        'error'
      );
      return;
    }

    // Spend credits and update tier
    onTransaction(-cost, `订阅升级会员等级 [${tierName}]`);
    setMembershipTier(tierName);
    triggerToast(`🎉 恭喜！成功升级为 ${tierName} 会员！已享受全部专属特权`);
    onLogAction(
      '会员成功升级',
      `使用 ${cost} 积分成功解锁并升级为 [${tierName}] 会员，特权即刻生效。`,
      'Membership Hub',
      'success'
    );
  };

  const toggleAddon = (addonKey: 'aiTranslator' | 'greVocab' | 'dedicatedTunnel', cost: number, addonName: string) => {
    if (addons[addonKey]) {
      triggerToast(`您已激活 ${addonName}，不可重复购买`);
      return;
    }

    // Ultimate member gets them all for free!
    if (membershipTier === 'Ultimate') {
      setAddons(prev => ({ ...prev, [addonKey]: true }));
      triggerToast(`✨ [Ultimate 会员专属] 免费解锁 ${addonName}！`);
      onLogAction(
        '免费解锁增值特权',
        `Ultimate 黄金席位特权：直接免费授权启用增值附加服务: [${addonName}]`,
        'Membership Hub',
        'success'
      );
      return;
    }

    if (creditBalance < cost) {
      triggerToast(`❌ 积分不足：购买该增值功能需要 ${cost} 积分`);
      return;
    }

    onTransaction(-cost, `付费解锁增值功能 [${addonName}]`);
    setAddons(prev => ({ ...prev, [addonKey]: true }));
    triggerToast(`🚀 已扣除 ${cost} 积分，成功开通并启用 ${addonName}！`);
    onLogAction(
      '增值功能付费解锁',
      `花费 ${cost} 积分，成功激活 [${addonName}]，已成功集成并分发访问凭证。`,
      'Membership Hub',
      'success'
    );
  };

  return (
    <div className="space-y-8 max-w-[1280px] mx-auto animate-fadeIn relative pb-12">
      {/* Toast popup */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 bg-[#1A212B] text-[#FAF9F6] border border-[#E5E1D5]/20 font-headline text-xs py-3 px-5 rounded-sm shadow-xl z-50 flex items-center space-x-2 animate-fadeIn">
          <Crown size={14} className="text-yellow-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-[#E5E1D5] pb-6">
        <div>
          <div className="flex items-center space-x-2.5">
            <h2 className="font-headline text-3xl font-semibold tracking-tight text-[#1A212B]">
              会员增值域
            </h2>
            <span className="px-2 py-0.5 bg-[#1A212B] text-[10px] font-headline font-semibold text-[#FAF9F6] rounded-sm tracking-wider">
              DOMAIN-MEMBERSHIP
            </span>
          </div>
          <p className="font-label text-sm text-[#585f6a] mt-2">
            提供会员等级付费订阅、高阶特权解锁以及增值API通道精细化管控，完美支持业务权限全链路闭环
          </p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center space-x-2 text-[#1A212B] bg-[#E5E1D5]/40 px-3 py-1.5 rounded-sm border border-[#E5E1D5]/60">
          <Crown size={14} className="text-[#1A212B] animate-pulse" />
          <span className="font-mono text-xs font-semibold">当前等级: {membershipTier}</span>
        </div>
      </header>

      {/* Membership Tiers Selector Card Board */}
      <section className="space-y-4">
        <h3 className="font-headline text-base font-semibold text-[#1A212B] uppercase tracking-wider">
          会员等级订阅中心
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Plan 1: Free */}
          <div className={`bento-card p-6 rounded-md border flex flex-col justify-between ${
            membershipTier === 'Free' || membershipTier === 'Developer'
              ? 'border-[#1A212B] bg-[#E5E1D5]/10 shadow-sm relative'
              : 'border-[#E5E1D5] bg-[#FAF9F6]'
          }`}>
            {membershipTier === 'Free' && (
              <span className="absolute -top-2.5 right-4 bg-[#1A212B] text-[#FAF9F6] text-[9px] font-mono px-2 py-0.5 rounded-sm">
                当前订阅
              </span>
            )}
            <div className="space-y-4">
              <div>
                <span className="font-mono text-[10px] font-bold text-[#585f6a] uppercase">LEVEL 01</span>
                <h4 className="font-headline text-xl font-bold text-[#1A212B] mt-1">标准基础版 (Free)</h4>
                <p className="font-body text-xs text-[#585f6a] mt-1">适用于入门及基础单词库查询与简易私有收藏</p>
              </div>

              <div className="border-t border-b border-[#E5E1D5]/60 py-3 space-y-2">
                <div className="flex items-center space-x-2 text-xs text-[#1A212B]">
                  <Check size={14} className="text-emerald-700 shrink-0" />
                  <span>官方单词库查询：标准速度</span>
                </div>
                <div className="flex items-center space-x-2 text-xs text-[#1A212B]">
                  <Check size={14} className="text-emerald-700 shrink-0" />
                  <span>私有自定义词库：最大 10 词</span>
                </div>
                <div className="flex items-center space-x-2 text-xs text-[#585f6a] opacity-50">
                  <Check size={14} className="shrink-0" />
                  <span>高级增值词库解锁：不可用</span>
                </div>
              </div>
            </div>

            <div className="pt-6">
              <button
                disabled={membershipTier === 'Free' || membershipTier === 'Developer'}
                onClick={() => {
                  setMembershipTier('Free');
                  triggerToast('已切换至标准基础版');
                }}
                className="w-full py-2.5 rounded-sm font-headline text-xs font-semibold border border-[#E5E1D5] text-[#585f6a] bg-transparent hover:bg-[#1A212B]/5 transition-all"
              >
                {membershipTier === 'Free' || membershipTier === 'Developer' ? '当前正在使用' : '切换回基础版'}
              </button>
            </div>
          </div>

          {/* Plan 2: Pro */}
          <div className={`bento-card p-6 rounded-md border flex flex-col justify-between ${
            membershipTier === 'Pro'
              ? 'border-[#1A212B] bg-[#E5E1D5]/15 shadow-md relative'
              : 'border-[#E5E1D5] bg-[#FAF9F6]'
          }`}>
            {membershipTier === 'Pro' && (
              <span className="absolute -top-2.5 right-4 bg-[#1A212B] text-[#FAF9F6] text-[9px] font-mono px-2 py-0.5 rounded-sm">
                当前订阅
              </span>
            )}
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center">
                  <span className="font-mono text-[10px] font-bold text-[#585f6a] uppercase">LEVEL 02</span>
                  <span className="text-[10px] px-2 py-0.5 bg-[#1A212B] text-[#FAF9F6] font-semibold rounded-sm">推荐</span>
                </div>
                <h4 className="font-headline text-xl font-bold text-[#1A212B] mt-1">专业极速版 (Pro)</h4>
                <p className="font-body text-xs text-[#585f6a] mt-1">适用于高阶学者及开发者，解除词汇存储与频控限制</p>
              </div>

              <div className="border-t border-b border-[#E5E1D5]/60 py-3 space-y-2">
                <div className="flex items-center space-x-2 text-xs text-[#1A212B]">
                  <Check size={14} className="text-emerald-700 shrink-0" />
                  <span>官方单词库查询：双倍极速</span>
                </div>
                <div className="flex items-center space-x-2 text-xs text-[#1A212B]">
                  <Check size={14} className="text-emerald-700 shrink-0" />
                  <span>私有自定义词库：存储无限</span>
                </div>
                <div className="flex items-center space-x-2 text-xs text-[#1A212B]">
                  <Check size={14} className="text-emerald-700 shrink-0" />
                  <span>支持多级API Key凭证定制</span>
                </div>
              </div>
            </div>

            <div className="pt-6 space-y-2">
              <div className="text-center font-mono text-xs font-bold text-[#1A212B]">300 积分 (CRD) / 月</div>
              <button
                onClick={() => buyMembership('Pro', 300)}
                className={`w-full py-2.5 rounded-sm font-headline text-xs font-semibold transition-all ${
                  membershipTier === 'Pro'
                    ? 'bg-[#E5E1D5] text-[#585f6a] border border-[#E5E1D5] cursor-default'
                    : 'bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90'
                }`}
              >
                {membershipTier === 'Pro' ? '专业版已开通' : '积分安全购买 (300 pts)'}
              </button>
            </div>
          </div>

          {/* Plan 3: Ultimate */}
          <div className={`bento-card p-6 rounded-md border flex flex-col justify-between ${
            membershipTier === 'Ultimate'
              ? 'border-[#1A212B] bg-[#E5E1D5]/15 shadow-md relative animate-pulse'
              : 'border-[#E5E1D5] bg-[#FAF9F6]'
          }`}>
            {membershipTier === 'Ultimate' && (
              <span className="absolute -top-2.5 right-4 bg-yellow-600 text-[#FAF9F6] text-[9px] font-mono px-2 py-0.5 rounded-sm">
                尊贵黄金席
              </span>
            )}
            <div className="space-y-4">
              <div>
                <span className="font-mono text-[10px] font-bold text-yellow-700 uppercase">LEVEL 03</span>
                <h4 className="font-headline text-xl font-bold text-[#1A212B] mt-1">旗舰至尊版 (Ultimate)</h4>
                <p className="font-body text-xs text-[#585f6a] mt-1">顶级物理计算资源保障，全面解锁高阶人工智能特权</p>
              </div>

              <div className="border-t border-b border-[#E5E1D5]/60 py-3 space-y-2">
                <div className="flex items-center space-x-2 text-xs text-[#1A212B]">
                  <Check size={14} className="text-emerald-700 shrink-0" />
                  <span>独立专用专属云端计算节点</span>
                </div>
                <div className="flex items-center space-x-2 text-xs text-[#1A212B]">
                  <Check size={14} className="text-emerald-700 shrink-0" />
                  <span>免扣积分：所有增值服务全免费</span>
                </div>
                <div className="flex items-center space-x-2 text-xs text-[#1A212B]">
                  <Check size={14} className="text-emerald-700 shrink-0" />
                  <span>突发异常秒级兜底专属支持通道</span>
                </div>
              </div>
            </div>

            <div className="pt-6 space-y-2">
              <div className="text-center font-mono text-xs font-bold text-yellow-700">600 积分 (CRD) / 月</div>
              <button
                onClick={() => buyMembership('Ultimate', 600)}
                className={`w-full py-2.5 rounded-sm font-headline text-xs font-semibold transition-all ${
                  membershipTier === 'Ultimate'
                    ? 'bg-yellow-600 text-[#FAF9F6] border border-yellow-600 cursor-default'
                    : 'bg-gradient-to-r from-amber-600 to-yellow-600 text-white hover:opacity-95'
                }`}
              >
                {membershipTier === 'Ultimate' ? '旗舰至尊已开通' : '积分豪华升级 (600 pts)'}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 增值服务 - 付费解锁增值功能 */}
      <section className="space-y-4">
        <h3 className="font-headline text-base font-semibold text-[#1A212B] uppercase tracking-wider">
          付费解锁增值服务
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Addon 1 */}
          <div className="bento-card p-5 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Globe size={20} className="text-[#1A212B]" />
                <span className="font-mono text-[10px] text-[#585f6a] font-bold">ADDON_01</span>
              </div>
              <h4 className="font-headline text-sm font-semibold text-[#1A212B]">全自动AI单词翻译引擎</h4>
              <p className="font-body text-xs text-[#585f6a] leading-normal">
                一键接入大语言模型，极速翻译生僻短语、生成词根词缀助记，多维度解析。
              </p>
            </div>

            <div className="border-t border-[#E5E1D5]/40 pt-4 flex items-center justify-between gap-2">
              <div>
                <span className="font-mono text-xs font-bold text-[#1A212B]">50 积分</span>
                <span className="text-[10px] text-[#585f6a] block">终身授权</span>
              </div>
              <button
                onClick={() => toggleAddon('aiTranslator', 50, '全自动AI单词翻译引擎')}
                className={`px-3 py-1.5 rounded-sm font-headline text-[10px] font-bold transition-all ${
                  addons.aiTranslator
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 cursor-default'
                    : 'bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90'
                }`}
              >
                {addons.aiTranslator ? '已成功开通' : '立即激活'}
              </button>
            </div>
          </div>

          {/* Addon 2 */}
          <div className="bento-card p-5 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Database size={20} className="text-[#1A212B]" />
                <span className="font-mono text-[10px] text-[#585f6a] font-bold">ADDON_02</span>
              </div>
              <h4 className="font-headline text-sm font-semibold text-[#1A212B]">专业GRE/TOEFL学术词库</h4>
              <p className="font-body text-xs text-[#585f6a] leading-normal">
                解锁官方最全的学术考研核心库。支持一键导入，精准分类释义，完美辅导备考。
              </p>
            </div>

            <div className="border-t border-[#E5E1D5]/40 pt-4 flex items-center justify-between gap-2">
              <div>
                <span className="font-mono text-xs font-bold text-[#1A212B]">80 积分</span>
                <span className="text-[10px] text-[#585f6a] block">终身授权</span>
              </div>
              <button
                onClick={() => toggleAddon('greVocab', 80, 'GRE/TOEFL学术词库')}
                className={`px-3 py-1.5 rounded-sm font-headline text-[10px] font-bold transition-all ${
                  addons.greVocab
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 cursor-default'
                    : 'bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90'
                }`}
              >
                {addons.greVocab ? '已成功开通' : '立即激活'}
              </button>
            </div>
          </div>

          {/* Addon 3 */}
          <div className="bento-card p-5 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Zap size={20} className="text-[#1A212B]" />
                <span className="font-mono text-[10px] text-[#585f6a] font-bold">ADDON_03</span>
              </div>
              <h4 className="font-headline text-sm font-semibold text-[#1A212B]">云端独享中继API专用通道</h4>
              <p className="font-body text-xs text-[#585f6a] leading-normal">
                接入顶级物理硬件机房。延迟降低至30ms以下，具备防爆破防护，专属加密握手。
              </p>
            </div>

            <div className="border-t border-[#E5E1D5]/40 pt-4 flex items-center justify-between gap-2">
              <div>
                <span className="font-mono text-xs font-bold text-[#1A212B]">120 积分</span>
                <span className="text-[10px] text-[#585f6a] block">按月计费</span>
              </div>
              <button
                onClick={() => toggleAddon('dedicatedTunnel', 120, '云端独享中继API专用通道')}
                className={`px-3 py-1.5 rounded-sm font-headline text-[10px] font-bold transition-all ${
                  addons.dedicatedTunnel
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 cursor-default'
                    : 'bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90'
                }`}
              >
                {addons.dedicatedTunnel ? '已成功开通' : '立即激活'}
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
