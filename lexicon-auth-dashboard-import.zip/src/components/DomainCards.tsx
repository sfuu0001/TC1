import React from 'react';
import { Badge, TrendingUp, Award, BookOpen } from 'lucide-react';

interface DomainCardsProps {
  onSimulateLogin: () => void;
  onOpenSecurity: () => void;
  onOpenProfile: () => void;
  onOpenCredits: () => void;
  onSimulateTask: () => void;
  membershipTier: string;
  onToggleMembership: () => void;
  onOpenAddLexeme: () => void;
  onOpenDictionary: () => void;
}

export const DomainCards: React.FC<DomainCardsProps> = ({
  onSimulateLogin,
  onOpenSecurity,
  onOpenProfile,
  onOpenCredits,
  onSimulateTask,
  membershipTier,
  onToggleMembership,
  onOpenAddLexeme,
  onOpenDictionary,
}) => {
  return (
    <section className="space-y-6">
      <h3 className="font-label text-lg text-[#1A212B] border-b border-[#E5E1D5] pb-2">
        Domain Access
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 1. Account & Identity */}
        <div className="bento-card rounded-md p-6 block group">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-8 h-8 rounded-sm bg-[#1A212B] flex items-center justify-center text-[#FAF9F6]">
              <Badge size={16} />
            </div>
            <h4 className="font-headline text-lg font-medium text-[#1A212B]">
              Account &amp; Identity
            </h4>
          </div>
          <p className="font-body text-sm text-[#585f6a] mb-6 leading-relaxed">
            Manage authentication protocols, profile settings, and system access levels.
          </p>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={onSimulateLogin}
              className="px-2 py-1 bg-[#FAF9F6] border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm text-xs font-label text-[#1A212B] transition-colors"
            >
              Login
            </button>
            <button
              onClick={onOpenSecurity}
              className="px-2 py-1 bg-[#FAF9F6] border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm text-xs font-label text-[#1A212B] transition-colors"
            >
              Security
            </button>
            <button
              onClick={onOpenProfile}
              className="px-2 py-1 bg-[#FAF9F6] border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm text-xs font-label text-[#1A212B] transition-colors"
            >
              Profile
            </button>
          </div>
        </div>

        {/* 2. Economy Center */}
        <div className="bento-card rounded-md p-6 block group">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-8 h-8 rounded-sm border border-[#1A212B] flex items-center justify-center text-[#1A212B]">
              <TrendingUp size={16} />
            </div>
            <h4 className="font-headline text-lg font-medium text-[#1A212B]">
              Economy Center
            </h4>
          </div>
          <p className="font-body text-sm text-[#585f6a] mb-6 leading-relaxed">
            Monitor credit flow, active tasks, and reward distributions.
          </p>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={onOpenCredits}
              className="px-2 py-1 bg-[#FAF9F6] border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm text-xs font-label text-[#1A212B] transition-colors"
            >
              Credits
            </button>
            <button
              onClick={onSimulateTask}
              className="px-2 py-1 bg-[#FAF9F6] border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm text-xs font-label text-[#1A212B] transition-colors"
            >
              Tasks
            </button>
          </div>
        </div>

        {/* 3. Membership Hub */}
        <div className="bento-card rounded-md p-6 block group">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-8 h-8 rounded-sm border border-[#1A212B] flex items-center justify-center text-[#1A212B]">
              <Award size={16} />
            </div>
            <h4 className="font-headline text-lg font-medium text-[#1A212B]">
              Membership Hub
            </h4>
          </div>
          <p className="font-body text-sm text-[#585f6a] mb-6 leading-relaxed">
            View subscription tiers, billing cycles, and feature access rights.
          </p>
          <div className="flex flex-wrap gap-2">
            <span className="px-2 py-1 bg-[#FAF9F6] border border-[#E5E1D5] rounded-sm text-xs font-label text-[#1A212B]">
              Status: Active
            </span>
            <button
              onClick={onToggleMembership}
              className="px-2 py-1 bg-[#FAF9F6] border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm text-xs font-label text-[#ba1a1a] font-medium transition-colors"
              title="Click to toggle level / tier"
            >
              Tier: {membershipTier} ⇥
            </button>
          </div>
        </div>

        {/* 4. Lexis Core */}
        <div className="bento-card rounded-md p-6 block group">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-8 h-8 rounded-sm bg-[#1A212B] flex items-center justify-center text-[#FAF9F6]">
              <BookOpen size={16} />
            </div>
            <h4 className="font-headline text-lg font-medium text-[#1A212B]">
              Lexis Core
            </h4>
          </div>
          <p className="font-body text-sm text-[#585f6a] mb-6 leading-relaxed">
            Access dictionary lookups and manage private word collections.
          </p>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={onOpenAddLexeme}
              className="px-2 py-1 bg-[#FAF9F6] border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm text-xs font-label text-[#1A212B] transition-colors"
            >
              Add Word
            </button>
            <button
              onClick={onOpenDictionary}
              className="px-2 py-1 bg-[#FAF9F6] border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm text-xs font-label text-[#1A212B] transition-colors"
            >
              Collections
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
