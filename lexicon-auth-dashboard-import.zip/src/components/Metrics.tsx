import React from 'react';
import { ShieldAlert, Terminal, Library, Wallet, RefreshCw, Zap } from 'lucide-react';
import { DashboardStats } from '../types';

interface MetricsProps {
  stats: DashboardStats;
  onOpenCreditModal: () => void;
  onSimulateApiRequest: () => void;
  onQuickAddWord: () => void;
}

export const Metrics: React.FC<MetricsProps> = ({
  stats,
  onOpenCreditModal,
  onSimulateApiRequest,
  onQuickAddWord,
}) => {
  return (
    <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* 1. Identity Health */}
      <div className="bento-card p-6 rounded-md flex flex-col justify-between h-32 relative overflow-hidden group">
        <div className="flex justify-between items-start z-10">
          <span className="font-label text-xs text-[#585f6a] uppercase tracking-wider">
            Identity Health
          </span>
          <ShieldAlert size={16} className="text-[#1A212B] opacity-50 group-hover:opacity-100 transition-opacity" />
        </div>
        <div className="flex items-baseline space-x-2 z-10">
          <span className="font-headline text-3xl font-semibold text-[#1A212B]">
            {stats.identityHealth.toFixed(1)}
          </span>
          <span className="font-body text-xs text-[#585f6a]">%</span>
        </div>
        {/* Decorative micro-chart styled after the reference screenshot */}
        <div
          className="absolute bottom-0 left-0 w-full h-8 opacity-20 bg-gradient-to-t from-[#1A212B] to-transparent pointer-events-none"
          style={{
            clipPath: 'polygon(0 100%, 20% 60%, 40% 80%, 60% 40%, 80% 50%, 100% 10%, 100% 100%)',
          }}
        />
      </div>

      {/* 2. API Usage */}
      <div className="bento-card p-6 rounded-md flex flex-col justify-between h-32 relative overflow-hidden group">
        <div className="flex justify-between items-start z-10">
          <span className="font-label text-xs text-[#585f6a] uppercase tracking-wider">
            API Usage
          </span>
          <button
            onClick={onSimulateApiRequest}
            className="text-[#585f6a] hover:text-[#1A212B] transition-colors p-0.5 rounded-sm hover:bg-[#E5E1D5]/40"
            title="Simulate API Call (+1 req)"
          >
            <Zap size={15} className="animate-pulse text-[#1A212B]" />
          </button>
        </div>
        <div className="flex items-baseline space-x-2 z-10">
          <span className="font-headline text-3xl font-semibold text-[#1A212B]">
            {stats.apiUsage.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 })}
          </span>
          <span className="font-body text-xs text-[#585f6a]">k/req</span>
        </div>
        {/* Quick simulator visual */}
        <div className="absolute right-3 bottom-3 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          <span className="font-body text-[10px] text-[#585f6a] bg-[#E5E1D5] px-1.5 py-0.5 rounded-sm">
            + Click to simulate traffic
          </span>
        </div>
      </div>

      {/* 3. Total Lexemes */}
      <div className="bento-card p-6 rounded-md flex flex-col justify-between h-32 relative overflow-hidden group">
        <div className="flex justify-between items-start z-10">
          <span className="font-label text-xs text-[#585f6a] uppercase tracking-wider">
            Total Lexemes
          </span>
          <button
            onClick={onQuickAddWord}
            className="text-[#585f6a] hover:text-[#1A212B] transition-colors p-0.5 rounded-sm hover:bg-[#E5E1D5]/40"
            title="Add New Word"
          >
            <Library size={16} />
          </button>
        </div>
        <div className="flex items-baseline space-x-2 z-10">
          <span className="font-headline text-3xl font-semibold text-[#1A212B]">
            {stats.totalLexemes.toLocaleString()}
          </span>
        </div>
        <div className="absolute right-3 bottom-3 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          <span className="font-body text-[10px] text-[#585f6a] bg-[#E5E1D5] px-1.5 py-0.5 rounded-sm">
            + Quick Add Word
          </span>
        </div>
      </div>

      {/* 4. Credit Balance */}
      <div className="bento-card p-6 rounded-md flex flex-col justify-between h-32 relative overflow-hidden group">
        <div className="flex justify-between items-start z-10">
          <span className="font-label text-xs text-[#585f6a] uppercase tracking-wider">
            Credit Balance
          </span>
          <button
            onClick={onOpenCreditModal}
            className="text-[#585f6a] hover:text-[#1A212B] transition-colors p-0.5 rounded-sm hover:bg-[#E5E1D5]/40"
            title="Adjust Credit Balance"
          >
            <Wallet size={16} />
          </button>
        </div>
        <div className="flex items-baseline space-x-2 z-10">
          <span className="font-headline text-3xl font-semibold text-[#1A212B]">
            {stats.creditBalance.toLocaleString()}
          </span>
          <span className="font-body text-xs text-[#585f6a]">CRD</span>
        </div>
        <div className="absolute right-3 bottom-3 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          <span className="font-body text-[10px] text-[#585f6a] bg-[#E5E1D5] px-1.5 py-0.5 rounded-sm">
            Adjust Balance
          </span>
        </div>
      </div>
    </section>
  );
};
