import React, { useState } from 'react';
import { X, Key, User, BookOpen, Coins, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Profile, Lexeme } from '../types';

interface ModalWrapperProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

export const ModalWrapper: React.FC<ModalWrapperProps> = ({
  isOpen,
  onClose,
  title,
  icon,
  children,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#1A212B]/40 backdrop-blur-xs"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 10 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 10 }}
            transition={{ type: 'spring', duration: 0.3 }}
            className="relative w-full max-w-md bg-[#FAF9F6] border border-[#E5E1D5] rounded-md overflow-hidden z-10"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#E5E1D5] bg-[#F9F7F2]">
              <div className="flex items-center space-x-2">
                <span className="text-[#1A212B]">{icon}</span>
                <h3 className="font-headline text-lg font-semibold text-[#1A212B]">
                  {title}
                </h3>
              </div>
              <button
                onClick={onClose}
                className="text-[#585f6a] hover:text-[#1A212B] transition-colors p-1"
                aria-label="Close"
              >
                <X size={18} />
              </button>
            </div>

            {/* Content */}
            <div className="p-5">{children}</div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

// 1. Profile Edit Form
interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: Profile;
  onSave: (newProfile: Profile) => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  profile,
  onSave,
}) => {
  const [name, setName] = useState(profile.name);
  const [role, setRole] = useState(profile.role);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ ...profile, name, role });
    onClose();
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Edit Administrator Profile"
      icon={<User size={18} />}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block font-headline text-xs text-[#585f6a] uppercase tracking-wider mb-1">
            Display Name
          </label>
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#1A212B] transition-colors"
          />
        </div>

        <div>
          <label className="block font-headline text-xs text-[#585f6a] uppercase tracking-wider mb-1">
            Role Description
          </label>
          <input
            type="text"
            required
            value={role}
            onChange={(e) => setRole(e.target.value)}
            className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#1A212B] transition-colors"
          />
        </div>

        <div className="pt-2 flex justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-[#E5E1D5] text-xs font-headline font-semibold text-[#585f6a] hover:text-[#1A212B] hover:border-[#1A212B] rounded-sm transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-[#1A212B] text-xs font-headline font-semibold text-[#FAF9F6] hover:bg-[#1A212B]/90 rounded-sm transition-colors"
          >
            Save Changes
          </button>
        </div>
      </form>
    </ModalWrapper>
  );
};

// 2. Add Lexeme Form
interface AddLexemeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (word: string, translation: string, partOfSpeech: string) => void;
}

export const AddLexemeModal: React.FC<AddLexemeModalProps> = ({
  isOpen,
  onClose,
  onAdd,
}) => {
  const [word, setWord] = useState('');
  const [translation, setTranslation] = useState('');
  const [partOfSpeech, setPartOfSpeech] = useState('noun');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!word || !translation) return;
    onAdd(word, translation, partOfSpeech);
    setWord('');
    setTranslation('');
    setPartOfSpeech('noun');
    onClose();
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Add Private Lexeme"
      icon={<BookOpen size={18} />}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block font-headline text-xs text-[#585f6a] uppercase tracking-wider mb-1">
            Word / Term
          </label>
          <input
            type="text"
            required
            placeholder="e.g. Ephemeral"
            value={word}
            onChange={(e) => setWord(e.target.value)}
            className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#1A212B] transition-colors"
          />
        </div>

        <div>
          <label className="block font-headline text-xs text-[#585f6a] uppercase tracking-wider mb-1">
            Translation / Meaning
          </label>
          <input
            type="text"
            required
            placeholder="e.g. 朝生暮死，短暂的"
            value={translation}
            onChange={(e) => setTranslation(e.target.value)}
            className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#1A212B] transition-colors"
          />
        </div>

        <div>
          <label className="block font-headline text-xs text-[#585f6a] uppercase tracking-wider mb-1">
            Part of Speech
          </label>
          <select
            value={partOfSpeech}
            onChange={(e) => setPartOfSpeech(e.target.value)}
            className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#1A212B] transition-colors"
          >
            <option value="noun">Noun (n.)</option>
            <option value="verb">Verb (v.)</option>
            <option value="adjective">Adjective (adj.)</option>
            <option value="adverb">Adverb (adv.)</option>
            <option value="conjunction">Conjunction (conj.)</option>
          </select>
        </div>

        <div className="pt-2 flex justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-[#E5E1D5] text-xs font-headline font-semibold text-[#585f6a] hover:text-[#1A212B] hover:border-[#1A212B] rounded-sm transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-[#1A212B] text-xs font-headline font-semibold text-[#FAF9F6] hover:bg-[#1A212B]/90 rounded-sm transition-colors"
          >
            Add Word
          </button>
        </div>
      </form>
    </ModalWrapper>
  );
};

// 3. API Key Generation Form
interface GenerateApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (name: string) => void;
}

export const GenerateApiKeyModal: React.FC<GenerateApiKeyModalProps> = ({
  isOpen,
  onClose,
  onGenerate,
}) => {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onGenerate(name);
    setName('');
    onClose();
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Generate Production API Key"
      icon={<Key size={18} />}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <p className="font-headline text-xs text-[#585f6a] leading-relaxed">
          Production keys grant full read/write access to security namespaces and active Lexis dictionary indexing.
        </p>

        <div>
          <label className="block font-headline text-xs text-[#585f6a] uppercase tracking-wider mb-1">
            Key Label / Name
          </label>
          <input
            type="text"
            required
            placeholder="e.g. Website Integration SDK"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#1A212B] transition-colors"
          />
        </div>

        <div className="pt-2 flex justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-[#E5E1D5] text-xs font-headline font-semibold text-[#585f6a] hover:text-[#1A212B] hover:border-[#1A212B] rounded-sm transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-[#1A212B] text-xs font-headline font-semibold text-[#FAF9F6] hover:bg-[#1A212B]/90 rounded-sm transition-colors"
          >
            Generate Key
          </button>
        </div>
      </form>
    </ModalWrapper>
  );
};

// 4. Credit adjustment / Simulation Form
interface CreditModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBalance: number;
  onTransaction: (amount: number, reason: string) => void;
}

export const CreditModal: React.FC<CreditModalProps> = ({
  isOpen,
  onClose,
  currentBalance,
  onTransaction,
}) => {
  const [amount, setAmount] = useState(100);
  const [type, setType] = useState<'add' | 'deduct'>('add');
  const [reason, setReason] = useState('Manual Administrative Provision');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const actualAmount = type === 'add' ? amount : -amount;
    onTransaction(actualAmount, reason);
    onClose();
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Adjust Credit Balance"
      icon={<Coins size={18} />}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-3 rounded-sm flex justify-between items-center mb-2">
          <span className="font-label text-sm text-[#585f6a]">Current Balance</span>
          <span className="font-headline text-lg font-bold text-[#1A212B]">{currentBalance} CRD</span>
        </div>

        <div>
          <label className="block font-headline text-xs text-[#585f6a] uppercase tracking-wider mb-2">
            Adjustment Type
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setType('add')}
              className={`py-2 text-xs font-headline font-semibold border rounded-sm transition-colors ${
                type === 'add'
                  ? 'bg-[#1A212B] text-[#FAF9F6] border-[#1A212B]'
                  : 'bg-[#F9F7F2] text-[#585f6a] border-[#E5E1D5] hover:border-[#1A212B]'
              }`}
            >
              Add / Grant
            </button>
            <button
              type="button"
              onClick={() => setType('deduct')}
              className={`py-2 text-xs font-headline font-semibold border rounded-sm transition-colors ${
                type === 'deduct'
                  ? 'bg-[#1A212B] text-[#FAF9F6] border-[#1A212B]'
                  : 'bg-[#F9F7F2] text-[#585f6a] border-[#E5E1D5] hover:border-[#1A212B]'
              }`}
            >
              Deduct / Charge
            </button>
          </div>
        </div>

        <div>
          <label className="block font-headline text-xs text-[#585f6a] uppercase tracking-wider mb-1">
            Amount (CRD)
          </label>
          <input
            type="number"
            required
            min={1}
            max={10000}
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
            className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#1A212B] transition-colors"
          />
        </div>

        <div>
          <label className="block font-headline text-xs text-[#585f6a] uppercase tracking-wider mb-1">
            Reason / Memo
          </label>
          <input
            type="text"
            required
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#1A212B] transition-colors"
          />
        </div>

        <div className="pt-2 flex justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-[#E5E1D5] text-xs font-headline font-semibold text-[#585f6a] hover:text-[#1A212B] hover:border-[#1A212B] rounded-sm transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-[#1A212B] text-xs font-headline font-semibold text-[#FAF9F6] hover:bg-[#1A212B]/90 rounded-sm transition-colors"
          >
            Apply Adjustment
          </button>
        </div>
      </form>
    </ModalWrapper>
  );
};

// 5. Security Protocols Form
interface SecurityModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentMfa: boolean;
  currentTimeout: number;
  onUpdate: (mfa: boolean, timeout: number) => void;
}

export const SecurityModal: React.FC<SecurityModalProps> = ({
  isOpen,
  onClose,
  currentMfa,
  currentTimeout,
  onUpdate,
}) => {
  const [mfa, setMfa] = useState(currentMfa);
  const [timeout, setTimeout] = useState(currentTimeout);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate(mfa, timeout);
    onClose();
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Security & Access Protocols"
      icon={<ShieldAlert size={18} />}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex items-center justify-between p-3 bg-[#F9F7F2] border border-[#E5E1D5] rounded-sm">
          <div>
            <span className="block font-headline text-sm font-semibold text-[#1A212B]">
              Multi-Factor Auth (MFA)
            </span>
            <span className="block font-label text-xs text-[#585f6a]">
              Require biometric verification on new sessions
            </span>
          </div>
          <button
            type="button"
            onClick={() => setMfa(!mfa)}
            className={`w-12 h-6 rounded-full transition-colors relative focus:outline-none ${
              mfa ? 'bg-[#1A212B]' : 'bg-[#E5E1D5]'
            }`}
          >
            <span
              className={`absolute top-1 left-1 bg-[#FAF9F6] w-4 h-4 rounded-full transition-transform ${
                mfa ? 'translate-x-6' : ''
              }`}
            />
          </button>
        </div>

        <div>
          <label className="block font-headline text-xs text-[#585f6a] uppercase tracking-wider mb-1">
            Session Idle Timeout (Minutes)
          </label>
          <select
            value={timeout}
            onChange={(e) => setTimeout(Number(e.target.value))}
            className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-sm px-3 py-2 rounded-sm focus:outline-none focus:border-[#1A212B] transition-colors"
          >
            <option value={15}>15 Minutes</option>
            <option value={30}>30 Minutes</option>
            <option value={60}>60 Minutes (Standard)</option>
            <option value={120}>120 Minutes (Extended)</option>
            <option value={0}>No Timeout (Caution)</option>
          </select>
        </div>

        <div className="pt-2 flex justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-[#E5E1D5] text-xs font-headline font-semibold text-[#585f6a] hover:text-[#1A212B] hover:border-[#1A212B] rounded-sm transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-[#1A212B] text-xs font-headline font-semibold text-[#FAF9F6] hover:bg-[#1A212B]/90 rounded-sm transition-colors"
          >
            Apply Protocols
          </button>
        </div>
      </form>
    </ModalWrapper>
  );
};
