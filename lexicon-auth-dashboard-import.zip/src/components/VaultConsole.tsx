import React, { useState } from 'react';
import { Key, Copy, Check, Trash2, Plus, Terminal, Eye, EyeOff } from 'lucide-react';
import { ApiKey } from '../types';

interface VaultConsoleProps {
  apiKeys: ApiKey[];
  onGenerateKey: (name: string) => void;
  onRevokeKey: (id: string) => void;
  onLogAction: (title: string, desc: string, domain: 'Account & Identity' | 'Economy Center' | 'Membership Hub' | 'Lexis Core' | 'General', type: 'info' | 'warning' | 'error' | 'success') => void;
}

export const VaultConsole: React.FC<VaultConsoleProps> = ({
  apiKeys,
  onGenerateKey,
  onRevokeKey,
  onLogAction,
}) => {
  const [newKeyName, setNewKeyName] = useState('');
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);
  const [visibleKeys, setVisibleKeys] = useState<Record<string, boolean>>({});

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyName.trim()) return;
    onGenerateKey(newKeyName.trim());
    setNewKeyName('');
  };

  const handleCopy = (id: string, keyVal: string) => {
    navigator.clipboard.writeText(keyVal);
    setCopiedKeyId(id);
    onLogAction(
      `Credential Copied`,
      `API Key [${id.substring(0, 6)}] copied to system clipboard`,
      'Account & Identity',
      'info'
    );
    setTimeout(() => setCopiedKeyId(null), 2000);
  };

  const toggleVisibility = (id: string) => {
    setVisibleKeys((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-6 max-w-[1280px] mx-auto animate-fadeIn">
      {/* Header */}
      <header className="mb-8">
        <h2 className="font-headline text-3xl font-semibold tracking-tight text-[#1A212B]">
          Credentials Vault
        </h2>
        <p className="font-label text-base text-[#585f6a] mt-2">
          Lexicon 凭证库 - Cryptographic keys, secrets and token credentials registries.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Token Registry Table */}
        <section className="lg:col-span-2 space-y-6">
          <h3 className="font-label text-lg text-[#1A212B] border-b border-[#E5E1D5] pb-2">
            Active Tokens &amp; Keys Registry
          </h3>

          <div className="bento-card rounded-md overflow-hidden bg-[#FAF9F6]">
            {apiKeys.length === 0 ? (
              <div className="p-8 text-center text-[#585f6a]">
                <p className="font-body text-sm">No tokens active in current workspace.</p>
                <p className="font-label text-xs mt-1">Generate a production credential below to connect client-side SDKs.</p>
              </div>
            ) : (
              <table className="w-full text-left font-body text-xs border-collapse">
                <thead>
                  <tr className="bg-[#F9F7F2] border-b border-[#E5E1D5]">
                    <th className="p-3 font-headline font-semibold text-[#1A212B]">Label</th>
                    <th className="p-3 font-headline font-semibold text-[#1A212B]">Created</th>
                    <th className="p-3 font-headline font-semibold text-[#1A212B]">Secret Payload</th>
                    <th className="p-3 font-headline font-semibold text-[#1A212B] text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5E1D5]">
                  {apiKeys.map((item) => {
                    const isVisible = !!visibleKeys[item.id];
                    const maskedKey = isVisible
                      ? item.key
                      : `lex_live_••••••••••••${item.key.slice(-4)}`;

                    return (
                      <tr key={item.id} className="hover:bg-[#F9F7F2]/40 transition-colors">
                        <td className="p-3 font-semibold text-[#1A212B]">
                          {item.name}
                        </td>
                        <td className="p-3 text-[#585f6a]">
                          {new Date(item.created).toLocaleDateString()}
                        </td>
                        <td className="p-3 font-mono text-[11px] text-[#585f6a] flex items-center space-x-1.5">
                          <span>{maskedKey}</span>
                          <button
                            onClick={() => toggleVisibility(item.id)}
                            className="text-[#585f6a] hover:text-[#1A212B] p-0.5 rounded-sm"
                            title={isVisible ? 'Hide payload' : 'Reveal payload'}
                          >
                            {isVisible ? <EyeOff size={11} /> : <Eye size={11} />}
                          </button>
                        </td>
                        <td className="p-3 text-right space-x-2">
                          <button
                            onClick={() => handleCopy(item.id, item.key)}
                            className="text-[#585f6a] hover:text-[#1A212B] inline-flex items-center space-x-1 border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm px-2 py-0.5"
                            title="Copy API Key"
                          >
                            {copiedKeyId === item.id ? <Check size={11} /> : <Copy size={11} />}
                            <span className="text-[10px] font-headline">{copiedKeyId === item.id ? 'Copied' : 'Copy'}</span>
                          </button>
                          <button
                            onClick={() => onRevokeKey(item.id)}
                            className="text-brand-error hover:bg-brand-error/5 border border-transparent hover:border-brand-error/30 rounded-sm p-1 inline-flex items-center"
                            title="Revoke Credential"
                          >
                            <Trash2 size={12} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </section>

        {/* Generate Key Form Panel */}
        <section className="space-y-6">
          <h3 className="font-label text-lg text-[#1A212B] border-b border-[#E5E1D5] pb-2">
            Generate Credential
          </h3>

          <div className="bento-card rounded-md p-6">
            <form onSubmit={handleCreate} className="space-y-4">
              <p className="font-headline text-xs text-[#585f6a] leading-relaxed">
                Generate production-level API tokens to connect external scripts, query dictionaries, or interface with secure authenticators.
              </p>

              <div>
                <label className="block font-headline text-xs text-[#585f6a] uppercase tracking-wider mb-1">
                  Key Label Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. NextJS App Client Keys"
                  value={newKeyName}
                  onChange={(e) => setNewKeyName(e.target.value)}
                  className="w-full bg-[#FAF9F6] border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2.5 py-2 rounded-sm focus:outline-none focus:border-[#1A212B]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#1A212B] text-xs font-headline font-semibold text-[#FAF9F6] hover:bg-[#1A212B]/90 rounded-sm transition-colors flex items-center justify-center space-x-1.5"
              >
                <Plus size={14} />
                <span>Create Production Key</span>
              </button>
            </form>
          </div>
        </section>
      </div>
    </div>
  );
};
