import React, { useState } from 'react';
import { BookOpen, Search, Trash2, Plus, ExternalLink } from 'lucide-react';
import { Lexeme } from '../types';
import { ModalWrapper } from './InteractiveDialogs';

interface LexisCoreDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  lexemes: Lexeme[];
  onAddLexeme: (word: string, translation: string, partOfSpeech: string) => void;
  onRemoveLexeme: (id: string) => void;
}

export const LexisCoreDrawer: React.FC<LexisCoreDrawerProps> = ({
  isOpen,
  onClose,
  lexemes,
  onAddLexeme,
  onRemoveLexeme,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [word, setWord] = useState('');
  const [translation, setTranslation] = useState('');
  const [partOfSpeech, setPartOfSpeech] = useState('noun');
  const [showAddForm, setShowAddForm] = useState(false);

  const filtered = lexemes.filter(
    (item) =>
      item.word.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.translation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!word || !translation) return;
    onAddLexeme(word, translation, partOfSpeech);
    setWord('');
    setTranslation('');
    setPartOfSpeech('noun');
    setShowAddForm(false);
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Lexis Core Private Collection"
      icon={<BookOpen size={18} />}
    >
      <div className="space-y-4 max-h-[75vh] flex flex-col">
        {showAddForm ? (
          <form onSubmit={handleSubmit} className="space-y-3 p-4 bg-[#F9F7F2] border border-[#E5E1D5] rounded-sm">
            <h4 className="font-headline text-xs font-semibold text-[#1A212B] uppercase tracking-wider mb-2">
              Add New Lexeme
            </h4>
            <div>
              <input
                type="text"
                placeholder="Word / Lexeme Name"
                value={word}
                onChange={(e) => setWord(e.target.value)}
                required
                className="w-full bg-[#FAF9F6] border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2.5 py-1.5 rounded-sm focus:outline-none focus:border-[#1A212B]"
              />
            </div>
            <div>
              <input
                type="text"
                placeholder="Translation / Meaning / Definition"
                value={translation}
                onChange={(e) => setTranslation(e.target.value)}
                required
                className="w-full bg-[#FAF9F6] border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2.5 py-1.5 rounded-sm focus:outline-none focus:border-[#1A212B]"
              />
            </div>
            <div>
              <select
                value={partOfSpeech}
                onChange={(e) => setPartOfSpeech(e.target.value)}
                className="w-full bg-[#FAF9F6] border border-[#E5E1D5] text-[#1A212B] font-body text-xs px-2.5 py-1.5 rounded-sm focus:outline-none"
              >
                <option value="noun">Noun (n.)</option>
                <option value="verb">Verb (v.)</option>
                <option value="adjective">Adjective (adj.)</option>
                <option value="adverb">Adverb (adv.)</option>
              </select>
            </div>
            <div className="flex justify-end space-x-2 pt-1">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-2.5 py-1 text-xs font-headline text-[#585f6a]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-3 py-1 bg-[#1A212B] text-xs font-headline text-[#FAF9F6] rounded-sm"
              >
                Add Word
              </button>
            </div>
          </form>
        ) : (
          <div className="flex justify-between items-center">
            <div className="relative flex-1 mr-2">
              <span className="absolute inset-y-0 left-0 flex items-center pl-2 pointer-events-none text-[#585f6a]">
                <Search size={14} />
              </span>
              <input
                type="text"
                placeholder="Search collection..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-xs pl-7 pr-3 py-1.5 rounded-sm focus:outline-none"
              />
            </div>
            <button
              onClick={() => setShowAddForm(true)}
              className="px-3 py-1.5 bg-[#1A212B] text-xs font-headline font-semibold text-[#FAF9F6] rounded-sm hover:bg-[#1A212B]/90 transition-all flex items-center space-x-1"
            >
              <Plus size={12} />
              <span>New</span>
            </button>
          </div>
        )}

        {/* Word ledger list */}
        <div className="flex-1 overflow-y-auto max-h-[300px] custom-scrollbar border border-[#E5E1D5] rounded-sm bg-[#FAF9F6] p-2 space-y-2">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-[#585f6a]">
              <p className="font-headline text-xs">No words stored in private namespace.</p>
              <p className="font-label text-[10px] mt-1">Add index targets using the "New" option above.</p>
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                className="p-2.5 bg-[#F9F7F2] border border-[#E5E1D5] hover:border-[#1A212B] rounded-sm transition-all flex justify-between items-start group"
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-1.5">
                    <span className="font-headline text-sm font-semibold text-[#1A212B]">
                      {item.word}
                    </span>
                    <span className="font-label text-[10px] text-[#585f6a] italic opacity-80">
                      ({item.partOfSpeech})
                    </span>
                  </div>
                  <p className="font-body text-xs text-[#585f6a] leading-relaxed">
                    {item.translation}
                  </p>
                  <span className="block font-label text-[9px] text-[#585f6a] opacity-60">
                    Added {new Date(item.addedAt).toLocaleDateString()}
                  </span>
                </div>
                <button
                  onClick={() => onRemoveLexeme(item.id)}
                  className="text-brand-error opacity-0 group-hover:opacity-100 hover:bg-brand-error/5 p-1 rounded-sm transition-all"
                  title="Remove word from private dictionary"
                >
                  <Trash2 size={13} />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </ModalWrapper>
  );
};
