import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  TrendingUp,
  Gift,
  Calendar,
  CheckCircle2,
  DollarSign,
  UserCheck,
  Award,
  ArrowUpRight,
  ArrowDownLeft,
  Clock,
  Sparkles,
  Sliders,
  Play,
  Zap,
  RefreshCw,
  Info,
  Layers,
  Activity,
  ChevronRight,
  AlertTriangle,
  Send,
  LineChart
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { SystemEvent } from '../types';

interface EconomyConsoleProps {
  creditBalance: number;
  onTransaction: (amount: number, reason: string) => void;
  logs: SystemEvent[];
  onLogAction?: (
    title: string,
    desc: string,
    domain: 'Account & Identity' | 'Economy Center' | 'Membership Hub' | 'Lexis Core' | 'General',
    type: 'info' | 'warning' | 'error' | 'success'
  ) => void;
}

export const EconomyConsole: React.FC<EconomyConsoleProps> = ({
  creditBalance,
  onTransaction,
  logs,
  onLogAction,
}) => {
  // --- SUB TABS SETUP ---
  const [activeSubTab, setActiveSubTab] = useState<'market' | 'tasks'>('market');

  // --- GENERAL TOAST ---
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // --- 1. STOCK MARKET PERSISTENT STATES ---
  const [cashBalance, setCashBalance] = useState<number>(() => {
    const saved = localStorage.getItem('lexicon_market_cash');
    return saved ? parseFloat(saved) : 10000.00;
  });

  const [creditPrice, setCreditPrice] = useState<number>(() => {
    const saved = localStorage.getItem('lexicon_credit_price');
    return saved ? parseFloat(saved) : 1.25;
  });

  const [priceHistory, setPriceHistory] = useState<{ time: string; price: number }[]>(() => {
    const saved = localStorage.getItem('lexicon_price_history');
    if (saved) {
      return JSON.parse(saved);
    }
    // Default historical curve leading up to 1.25
    return [
      { time: '10:00', price: 0.85 },
      { time: '11:00', price: 0.92 },
      { time: '12:00', price: 0.88 },
      { time: '13:00', price: 0.95 },
      { time: '14:00', price: 1.05 },
      { time: '15:00', price: 0.98 },
      { time: '16:00', price: 1.12 },
      { time: '17:00', price: 1.08 },
      { time: '18:00', price: 1.15 },
      { time: '19:00', price: 1.22 },
      { time: '20:00', price: 1.18 },
      { time: '21:00', price: 1.24 },
      { time: '22:00', price: 1.25 }
    ];
  });

  const [marketLogs, setMarketLogs] = useState<{ id: string; time: string; type: 'buy' | 'sell' | 'system' | 'warn'; msg: string; price: number }[]>(() => {
    const saved = localStorage.getItem('lexicon_market_logs');
    return saved ? JSON.parse(saved) : [
      { id: 'm1', time: '21:30', type: 'system', msg: 'Lexis Core 积分板交易对 CRD/CNY 挂牌上线成功', price: 1.00 },
      { id: 'm2', time: '21:45', type: 'buy', msg: '机构买单：大宗账户批次买入 1,200 CRD 触发上涨', price: 1.05 },
      { id: 'm3', time: '21:50', type: 'warn', msg: '通胀通知：全网派发注册礼包触发轻微通胀贬值 -4.5%', price: 1.00 },
      { id: 'm4', time: '22:00', type: 'buy', msg: '用户成交：以 1.18 元限价买入 800 CRD 成功', price: 1.18 },
      { id: 'm5', time: '22:15', type: 'sell', msg: '散户抛售：持币者获利了结售出 400 CRD', price: 1.24 }
    ];
  });

  // Save to localStorage when modified
  useEffect(() => {
    localStorage.setItem('lexicon_market_cash', cashBalance.toFixed(2));
  }, [cashBalance]);

  useEffect(() => {
    localStorage.setItem('lexicon_credit_price', creditPrice.toFixed(4));
  }, [creditPrice]);

  useEffect(() => {
    localStorage.setItem('lexicon_price_history', JSON.stringify(priceHistory));
  }, [priceHistory]);

  useEffect(() => {
    localStorage.setItem('lexicon_market_logs', JSON.stringify(marketLogs));
  }, [marketLogs]);

  // --- 2. ORDER BOOK FLICKERING SIMULATOR ---
  const generateOrderBook = (basePrice: number) => {
    const asks = []; // Sells (Red) - higher than current price
    const bids = []; // Buys (Green) - lower than current price
    for (let i = 5; i >= 1; i--) {
      const askPrice = basePrice * (1 + (i * 0.009) + (Math.random() * 0.003));
      const askVol = Math.floor(Math.random() * 800) + 120;
      asks.push({ price: askPrice, volume: askVol });
    }
    for (let i = 1; i <= 5; i++) {
      const bidPrice = basePrice * (1 - (i * 0.009) - (Math.random() * 0.003));
      const bidVol = Math.floor(Math.random() * 950) + 150;
      bids.push({ price: bidPrice, volume: bidVol });
    }
    return { asks, bids };
  };

  const [orderBook, setOrderBook] = useState(() => generateOrderBook(creditPrice));

  useEffect(() => {
    const interval = setInterval(() => {
      setOrderBook(generateOrderBook(creditPrice));
    }, 4500);
    return () => clearInterval(interval);
  }, [creditPrice]);

  // --- 3. DYNAMIC ADJUSTMENT MANAGER PANEL STATES ---
  const [adjustType, setAdjustType] = useState<'daily' | 'weekly' | 'custom'>('daily');
  const [adjustDir, setAdjustDir] = useState<'up' | 'down'>('down');
  const [adjustPercent, setAdjustPercent] = useState<number>(10); // in percent, e.g. 10%
  const [scheduledTargetTime, setScheduledTargetTime] = useState<string>('24:00');

  // --- 4. TRADING INPUT CONSOLE STATES ---
  const [tradeTab, setTradeTab] = useState<'buy' | 'sell'>('buy');
  const [tradeAmount, setTradeAmount] = useState<number>(200); // CRD count
  const tradeFeePercent = 0.002; // 0.2% Gas Fee

  const tradePriceImpact = useMemo(() => {
    // Large trade amount impacts the market price: 1000 CRD bought = +10% price impact, etc.
    return (tradeAmount / 2000) * 0.1;
  }, [tradeAmount]);

  const cashNeeded = useMemo(() => {
    const raw = tradeAmount * creditPrice;
    const fee = raw * tradeFeePercent;
    return raw + fee;
  }, [tradeAmount, creditPrice]);

  const cashProceeds = useMemo(() => {
    const raw = tradeAmount * creditPrice;
    const fee = raw * tradeFeePercent;
    return raw - fee;
  }, [tradeAmount, creditPrice]);

  // Helper to log transaction node & trigger parent system log
  const logMarketNode = (
    type: 'buy' | 'sell' | 'system' | 'warn',
    msg: string,
    priceVal: number,
    logTitle: string,
    logDesc: string
  ) => {
    const now = new Date();
    const timeString = now.toTimeString().substring(0, 5);
    const newNode = {
      id: 'm_log_' + Math.random().toString(36).substring(2, 9),
      time: timeString,
      type,
      msg,
      price: priceVal
    };
    setMarketLogs(prev => [newNode, ...prev.slice(0, 49)]); // Keep latest 50

    // Trigger app central event logs
    if (onLogAction) {
      onLogAction(
        logTitle,
        logDesc,
        'Economy Center',
        type === 'warn' ? 'warning' : type === 'buy' ? 'success' : 'info'
      );
    }
  };

  // --- 5. EXECUTE BUY ACTION ---
  const handleMarketBuy = () => {
    if (tradeAmount <= 0) {
      triggerToast('请输入有效的购买积分数额');
      return;
    }
    if (cashBalance < cashNeeded) {
      triggerToast('❌ 模拟现金余额不足，无法执行本次买入挂单');
      return;
    }

    // Spend Cash, Add Credits
    setCashBalance(prev => prev - cashNeeded);
    onTransaction(tradeAmount, `在积分商城以单价 ${creditPrice.toFixed(2)} 元成功买入`);

    // Price hikes due to demand
    const priceHike = creditPrice * tradePriceImpact;
    const finalPrice = parseFloat((creditPrice + priceHike).toFixed(4));
    setCreditPrice(finalPrice);

    // Add to history graph
    const now = new Date();
    const currentHourMin = now.toTimeString().substring(0, 5);
    setPriceHistory(prev => [...prev.slice(-14), { time: currentHourMin, price: finalPrice }]);

    triggerToast(`🟢 成功购入 ${tradeAmount} CRD！积分价格上涨 +${(tradePriceImpact * 100).toFixed(2)}%`);

    logMarketNode(
      'buy',
      `用户买入成交：以单价 ${creditPrice.toFixed(2)} 元购入 ${tradeAmount} CRD，消耗现金 ${cashNeeded.toFixed(2)} 元`,
      finalPrice,
      'Credits Speculated UP',
      `Market buy order executed for ${tradeAmount} CRD. Net price driven up to ${finalPrice} CNY (+${(tradePriceImpact * 100).toFixed(2)}%)`
    );
  };

  // --- 6. EXECUTE SELL ACTION ---
  const handleMarketSell = () => {
    if (tradeAmount <= 0) {
      triggerToast('请输入有效的卖出积分数额');
      return;
    }
    if (creditBalance < tradeAmount) {
      triggerToast('❌ 可用积分不足，无法执行本次卖出挂单');
      return;
    }

    // Deduct Credits, Add Cash
    onTransaction(-tradeAmount, `在积分商城以单价 ${creditPrice.toFixed(2)} 元成功售出`);
    setCashBalance(prev => prev + cashProceeds);

    // Price drops due to supply pressure
    const priceDrop = creditPrice * tradePriceImpact;
    const finalPrice = Math.max(0.01, parseFloat((creditPrice - priceDrop).toFixed(4)));
    setCreditPrice(finalPrice);

    // Add to history graph
    const now = new Date();
    const currentHourMin = now.toTimeString().substring(0, 5);
    setPriceHistory(prev => [...prev.slice(-14), { time: currentHourMin, price: finalPrice }]);

    triggerToast(`🔴 成功抛售 ${tradeAmount} CRD！积分价格下跌 -${(tradePriceImpact * 100).toFixed(2)}%`);

    logMarketNode(
      'sell',
      `用户抛售成交：以单价 ${creditPrice.toFixed(2)} 元售出 ${tradeAmount} CRD，变现获得 ${cashProceeds.toFixed(2)} 元`,
      finalPrice,
      'Credits Speculated DOWN',
      `Market sell order executed for ${tradeAmount} CRD. Net price driven down to ${finalPrice} CNY (-${(tradePriceImpact * 100).toFixed(2)}%)`
    );
  };

  // --- 7. FREE BONUS AIRDROP (INFLATION DILUTION RULE) ---
  const handleAirdropInflation = () => {
    // Receive 200 free credits
    onTransaction(200, '申领免费扶持特权空投 (触发通胀贬值)');

    // Immediate -15% depreciation
    const depreciationPercent = 15;
    const prevPrice = creditPrice;
    const finalPrice = parseFloat((creditPrice * 0.85).toFixed(4));
    setCreditPrice(finalPrice);

    // Add to chart history
    const now = new Date();
    const currentHourMin = now.toTimeString().substring(0, 5);
    setPriceHistory(prev => [...prev.slice(-14), { time: currentHourMin, price: finalPrice }]);

    setCashBalance(prev => prev + 0); // Cash is unaffected

    triggerToast(`🎁 成功领取 +200 免费积分！货币供应过剩，单价贬值 -${depreciationPercent}%`);

    logMarketNode(
      'warn',
      `🚨 通胀贬值警告：用户申领 200 CRD 免费特权空投，全网流通总量稀释，价格被动通胀下跌 -15.00%`,
      finalPrice,
      'Point Supply Diluted',
      `Airdrop token generation (+200 CRD) created credit inflation. Unit market price depreciated from ${prevPrice} to ${finalPrice} CNY (-15%)`
    );
  };

  // --- 8. MANAGER MANUAL ADJUSETMENT PLAN ---
  const handleSaveManagerPlan = () => {
    triggerToast(`⚙️ 已成功激活【${adjustType === 'daily' ? '每日' : adjustType === 'weekly' ? '每周' : '定时'}调控计划】：设定于 ${scheduledTargetTime} 自动调控价格变动 ${adjustDir === 'up' ? '+' : '-'}${adjustPercent}%`);
  };

  // Immediate Force Execute Manager Adjustment
  const handleExecuteManagerPlan = () => {
    const factor = adjustPercent / 100;
    const prevPrice = creditPrice;
    let finalPrice = creditPrice;

    if (adjustDir === 'up') {
      finalPrice = parseFloat((creditPrice * (1 + factor)).toFixed(4));
    } else {
      finalPrice = Math.max(0.01, parseFloat((creditPrice * (1 - factor)).toFixed(4)));
    }

    setCreditPrice(finalPrice);

    // Add to chart history
    const now = new Date();
    const currentHourMin = now.toTimeString().substring(0, 5);
    setPriceHistory(prev => [...prev.slice(-14), { time: currentHourMin, price: finalPrice }]);

    triggerToast(`⚡️ 管理员强行执行调控计划：价格已 ${adjustDir === 'up' ? '上调' : '下调'} ${adjustPercent}%！`);

    logMarketNode(
      'system',
      `🛠 定期调控执行：项目方强力执行【${adjustType === 'daily' ? '每日' : adjustType === 'weekly' ? '每周' : '定时'}】价格调控，单价变动 ${adjustDir === 'up' ? '+' : '-'}${adjustPercent}%`,
      finalPrice,
      'Manager Price Adjustment',
      `Project team manually enforced scheduled ${adjustType} macro-adjustment policy. Target price modified by ${adjustDir === 'up' ? '+' : '-'}${adjustPercent}% (from ${prevPrice} to ${finalPrice} CNY)`
    );
  };

  // --- 9. PUMP AND DUMP (庄家强力控盘) ---
  const handleWhalePump = () => {
    const pumpRate = 15 + Math.floor(Math.random() * 15); // +15% to +30%
    const prevPrice = creditPrice;
    const finalPrice = parseFloat((creditPrice * (1 + pumpRate / 100)).toFixed(4));
    setCreditPrice(finalPrice);

    const now = new Date();
    const currentHourMin = now.toTimeString().substring(0, 5);
    setPriceHistory(prev => [...prev.slice(-14), { time: currentHourMin, price: finalPrice }]);

    triggerToast(`🚀 庄家暴力拉升：巨鲸扫货，价格暴涨 +${pumpRate}%！`);

    logMarketNode(
      'buy',
      `🔥 庄家主力控盘：监测到神秘大鳄大宗溢价收购，全网流动性告急，价格瞬间拉升 +${pumpRate}%`,
      finalPrice,
      'Whale Pump Injected',
      `Whale institutional order group pumped credit price violently by +${pumpRate}% (from ${prevPrice} to ${finalPrice} CNY) to trap short sellers`
    );
  };

  const handleWhaleDump = () => {
    const dumpRate = 12 + Math.floor(Math.random() * 14); // -12% to -26%
    const prevPrice = creditPrice;
    const finalPrice = Math.max(0.01, parseFloat((creditPrice * (1 - dumpRate / 100)).toFixed(4)));
    setCreditPrice(finalPrice);

    const now = new Date();
    const currentHourMin = now.toTimeString().substring(0, 5);
    setPriceHistory(prev => [...prev.slice(-14), { time: currentHourMin, price: finalPrice }]);

    triggerToast(`⚠️ 庄家获利砸盘：大单抛售，价格大跌 -${dumpRate}%！`);

    logMarketNode(
      'warn',
      `💥 庄家主力控盘：大户多单高位获利了结，砸出数万张恐慌盘，价格瞬间暴跌 -${dumpRate}%`,
      finalPrice,
      'Whale Dump Triggered',
      `Whale account triggered high-frequency stop-loss dump, dropping the unit exchange price by -${dumpRate}% (from ${prevPrice} to ${finalPrice} CNY)`
    );
  };

  // --- 10. TIME-BASED NEWS HEADLINES FEED ---
  const [activeNews, setActiveNews] = useState<string>('🔥 【大特写】生词本高频词更新，刚性消耗猛增，积分流通估值大幅攀升！');
  const newsTickerList = [
    '🔥 【大特写】官方单词本高频词更新，刚性消耗猛增，积分流通估值大幅攀升！',
    '📢 【官宣】新年直充特权包「LEXICON2026」火热兑换中，限量抢注积分大礼包',
    '📉 【通胀警报】部分散户疯狂申领免费空投低保福利，引发全网大范围价格折贬隐忧',
    '🐋 【大户动态】监测到地址 0x7b2a... 将 5000 CRD 存入安全冷钱包保险库，深度锁定供给',
    '📈 【盘面分析】今日积分突破 1.5 CNY 阻力位，多头散户持续买入，建议理性炒作',
    '⚡️ 【机制调整】项目方拟开展“背单词送积分”返利优惠，提振底层生态积分刚需底气'
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      const idx = Math.floor(Math.random() * newsTickerList.length);
      setActiveNews(newsTickerList[idx]);
    }, 12000);
    return () => clearInterval(interval);
  }, []);

  // --- 11. CUSTOM SVG SPARKLINE CHART DRAWING MATH ---
  const chartPoints = useMemo(() => {
    if (priceHistory.length === 0) return '';
    const width = 600;
    const height = 180;
    const paddingLeft = 40;
    const paddingRight = 20;
    const paddingTop = 20;
    const paddingBottom = 20;

    const prices = priceHistory.map(h => h.price);
    const max = Math.max(...prices, 1.5) * 1.05;
    const min = Math.max(0.01, Math.min(...prices, 0.5) * 0.95);

    const getX = (index: number) => {
      return paddingLeft + (index / (priceHistory.length - 1)) * (width - paddingLeft - paddingRight);
    };

    const getY = (priceVal: number) => {
      return paddingTop + (1 - (priceVal - min) / (max - min)) * (height - paddingTop - paddingBottom);
    };

    const linePoints = priceHistory.map((h, i) => `${getX(i)},${getY(h.price)}`).join(' ');
    
    // Gradient close path points
    const firstX = getX(0);
    const lastX = getX(priceHistory.length - 1);
    const zeroY = height - paddingBottom;
    const gradientPath = `${firstX},${zeroY} ${linePoints} ${lastX},${zeroY}`;

    return {
      linePath: linePoints,
      fillPath: gradientPath,
      minPrice: min,
      maxPrice: max,
      gridLines: [
        { label: max.toFixed(2), y: getY(max) },
        { label: ((max + min) / 2).toFixed(2), y: getY((max + min) / 2) },
        { label: min.toFixed(2), y: getY(min) }
      ],
      nodes: priceHistory.map((h, i) => ({
        x: getX(i),
        y: getY(h.price),
        price: h.price,
        time: h.time
      }))
    };
  }, [priceHistory]);

  const [hoverNode, setHoverNode] = useState<{ x: number; y: number; price: number; time: string } | null>(null);

  // --- 12. EXISTING RETRO COMPATIBLE CHECKS & TASKS STATES ---
  const [promoCode, setPromoCode] = useState('');
  const [giftRecipient, setGiftRecipient] = useState('');
  const [giftAmount, setGiftAmount] = useState(100);
  const [hasCheckedIn, setHasCheckedIn] = useState(false);
  const [streakCount, setStreakCount] = useState(3);

  const handleCheckIn = () => {
    if (hasCheckedIn) return;
    setHasCheckedIn(true);
    setStreakCount((prev) => prev + 1);
    const reward = 50 + streakCount * 10;
    onTransaction(reward, `每日连续签到奖励 (连续签到第 ${streakCount + 1} 天)`);
    triggerToast(`签到成功！获得 +${reward} 积分`);
  };

  const handleRedeemGiftCode = () => {
    const code = promoCode.trim().toUpperCase();
    if (!code) return;

    if (code === 'LEXICON2026') {
      onTransaction(500, '兑换新年积分大礼包 [LEXICON2026]');
      triggerToast('🎉 成功兑换新年特权礼包 +500 积分！');
      setPromoCode('');
    } else if (code === 'SECURESHIELD') {
      onTransaction(300, '兑换安全盾推广礼包 [SECURESHIELD]');
      triggerToast('🔒 成功兑换安全认证礼包 +300 积分！');
      setPromoCode('');
    } else {
      triggerToast('❌ 无效的礼包兑换码，请检查后再试');
    }
  };

  const handleSendGift = (e: React.FormEvent) => {
    e.preventDefault();
    if (!giftRecipient.trim()) {
      triggerToast('请输入接收人账号或邮箱');
      return;
    }
    if (giftAmount <= 0) {
      triggerToast('请输入有效的赠送数量');
      return;
    }
    if (creditBalance < giftAmount) {
      triggerToast('❌ 账户余额不足，无法赠送');
      return;
    }

    onTransaction(-giftAmount, `赠送积分给用户 [${giftRecipient}]`);
    triggerToast(`🎁 成功向 ${giftRecipient} 赠送 ${giftAmount} 积分！`);
    setGiftRecipient('');
  };

  const economyLogs = useMemo(() => {
    return logs.filter(
      (log) => log.domain === 'Economy Center' || log.title.toLowerCase().includes('credit')
    );
  }, [logs]);

  // Calculate current price stats
  const pricePctChange = useMemo(() => {
    if (priceHistory.length < 2) return 0;
    const prev = priceHistory[priceHistory.length - 2].price;
    const curr = creditPrice;
    const pct = ((curr - prev) / prev) * 100;
    return pct;
  }, [priceHistory, creditPrice]);

  return (
    <div className="space-y-6 max-w-[1280px] mx-auto animate-fadeIn relative pb-12">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 bg-[#1A212B] text-[#FAF9F6] border border-[#E5E1D5]/20 font-headline text-xs py-3 px-5 rounded-sm shadow-xl z-50 flex items-center space-x-2 animate-fadeIn">
          <Sparkles size={14} className="text-yellow-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-[#E5E1D5] pb-6">
        <div>
          <div className="flex items-center space-x-2.5">
            <h2 className="font-headline text-3xl font-semibold tracking-tight text-[#1A212B]">
              三、积分经济域
            </h2>
            <span className="px-2 py-0.5 bg-[#1A212B] text-[10px] font-headline font-semibold text-[#FAF9F6] rounded-sm tracking-wider">
              STOCK-MARKET & POINTS MALL
            </span>
          </div>
          <p className="font-label text-sm text-[#585f6a] mt-2">
            支持动态积分炒作、价格涨跌、大额买入卖出、通胀贬值、以及项目方周期性自动化配置调控
          </p>
        </div>

        {/* Navigation for Economy Sub-Tabs */}
        <div className="mt-4 md:mt-0 flex space-x-2 p-1 bg-[#FAF9F6] border border-[#E5E1D5] rounded-md shrink-0">
          <button
            onClick={() => setActiveSubTab('market')}
            className={`px-4 py-1.5 rounded-sm text-xs font-headline font-semibold transition-all flex items-center space-x-1.5 ${
              activeSubTab === 'market'
                ? 'bg-[#1A212B] text-[#FAF9F6]'
                : 'text-[#585f6a] hover:text-[#1A212B]'
            }`}
          >
            <TrendingUp size={13} />
            <span>📈 积分证券交易商城</span>
          </button>
          <button
            onClick={() => setActiveSubTab('tasks')}
            className={`px-4 py-1.5 rounded-sm text-xs font-headline font-semibold transition-all flex items-center space-x-1.5 ${
              activeSubTab === 'tasks'
                ? 'bg-[#1A212B] text-[#FAF9F6]'
                : 'text-[#585f6a] hover:text-[#1A212B]'
            }`}
          >
            <Gift size={13} />
            <span>日常任务与转账</span>
          </button>
        </div>
      </header>

      {/* Live Financial Flash Ticker */}
      <div className="bg-[#FAF9F6] border border-[#E5E1D5] px-4 py-2.5 rounded-sm flex items-center space-x-3.5 overflow-hidden">
        <span className="px-1.5 py-0.5 bg-red-700 text-[#FAF9F6] font-mono text-[9px] font-extrabold uppercase animate-pulse shrink-0">
          FLASH NEWS
        </span>
        <div className="text-xs font-headline text-[#1A212B] truncate flex-1 tracking-tight">
          {activeNews}
        </div>
        <span className="text-[10px] font-mono text-[#585f6a] shrink-0 flex items-center gap-1">
          <Clock size={11} />
          实时报价轮转中
        </span>
      </div>

      {activeSubTab === 'market' ? (
        <div className="space-y-6">
          {/* Top Indicators Board */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Indicator 1: User Points */}
            <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-4 rounded-sm flex justify-between items-center">
              <div>
                <span className="block font-label text-[10px] text-[#585f6a] uppercase">当前可用积分 (CRD)</span>
                <span className="font-headline text-2xl font-bold text-[#1A212B] block mt-1">{creditBalance} CRD</span>
                <span className="text-[10px] font-mono text-[#585f6a]">折合现金: {(creditBalance * creditPrice).toFixed(2)} 元</span>
              </div>
              <div className="w-10 h-10 rounded-sm bg-[#1A212B]/5 flex items-center justify-center text-[#1A212B]">
                <Layers size={18} />
              </div>
            </div>

            {/* Indicator 2: Simulated Cash */}
            <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-4 rounded-sm flex justify-between items-center">
              <div>
                <span className="block font-label text-[10px] text-[#585f6a] uppercase">模拟现金本金 (CNY)</span>
                <span className="font-headline text-2xl font-bold text-[#1A212B] block mt-1">¥ {cashBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                <span className="text-[10px] font-mono text-[#1A212B] cursor-pointer hover:underline" onClick={() => setCashBalance(prev => prev + 5000)}>+ 免费注入 5000 现金筹码</span>
              </div>
              <div className="w-10 h-10 rounded-sm bg-[#1A212B]/5 flex items-center justify-center text-[#1A212B]">
                <DollarSign size={18} />
              </div>
            </div>

            {/* Indicator 3: Ticker price */}
            <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-4 rounded-sm flex justify-between items-center">
              <div>
                <span className="block font-label text-[10px] text-[#585f6a] uppercase">积分市场当前单价</span>
                <div className="flex items-baseline space-x-1.5 mt-1">
                  <span className="font-headline text-2xl font-bold text-[#1A212B]">¥ {creditPrice.toFixed(4)}</span>
                  <span className={`text-[11px] font-mono font-bold flex items-center ${pricePctChange >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                    {pricePctChange >= 0 ? '+' : ''}{pricePctChange.toFixed(2)}%
                    {pricePctChange >= 0 ? <ArrowUpRight size={12} /> : <ArrowDownLeft size={12} />}
                  </span>
                </div>
                <span className="text-[10px] font-mono text-[#585f6a]">当前交易对: CRD / CNY</span>
              </div>
              <div className={`w-10 h-10 rounded-sm flex items-center justify-center ${pricePctChange >= 0 ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
                <TrendingUp size={18} />
              </div>
            </div>

            {/* Indicator 4: Supply Volume */}
            <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-4 rounded-sm flex justify-between items-center">
              <div>
                <span className="block font-label text-[10px] text-[#585f6a] uppercase">全网发行流通总量</span>
                <span className="font-headline text-2xl font-bold text-[#1A212B] block mt-1">25,800 CRD</span>
                <span className="text-[10px] font-mono text-amber-700 font-semibold flex items-center gap-0.5">
                  <AlertTriangle size={10} /> 增发过剩将导致单价大跌
                </span>
              </div>
              <div className="w-10 h-10 rounded-sm bg-[#1A212B]/5 flex items-center justify-center text-[#1A212B]">
                <Activity size={18} />
              </div>
            </div>
          </div>

          {/* Core Trading Layout Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Box (9 columns): Chart + Orderbook + trade module */}
            <div className="lg:col-span-9 space-y-6">
              
              {/* Chart Widget */}
              <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-5 rounded-md relative">
                <div className="flex justify-between items-center border-b border-[#E5E1D5] pb-3 mb-4">
                  <div className="flex items-center space-x-2">
                    <LineChart size={16} className="text-[#1A212B]" />
                    <h3 className="font-headline text-sm font-bold text-[#1A212B] uppercase tracking-wider">
                      积分兑现金(CRD/CNY) K线走势图
                    </h3>
                  </div>
                  <div className="flex space-x-1.5 text-[10px] font-mono">
                    {['1H', '24H', '7D', '30D'].map((t) => (
                      <button key={t} className={`px-2 py-0.5 rounded-sm border ${t === '24H' ? 'bg-[#1A212B] text-[#FAF9F6] border-[#1A212B]' : 'bg-white text-[#585f6a] border-[#E5E1D5] hover:border-[#1A212B]'}`}>
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                {/* SVG Live Render Chart */}
                <div className="relative h-48 w-full mt-2" onMouseLeave={() => setHoverNode(null)}>
                  <svg className="w-full h-full overflow-visible" viewBox="0 0 600 180" preserveAspectRatio="none">
                    <defs>
                      <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={pricePctChange >= 0 ? '#16a34a' : '#dc2626'} stopOpacity="0.25" />
                        <stop offset="100%" stopColor={pricePctChange >= 0 ? '#16a34a' : '#dc2626'} stopOpacity="0.00" />
                      </linearGradient>
                    </defs>

                    {/* Horizontal Gridlines */}
                    {chartPoints.gridLines.map((line, i) => (
                      <g key={i}>
                        <line x1="40" y1={line.y} x2="580" y2={line.y} stroke="#E5E1D5" strokeDasharray="4 4" strokeWidth="0.8" />
                        <text x="5" y={line.y + 4} fill="#585f6a" className="font-mono text-[9px] text-right" style={{ textAnchor: 'start' }}>
                          ¥{line.label}
                        </text>
                      </g>
                    ))}

                    {/* Gradient Area Fill */}
                    <polygon points={chartPoints.fillPath} fill="url(#chartGrad)" />

                    {/* Trend Line */}
                    <polyline points={chartPoints.linePath} fill="none" stroke={pricePctChange >= 0 ? '#15803d' : '#b91c1c'} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />

                    {/* Node dots */}
                    {chartPoints.nodes.map((n, i) => (
                      <circle
                        key={i}
                        cx={n.x}
                        cy={n.y}
                        r="3.5"
                        fill="white"
                        stroke={pricePctChange >= 0 ? '#15803d' : '#b91c1c'}
                        strokeWidth="1.5"
                        className="cursor-pointer hover:r-[5px] transition-all"
                        onMouseEnter={() => setHoverNode(n)}
                      />
                    ))}

                    {/* Vertical tracking crosshair lines */}
                    {hoverNode && (
                      <g>
                        <line x1={hoverNode.x} y1="0" x2={hoverNode.x} y2="160" stroke="#1A212B" strokeOpacity="0.3" strokeDasharray="3 3" />
                        <line x1="40" y1={hoverNode.y} x2="580" y2={hoverNode.y} stroke="#1A212B" strokeOpacity="0.3" strokeDasharray="3 3" />
                      </g>
                    )}
                  </svg>

                  {/* Hover Node Badge */}
                  {hoverNode && (
                    <div
                      className="absolute bg-[#1A212B] text-white border border-[#E5E1D5]/20 p-2 rounded-sm shadow-lg pointer-events-none z-10 font-mono text-[10px] space-y-0.5"
                      style={{
                        left: `${(hoverNode.x / 600) * 100}%`,
                        top: `${Math.max(10, (hoverNode.y / 180) * 100 - 45)}%`,
                        transform: 'translateX(-50%)'
                      }}
                    >
                      <div className="font-bold text-yellow-400">¥ {hoverNode.price.toFixed(4)}</div>
                      <div className="text-gray-300 text-[9px]">时间: {hoverNode.time}</div>
                    </div>
                  )}
                </div>

                {/* Sub-legend indicator */}
                <div className="flex justify-between items-center text-[10px] font-mono text-[#585f6a] mt-3 border-t border-[#E5E1D5]/50 pt-2.5">
                  <span>起始报价: ¥0.8500</span>
                  <div className="flex space-x-3 items-center">
                    <span className="flex items-center"><span className="w-2.5 h-2.5 bg-[#15803d] rounded-full mr-1"></span>多头拉升</span>
                    <span className="flex items-center"><span className="w-2.5 h-2.5 bg-[#b91c1c] rounded-full mr-1"></span>空头砸盘</span>
                  </div>
                  <span>高位极值: ¥{Math.max(...priceHistory.map(h => h.price)).toFixed(2)}</span>
                </div>
              </div>

              {/* Orderbook + trading desk side by side */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Simulated Order Book (盘口数据) */}
                <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-5 rounded-md flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center border-b border-[#E5E1D5] pb-2.5 mb-3">
                      <span className="font-headline text-xs font-bold text-[#1A212B] uppercase tracking-wider">
                        盘口多空买卖挂单 (Depth Book)
                      </span>
                      <span className="px-1.5 py-0.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-[9px] font-mono rounded-sm">
                        Live Ticking
                      </span>
                    </div>

                    {/* Ask Sells (Red) */}
                    <div className="space-y-1">
                      {orderBook.asks.map((ask, i) => (
                        <div key={`ask-${i}`} className="flex justify-between items-center text-[11px] font-mono relative py-0.5 px-1.5 hover:bg-red-50/20 rounded-sm">
                          {/* Vol Visual Fill Bar background */}
                          <div className="absolute right-0 top-0 bottom-0 bg-red-500/5" style={{ width: `${Math.min(100, (ask.volume / 1000) * 100)}%` }}></div>
                          <span className="text-red-600 font-semibold">卖 {5 - i} (Ask)</span>
                          <span className="font-bold text-gray-800">¥ {ask.price.toFixed(4)}</span>
                          <span className="text-gray-600 shrink-0 z-10">{ask.volume} CRD</span>
                        </div>
                      ))}
                    </div>

                    {/* Spread Mid Price */}
                    <div className="border-y border-[#E5E1D5] my-2.5 py-2 text-center bg-[#1A212B]/5">
                      <div className="font-mono text-sm font-black text-gray-900 flex justify-center items-center gap-1">
                        <span>¥ {creditPrice.toFixed(4)}</span>
                        <span className={`text-[10px] font-bold ${pricePctChange >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                          ({pricePctChange >= 0 ? '+' : ''}{pricePctChange.toFixed(2)}%)
                        </span>
                      </div>
                      <span className="block text-[9px] text-[#585f6a] font-mono mt-0.5">市场公允价 / 估算点差: 0.0005 CRD</span>
                    </div>

                    {/* Bid Buys (Green) */}
                    <div className="space-y-1">
                      {orderBook.bids.map((bid, i) => (
                        <div key={`bid-${i}`} className="flex justify-between items-center text-[11px] font-mono relative py-0.5 px-1.5 hover:bg-green-50/20 rounded-sm">
                          {/* Vol Visual Fill Bar background */}
                          <div className="absolute right-0 top-0 bottom-0 bg-green-500/5" style={{ width: `${Math.min(100, (bid.volume / 1000) * 100)}%` }}></div>
                          <span className="text-green-700 font-semibold">买 {i + 1} (Bid)</span>
                          <span className="font-bold text-gray-800">¥ {bid.price.toFixed(4)}</span>
                          <span className="text-gray-600 shrink-0 z-10">{bid.volume} CRD</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <p className="font-body text-[10px] text-gray-400 mt-3 text-right">
                    * 撮合行情模拟自全网背词用户的活跃交互节点
                  </p>
                </div>

                {/* Trading Desk Console (挂单与兑换交易) */}
                <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-5 rounded-md flex flex-col justify-between">
                  <div>
                    {/* Console Tab Toggles */}
                    <div className="grid grid-cols-2 gap-2 border-b border-[#E5E1D5] pb-3.5 mb-4">
                      <button
                        onClick={() => setTradeTab('buy')}
                        className={`py-2 rounded-sm font-headline text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 ${
                          tradeTab === 'buy'
                            ? 'bg-green-700 text-white shadow-sm'
                            : 'bg-white text-gray-600 border border-[#E5E1D5] hover:text-[#1A212B]'
                        }`}
                      >
                        <ArrowUpRight size={14} />
                        <span>限价买入积分</span>
                      </button>
                      <button
                        onClick={() => setTradeTab('sell')}
                        className={`py-2 rounded-sm font-headline text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 ${
                          tradeTab === 'sell'
                            ? 'bg-red-700 text-white shadow-sm'
                            : 'bg-white text-gray-600 border border-[#E5E1D5] hover:text-[#1A212B]'
                        }`}
                      >
                        <ArrowDownLeft size={14} />
                        <span>限价卖出积分</span>
                      </button>
                    </div>

                    {/* Form Input fields */}
                    <div className="space-y-4">
                      {/* Price input */}
                      <div className="space-y-1">
                        <label className="block font-headline text-xs font-bold text-gray-700">市价/限价成交价</label>
                        <div className="relative">
                          <input
                            type="text"
                            disabled
                            value={`¥ ${creditPrice.toFixed(4)} CNY`}
                            className="w-full bg-[#1A212B]/5 border border-[#E5E1D5] text-[#1A212B] font-mono text-xs px-3 py-2 rounded-sm cursor-not-allowed"
                          />
                          <span className="absolute right-3 top-2 text-[10px] font-mono text-[#585f6a]">实时公允</span>
                        </div>
                      </div>

                      {/* Quantity input */}
                      <div className="space-y-1">
                        <div className="flex justify-between items-center">
                          <label className="block font-headline text-xs font-bold text-gray-700">申购/售出数量 (CRD)</label>
                          <span className="font-mono text-[10px] text-gray-500">
                            {tradeTab === 'buy' ? `最高买入约: ${Math.floor(cashBalance / creditPrice)} CRD` : `最多售出: ${creditBalance} CRD`}
                          </span>
                        </div>
                        <div className="relative">
                          <input
                            type="number"
                            min={10}
                            step={10}
                            value={tradeAmount}
                            onChange={(e) => setTradeAmount(Math.max(0, parseInt(e.target.value) || 0))}
                            className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-mono text-xs px-3 py-2 rounded-sm focus:outline-none focus:border-[#1A212B]"
                          />
                          <span className="absolute right-3 top-2 text-[10px] font-mono text-[#585f6a]">CRD</span>
                        </div>
                      </div>

                      {/* Fast selection ratios */}
                      <div className="grid grid-cols-4 gap-1.5">
                        {[0.25, 0.50, 0.75, 1.0].map((ratio) => (
                          <button
                            key={ratio}
                            type="button"
                            onClick={() => {
                              if (tradeTab === 'buy') {
                                const maxBuyable = Math.floor((cashBalance * 0.99) / creditPrice); // Leave some room for fee
                                setTradeAmount(Math.floor(maxBuyable * ratio));
                              } else {
                                setTradeAmount(Math.floor(creditBalance * ratio));
                              }
                            }}
                            className="bg-white hover:bg-gray-100 border border-[#E5E1D5] rounded-sm py-1 font-mono text-[10px] text-gray-600 font-bold"
                          >
                            {ratio * 100}%
                          </button>
                        ))}
                      </div>

                      {/* Subtotal summary card */}
                      <div className="p-3 bg-gray-50 border border-[#E5E1D5] rounded-sm space-y-1.5 font-mono text-[11px] text-gray-700">
                        <div className="flex justify-between">
                          <span>交易估算总额:</span>
                          <span className="font-bold text-gray-900">¥ {(tradeAmount * creditPrice).toFixed(2)} CNY</span>
                        </div>
                        <div className="flex justify-between">
                          <span>模拟手续费 (0.2%):</span>
                          <span>¥ {(tradeAmount * creditPrice * tradeFeePercent).toFixed(2)} CNY</span>
                        </div>
                        <div className="flex justify-between text-xs font-bold border-t border-[#E5E1D5] pt-1.5 mt-1.5 text-gray-900">
                          <span>{tradeTab === 'buy' ? '实付现金总计:' : '实收现金总计:'}</span>
                          <span className={tradeTab === 'buy' ? 'text-green-700' : 'text-emerald-700'}>
                            ¥ {tradeTab === 'buy' ? cashNeeded.toFixed(2) : cashProceeds.toFixed(2)} CNY
                          </span>
                        </div>
                        <div className="flex justify-between border-t border-dashed border-[#E5E1D5] pt-1.5 text-[9px] text-amber-800">
                          <span>预计交易影响:</span>
                          <span>
                            {tradeTab === 'buy' ? '+' : '-'}{(tradePriceImpact * 100).toFixed(2)}% (价格冲击)
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Buy or Sell Submit Trigger */}
                  <div className="mt-4">
                    {tradeTab === 'buy' ? (
                      <button
                        onClick={handleMarketBuy}
                        className="w-full py-2.5 bg-green-700 hover:bg-green-800 text-white font-headline text-xs font-bold uppercase rounded-sm transition-all shadow-sm tracking-wide"
                      >
                        🚀 确 认 买 入 (BUY CRD)
                      </button>
                    ) : (
                      <button
                        onClick={handleMarketSell}
                        className="w-full py-2.5 bg-red-700 hover:bg-red-800 text-white font-headline text-xs font-bold uppercase rounded-sm transition-all shadow-sm tracking-wide"
                      >
                        📉 确 认 卖 出 (SELL CRD)
                      </button>
                    )}
                  </div>
                </div>

              </div>

            </div>

            {/* Right Box (3 columns): Admin Adjust Panel + Airdrop inflation + Market node event alerts */}
            <div className="lg:col-span-3 space-y-6">
              
              {/* Macro Adjustment Manager Panel */}
              <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-5 rounded-md space-y-4">
                <div className="flex items-center space-x-2 border-b border-[#E5E1D5] pb-2.5">
                  <Sliders size={15} className="text-[#1A212B]" />
                  <h3 className="font-headline text-xs font-bold text-[#1A212B] uppercase tracking-wider">
                    管理员动态调控计划 (Scheduler)
                  </h3>
                </div>

                <div className="space-y-3 text-xs">
                  {/* Select adjustment schedule */}
                  <div className="space-y-1">
                    <span className="block font-headline text-[10px] font-bold text-gray-600 uppercase">周期频率</span>
                    <select
                      value={adjustType}
                      onChange={(e) => setAdjustType(e.target.value as any)}
                      className="w-full bg-white border border-[#E5E1D5] p-1.5 rounded-sm font-headline text-[11px]"
                    >
                      <option value="daily">每日固定时段调控 (Daily)</option>
                      <option value="weekly">每周定时重置调控 (Weekly)</option>
                      <option value="custom">特定定时计划 (Scheduled)</option>
                    </select>
                  </div>

                  {/* Direction of adjustment */}
                  <div className="space-y-1">
                    <span className="block font-headline text-[10px] font-bold text-gray-600 uppercase">调控变动方向</span>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => setAdjustDir('up')}
                        className={`flex-1 py-1 rounded-sm text-[10px] font-bold border transition-all ${adjustDir === 'up' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-white text-gray-500 border-gray-200'}`}
                      >
                        上涨 (Increase)
                      </button>
                      <button
                        onClick={() => setAdjustDir('down')}
                        className={`flex-1 py-1 rounded-sm text-[10px] font-bold border transition-all ${adjustDir === 'down' ? 'bg-red-50 text-red-700 border-red-200' : 'bg-white text-gray-500 border-gray-200'}`}
                      >
                        下跌 (Decrease)
                      </button>
                    </div>
                  </div>

                  {/* Percentage input */}
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="block font-headline text-[10px] font-bold text-gray-600 uppercase">比例百分比</span>
                      <span className="font-mono text-[10px] font-bold text-gray-900">{adjustPercent}%</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="50"
                      value={adjustPercent}
                      onChange={(e) => setAdjustPercent(parseInt(e.target.value))}
                      className="w-full accent-[#1A212B]"
                    />
                  </div>

                  {/* Scheduled timer input */}
                  <div className="space-y-1">
                    <span className="block font-headline text-[10px] font-bold text-gray-600 uppercase">执行时刻</span>
                    <input
                      type="text"
                      value={scheduledTargetTime}
                      onChange={(e) => setScheduledTargetTime(e.target.value)}
                      placeholder="e.g. 24:00"
                      className="w-full bg-white border border-[#E5E1D5] px-2 py-1 rounded-sm font-mono text-[11px] focus:outline-none"
                    />
                  </div>

                  {/* Action buttons */}
                  <div className="space-y-2 pt-2 border-t border-[#E5E1D5]">
                    <button
                      onClick={handleSaveManagerPlan}
                      className="w-full py-1.5 bg-[#1A212B]/5 hover:bg-[#1A212B]/10 text-[#1A212B] border border-[#1A212B]/20 rounded-sm font-headline text-[11px] font-bold uppercase transition-all"
                    >
                      💾 应用并保存周期配置
                    </button>
                    <button
                      onClick={handleExecuteManagerPlan}
                      className="w-full py-1.5 bg-[#1A212B] hover:bg-[#1A212B]/90 text-white rounded-sm font-headline text-[11px] font-bold uppercase transition-all shadow-sm flex items-center justify-center gap-1"
                    >
                      <Play size={11} /> 立即测试自动调控
                    </button>
                  </div>
                </div>
              </div>

              {/* Airdrop dilution mechanism & Pump dump panel */}
              <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-5 rounded-md space-y-4">
                <div className="flex items-center space-x-2 border-b border-[#E5E1D5] pb-2.5">
                  <Award size={15} className="text-[#1A212B]" />
                  <h3 className="font-headline text-xs font-bold text-[#1A212B] uppercase tracking-wider">
                    免费空投 & 庄家扫货
                  </h3>
                </div>

                <div className="space-y-2.5">
                  {/* FREE AIRDROP BONUS FOR DILUTION TEST */}
                  <div className="p-3 bg-amber-50/50 border border-amber-200 rounded-sm text-xs space-y-2">
                    <span className="font-headline font-bold text-amber-900 flex items-center gap-1 text-[11px]">
                      <Gift size={12} /> 申领免费特权空投 (+200)
                    </span>
                    <p className="text-[10px] text-amber-800 leading-relaxed font-body">
                      无需本金，点击可无成本领取 200 积分。但将带来通胀效应，使积分价格贬值 -15%！
                    </p>
                    <button
                      onClick={handleAirdropInflation}
                      className="w-full py-1.5 bg-amber-700 hover:bg-amber-800 text-white rounded-sm font-headline text-[10px] font-bold uppercase transition-all tracking-wider"
                    >
                      🎁 免费申领 200 CRD 福利
                    </button>
                  </div>

                  {/* WHALE PUMP AND DUMP CHEATS */}
                  <div className="p-3 bg-gray-50 border border-gray-200 rounded-sm text-xs space-y-2">
                    <span className="font-headline font-bold text-[#1A212B] flex items-center gap-1 text-[11px]">
                      <Zap size={12} className="text-yellow-500" /> 庄家暴力控盘工具 (Cheats)
                    </span>
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <button
                        onClick={handleWhalePump}
                        className="py-1.5 bg-green-700 hover:bg-green-800 text-white rounded-sm font-headline text-[10px] font-bold uppercase transition-all"
                      >
                        🚀 强力拉升
                      </button>
                      <button
                        onClick={handleWhaleDump}
                        className="py-1.5 bg-red-700 hover:bg-red-800 text-white rounded-sm font-headline text-[10px] font-bold uppercase transition-all"
                      >
                        📉 强力砸盘
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Ticker Event Logs (市场历史快讯) */}
              <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-5 rounded-md flex flex-col justify-between h-[340px]">
                <div className="space-y-2.5 h-full flex flex-col justify-between">
                  <div className="flex items-center space-x-2 border-b border-[#E5E1D5] pb-2">
                    <Activity size={15} className="text-[#1A212B]" />
                    <h3 className="font-headline text-xs font-bold text-[#1A212B] uppercase tracking-wider">
                      交易所快讯与交易记录 (Feed)
                    </h3>
                  </div>

                  <div className="space-y-2 overflow-y-auto custom-scrollbar flex-1 pr-1 max-h-[250px] text-[11px]">
                    {marketLogs.map((item) => (
                      <div key={item.id} className="border-b border-[#E5E1D5]/40 pb-2 last:border-b-0">
                        <div className="flex justify-between items-center mb-0.5">
                          <span className="text-[9px] font-mono text-gray-400">{item.time}</span>
                          <span className={`font-mono text-[9px] font-bold uppercase px-1.5 py-0.1 rounded-sm ${
                            item.type === 'buy' ? 'bg-green-50 text-green-700' :
                            item.type === 'sell' ? 'bg-red-50 text-red-700' :
                            item.type === 'warn' ? 'bg-amber-50 text-amber-700' : 'bg-gray-100 text-gray-700'
                          }`}>
                            {item.type}
                          </span>
                        </div>
                        <p className="font-headline text-[10.5px] leading-relaxed text-gray-800 tracking-tight">
                          {item.msg}
                        </p>
                        <div className="mt-1 flex items-center justify-between font-mono text-[9px] text-[#585f6a]">
                          <span>成交公允价:</span>
                          <span className="font-bold text-[#1A212B]">¥ {item.price.toFixed(4)} CNY</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left column: Check-in, tasks, gift packs */}
          <div className="lg:col-span-7 space-y-6">
            {/* 签到与任务 */}
            <section className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-5">
              <div className="flex justify-between items-start border-b border-[#E5E1D5]/60 pb-3">
                <div>
                  <h3 className="font-headline text-base font-semibold text-[#1A212B]">
                    签到与任务
                  </h3>
                  <p className="font-body text-xs text-[#585f6a] mt-0.5">
                    每日签到累积连签翻倍，完成系统任务即可源源不断获取可用积分
                  </p>
                </div>
                <Calendar size={20} className="text-[#1A212B]" />
              </div>

              {/* Check-in Calendar Board */}
              <div className="bg-[#E5E1D5]/20 p-4 rounded-sm border border-[#E5E1D5]/40 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center space-x-3.5">
                  <div className="w-12 h-12 rounded-sm bg-[#1A212B] text-[#FAF9F6] flex flex-col items-center justify-center font-headline">
                    <span className="text-[10px] uppercase font-bold tracking-wider opacity-80">STREAK</span>
                    <span className="text-lg font-extrabold leading-none">{streakCount}</span>
                  </div>
                  <div>
                    <h4 className="font-headline text-sm font-semibold text-[#1A212B]">
                      连续签到领特权
                    </h4>
                    <p className="font-body text-xs text-[#585f6a] mt-0.5">
                      每日签到基准 50 积分，连续签到每天额外 +10 积分
                    </p>
                  </div>
                </div>

                <button
                  disabled={hasCheckedIn}
                  onClick={handleCheckIn}
                  className={`w-full sm:w-auto px-6 py-2.5 rounded-sm font-headline text-xs font-semibold transition-all flex items-center justify-center space-x-1.5 ${
                    hasCheckedIn
                      ? 'bg-[#E5E1D5] text-[#585f6a] border border-[#E5E1D5] cursor-not-allowed'
                      : 'bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90 shadow-sm'
                  }`}
                >
                  {hasCheckedIn ? (
                    <>
                      <CheckCircle2 size={14} className="text-emerald-700" />
                      <span>今日已成功签到</span>
                    </>
                  ) : (
                    <>
                      <UserCheck size={14} />
                      <span>立即打卡签到</span>
                    </>
                  )}
                </button>
              </div>

              {/* Daily Tasks List */}
              <div className="space-y-3">
                <span className="block font-headline text-xs font-semibold text-[#1A212B] uppercase tracking-wider">
                  积分任务大厅 (赚取积分)
                </span>

                <div className="divide-y divide-[#E5E1D5]/60 border border-[#E5E1D5]/60 rounded-sm">
                  {/* Task 1 */}
                  <div className="p-4 flex justify-between items-center bg-[#FAF9F6]">
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <span className="font-headline text-xs font-semibold text-[#1A212B]">执行全域安全备份</span>
                        <span className="text-[9px] px-1.5 py-0.5 bg-amber-50 text-amber-800 rounded-sm border border-amber-200">一次性</span>
                      </div>
                      <p className="font-body text-[11px] text-[#585f6a] mt-0.5">在身份安全域执行一键安全备份导出，保障账号安全</p>
                    </div>
                    <button
                      onClick={() => {
                        onTransaction(150, '完成任务: 导出全域安全备份');
                        triggerToast('🎉 备份任务完成！+150 积分');
                      }}
                      className="px-2.5 py-1.5 border border-[#1A212B] text-[#1A212B] hover:bg-[#1A212B]/5 font-headline text-[10px] font-semibold rounded-sm transition-all shrink-0"
                    >
                      +150 积分
                    </button>
                  </div>

                  {/* Task 2 */}
                  <div className="p-4 flex justify-between items-center bg-[#FAF9F6]">
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <span className="font-headline text-xs font-semibold text-[#1A212B]">官方单词库高频查词</span>
                        <span className="text-[9px] px-1.5 py-0.5 bg-emerald-50 text-emerald-800 rounded-sm border border-emerald-200">每日</span>
                      </div>
                      <p className="font-body text-[11px] text-[#585f6a] mt-0.5">在单词业务域查询官方词库，探索并扩展词汇认知</p>
                    </div>
                    <button
                      onClick={() => {
                        onTransaction(100, '完成每日任务: 探索官方词库');
                        triggerToast('🎉 单词学习打卡成功！+100 积分');
                      }}
                      className="px-2.5 py-1.5 border border-[#1A212B] text-[#1A212B] hover:bg-[#1A212B]/5 font-headline text-[10px] font-semibold rounded-sm transition-all shrink-0"
                    >
                      +100 积分
                    </button>
                  </div>

                  {/* Task 3 */}
                  <div className="p-4 flex justify-between items-center bg-[#FAF9F6]">
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <span className="font-headline text-xs font-semibold text-[#1A212B]">异常安全兜底压力测试</span>
                        <span className="text-[9px] px-1.5 py-0.5 bg-blue-50 text-blue-800 rounded-sm border border-blue-200">每日</span>
                      </div>
                      <p className="font-body text-[11px] text-[#585f6a] mt-0.5">模拟全网入侵或密码泄露并一键启用隔离隔离兜底方案</p>
                    </div>
                    <button
                      onClick={() => {
                        onTransaction(200, '完成每日任务: 隔离兜底压力测试');
                        triggerToast('🎉 隔离安全测试成功！+200 积分');
                      }}
                      className="px-2.5 py-1.5 border border-[#1A212B] text-[#1A212B] hover:bg-[#1A212B]/5 font-headline text-[10px] font-semibold rounded-sm transition-all shrink-0"
                    >
                      +200 积分
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* 积分礼包与转账 */}
            <section className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-5">
              <div className="flex justify-between items-start border-b border-[#E5E1D5]/60 pb-3">
                <div>
                  <h3 className="font-headline text-base font-semibold text-[#1A212B]">
                    积分兑换礼包与好友转账
                  </h3>
                  <p className="font-body text-xs text-[#585f6a] mt-0.5">
                    输入官方兑换码，或输入好友的UID账号进行积分的实时赠送与转账
                  </p>
                </div>
                <Gift size={20} className="text-[#1A212B]" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="space-y-3.5">
                  <div className="space-y-1">
                    <label className="block font-headline text-xs font-semibold text-[#1A212B]">
                      输入礼包代码
                    </label>
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        placeholder="e.g. LEXICON2026"
                        value={promoCode}
                        onChange={(e) => setPromoCode(e.target.value)}
                        className="flex-1 bg-white border border-[#E5E1D5] text-[#1A212B] font-mono text-xs px-2.5 py-2 rounded-sm focus:outline-none focus:border-[#1A212B]"
                      />
                      <button
                        onClick={handleRedeemGiftCode}
                        className="bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90 font-headline text-xs font-semibold px-4 rounded-sm transition-all"
                      >
                        兑换
                      </button>
                    </div>
                  </div>

                  <div className="bg-[#FAF9F6] border border-[#E5E1D5] p-3 rounded-sm">
                    <span className="block font-headline text-[11px] font-semibold text-[#1A212B] uppercase">官方推荐特权兑换码:</span>
                    <div className="mt-2 space-y-1 text-[10px] font-mono">
                      <div className="flex justify-between">
                        <span className="text-[#585f6a]">新年直充包 (500 pts):</span>
                        <span className="font-bold text-[#1A212B]">LEXICON2026</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#585f6a]">安全卫士包 (300 pts):</span>
                        <span className="font-bold text-[#1A212B]">SECURESHIELD</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Gift Sending Transfer Form */}
                <form onSubmit={handleSendGift} className="p-4 rounded-sm border border-[#E5E1D5] space-y-3 bg-[#E5E1D5]/10">
                  <span className="block font-headline text-xs font-bold text-[#1A212B] flex items-center gap-1">
                    <Send size={12} /> 向好友赠送或转账积分
                  </span>
                  
                  <div className="space-y-2">
                    <input
                      type="text"
                      placeholder="接收方账户UID / 邮箱"
                      value={giftRecipient}
                      onChange={(e) => setGiftRecipient(e.target.value)}
                      className="w-full bg-white border border-[#E5E1D5] text-[#1A212B] font-body text-[11px] px-2 py-1.5 rounded-sm focus:outline-none focus:border-[#1A212B]"
                    />
                    <div className="flex items-center space-x-2">
                      <span className="font-body text-[11px] text-[#585f6a]">赠送数额:</span>
                      <input
                        type="number"
                        min={10}
                        step={10}
                        value={giftAmount}
                        onChange={(e) => setGiftAmount(Number(e.target.value))}
                        className="w-24 bg-white border border-[#E5E1D5] text-[#1A212B] font-mono text-xs px-2 py-1 rounded-sm focus:outline-none focus:border-[#1A212B]"
                      />
                      <span className="font-mono text-[10px] text-gray-500">CRD</span>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-1.5 bg-[#1A212B] text-[#FAF9F6] hover:bg-[#1A212B]/90 font-headline text-xs font-semibold rounded-sm transition-all"
                  >
                    确认赠送积分
                  </button>
                </form>
              </div>
            </section>
          </div>

          {/* Right column: Transaction ledger */}
          <div className="lg:col-span-5 space-y-6">
            <section className="bento-card p-6 rounded-md border border-[#E5E1D5] bg-[#FAF9F6] space-y-4 h-full flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex justify-between items-start border-b border-[#E5E1D5]/60 pb-3">
                  <div>
                    <h3 className="font-headline text-base font-semibold text-[#1A212B]">
                      积分收支明细对账 (Ledger)
                    </h3>
                    <p className="font-body text-xs text-[#585f6a] mt-0.5">
                      收支明细全记录，确保积分流转的透明与可审计性
                    </p>
                  </div>
                  <DollarSign size={20} className="text-[#1A212B]" />
                </div>

                {/* Transactions list */}
                <div className="space-y-3 max-h-[420px] overflow-y-auto custom-scrollbar pr-1">
                  {economyLogs.length === 0 ? (
                    <div className="py-12 text-center text-xs font-body text-[#585f6a]">
                      暂无积分收支流水明细
                    </div>
                  ) : (
                    economyLogs.map((log) => {
                      const isDeduction = log.title.includes('Deducted') || log.title.includes('Spend') || log.title.includes('扣除') || log.title.includes('赠送积分') || log.title.includes('Deduction');
                      
                      return (
                        <div key={log.id} className="p-3 border border-[#E5E1D5]/60 rounded-sm bg-[#FAF9F6] hover:bg-[#F9F7F2] transition-colors flex justify-between items-start gap-3">
                          <div className="min-w-0">
                            <h4 className="font-headline text-xs font-semibold text-[#1A212B] truncate">
                              {log.title}
                            </h4>
                            <p className="font-body text-[10px] text-[#585f6a] leading-normal mt-0.5">
                              {log.description}
                            </p>
                            <span className="font-mono text-[9px] text-gray-400 block mt-1">
                              {new Date(log.timestamp).toLocaleString([], {
                                month: '2-digit',
                                day: '2-digit',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>

                          <div className={`font-mono text-xs font-bold shrink-0 flex items-center ${isDeduction ? 'text-red-700' : 'text-emerald-700'}`}>
                            {isDeduction ? (
                              <ArrowDownLeft size={12} className="mr-0.5 shrink-0" />
                            ) : (
                              <ArrowUpRight size={12} className="mr-0.5 shrink-0" />
                            )}
                            <span>
                              {isDeduction ? '-' : '+'}
                              {log.title.match(/\d+/) ? log.title.match(/\d+/)?.[0] : 'Adjust'}
                            </span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              <div className="bg-[#FAF9F6] border-t border-[#E5E1D5] pt-4 mt-4 text-center">
                <span className="font-mono text-[10px] text-gray-400">
                  SYSTEM AUDITING CRYPTO ID: L_ECON_{creditBalance}
                </span>
              </div>
            </section>
          </div>
        </div>
      )}
    </div>
  );
};
