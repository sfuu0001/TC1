import React, { useState, useMemo } from 'react';
import { Search, Filter, Trash2, Download, Copy, Check } from 'lucide-react';
import { SystemEvent } from '../types';
import { ModalWrapper } from './InteractiveDialogs';

interface FullLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: SystemEvent[];
  onClear: () => void;
}

export const FullLogModal: React.FC<FullLogModalProps> = ({
  isOpen,
  onClose,
  logs,
  onClear,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDomain, setSelectedDomain] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [copied, setCopied] = useState(false);

  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      const matchesSearch =
        log.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDomain = selectedDomain === 'all' || log.domain === selectedDomain;
      const matchesType = selectedType === 'all' || log.type === selectedType;

      return matchesSearch && matchesDomain && matchesType;
    });
  }, [logs, searchTerm, selectedDomain, selectedType]);

  const handleCopy = () => {
    const text = JSON.stringify(logs, null, 2);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExport = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', 'lexicon_security_audit.json');
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Security System Audit Log"
      icon={<Filter size={18} />}
    >
      <div className="space-y-4 max-w-4xl w-full max-h-[75vh] flex flex-col">
        {/* Search and Filters Bar */}
        <div className="space-y-3">
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-[#585f6a]">
              <Search size={16} />
            </span>
            <input
              type="text"
              placeholder="Search security log payload metadata..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-xs pl-9 pr-4 py-2 rounded-sm focus:outline-none focus:border-[#1A212B]"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block font-headline text-[10px] text-[#585f6a] uppercase tracking-wider mb-1">
                Filter Domain
              </label>
              <select
                value={selectedDomain}
                onChange={(e) => setSelectedDomain(e.target.value)}
                className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-[11px] px-2 py-1.5 rounded-sm focus:outline-none"
              >
                <option value="all">All Domains</option>
                <option value="Account & Identity">Account & Identity</option>
                <option value="Economy Center">Economy Center</option>
                <option value="Membership Hub">Membership Hub</option>
                <option value="Lexis Core">Lexis Core</option>
                <option value="General">General</option>
              </select>
            </div>

            <div>
              <label className="block font-headline text-[10px] text-[#585f6a] uppercase tracking-wider mb-1">
                Filter Severity
              </label>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="w-full bg-[#F9F7F2] border border-[#E5E1D5] text-[#1A212B] font-body text-[11px] px-2 py-1.5 rounded-sm focus:outline-none"
              >
                <option value="all">All Levels</option>
                <option value="success">Success</option>
                <option value="info">Info</option>
                <option value="warning">Warning</option>
                <option value="error">Error</option>
              </select>
            </div>
          </div>
        </div>

        {/* Action Bar */}
        <div className="flex justify-between items-center text-xs py-1 border-b border-[#E5E1D5]">
          <span className="font-label text-[#585f6a]">
            Showing {filteredLogs.length} of {logs.length} events
          </span>
          <div className="flex space-x-2">
            <button
              onClick={handleCopy}
              className="flex items-center space-x-1 px-2.5 py-1 border border-[#E5E1D5] hover:border-[#1A212B] hover:text-[#1A212B] text-[#585f6a] rounded-sm transition-colors font-headline"
            >
              {copied ? <Check size={12} /> : <Copy size={12} />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
            <button
              onClick={handleExport}
              className="flex items-center space-x-1 px-2.5 py-1 border border-[#E5E1D5] hover:border-[#1A212B] hover:text-[#1A212B] text-[#585f6a] rounded-sm transition-colors font-headline"
            >
              <Download size={12} />
              <span>Export</span>
            </button>
            <button
              onClick={onClear}
              className="flex items-center space-x-1 px-2.5 py-1 border border-brand-error/40 hover:border-brand-error text-brand-error hover:bg-brand-error/5 rounded-sm transition-colors font-headline"
            >
              <Trash2 size={12} />
              <span>Clear</span>
            </button>
          </div>
        </div>

        {/* Table Content */}
        <div className="flex-1 overflow-y-auto max-h-[350px] custom-scrollbar border border-[#E5E1D5] rounded-sm bg-[#FAF9F6]">
          <table className="w-full text-left font-body text-xs border-collapse">
            <thead>
              <tr className="bg-[#F9F7F2] border-b border-[#E5E1D5] sticky top-0">
                <th className="p-2.5 font-headline font-semibold text-[#1A212B]">Timestamp</th>
                <th className="p-2.5 font-headline font-semibold text-[#1A212B]">Domain</th>
                <th className="p-2.5 font-headline font-semibold text-[#1A212B]">Event</th>
                <th className="p-2.5 font-headline font-semibold text-[#1A212B]">Metadata payload</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E5E1D5]">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={4} className="p-8 text-center text-[#585f6a]">
                    No security event logs match current search filters.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-[#F9F7F2]/40 transition-colors">
                    <td className="p-2.5 text-[11px] whitespace-nowrap text-[#585f6a]">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </td>
                    <td className="p-2.5">
                      <span className="px-1.5 py-0.5 bg-[#F9F7F2] border border-[#E5E1D5] rounded-sm text-[10px] font-label text-[#1A212B]">
                        {log.domain}
                      </span>
                    </td>
                    <td className="p-2.5">
                      <div className="flex items-center space-x-1.5">
                        <span
                          className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                            log.type === 'error'
                              ? 'bg-[#ba1a1a]'
                              : log.type === 'warning'
                              ? 'bg-amber-500'
                              : log.type === 'success'
                              ? 'bg-[#1A212B]'
                              : 'bg-[#585f6a]'
                          }`}
                        />
                        <span className="font-semibold text-[#1A212B]">{log.title}</span>
                      </div>
                    </td>
                    <td className="p-2.5 text-[11px] text-[#585f6a]">
                      {log.description}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </ModalWrapper>
  );
};
