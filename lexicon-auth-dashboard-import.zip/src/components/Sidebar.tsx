import React from 'react';
import { User, Bell, Menu, X, Activity, Coins, Crown, BookOpen } from 'lucide-react';
import { Profile } from '../types';

interface SidebarProps {
  profile: Profile;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onEditProfile: () => void;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  profile,
  activeTab,
  setActiveTab,
  onEditProfile,
  isMobileOpen,
  setIsMobileOpen,
}) => {
  const menuItems = [
    { id: 'dashboard', label: '中控台', icon: <Activity size={18} /> },
    { id: 'identity', label: '账号身份域', icon: <User size={18} /> },
    { id: 'economy', label: '积分经济域', icon: <Coins size={18} /> },
    { id: 'membership', label: '会员增值域', icon: <Crown size={18} /> },
    { id: 'lexis', label: '单词核心业务域', icon: <BookOpen size={18} /> },
    { id: 'notifications', label: '消息通知域', icon: <Bell size={18} /> },
  ];

  return (
    <>
      {/* Mobile Nav Top Bar */}
      <div className="md:hidden flex items-center justify-between p-4 border-b border-[#E5E1D5] bg-[#FAF9F6] sticky top-0 z-30">
        <div className="flex items-center space-x-2">
          <span className="font-headline text-xl font-bold tracking-tight text-[#1A212B]">
            Lexicon
          </span>
          <span className="px-2 py-0.5 bg-[#1A212B] text-[10px] font-headline font-semibold text-[#FAF9F6] rounded-sm">
            AUTH
          </span>
        </div>
        <button
          onClick={() => setIsMobileOpen(!isMobileOpen)}
          className="text-[#1A212B] p-1"
          aria-label="Toggle Menu"
        >
          {isMobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* SideNavBar container */}
      <aside
        className={`${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0 fixed md:sticky top-0 left-0 h-screen w-64 bg-[#F9F7F2] border-r border-[#E5E1D5] transition-transform duration-300 ease-in-out z-40 flex flex-col`}
      >
        {/* Logo and Brand */}
        <div className="px-6 h-[57px] border-b border-[#E5E1D5] flex flex-col justify-center">
          <div className="flex items-center space-x-2">
            <span className="font-headline text-lg font-bold tracking-tight text-[#1A212B]">
              Lexicon
            </span>
            <span className="px-1.5 py-0.5 bg-[#1A212B] text-[8px] font-headline font-semibold text-[#FAF9F6] rounded-sm tracking-wide">
              AUTH
            </span>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 py-6 px-4 space-y-1.5 overflow-y-auto custom-scrollbar">
          {menuItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsMobileOpen(false);
                }}
                className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-sm transition-all group ${
                  isActive
                    ? 'bg-[#E5E1D5] text-[#1A212B] font-semibold border-l-2 border-[#1A212B]'
                    : 'text-[#585f6a] hover:bg-[#E5E1D5]/50 hover:text-[#1A212B]'
                }`}
              >
                <span className={`text-lg transition-opacity ${isActive ? 'opacity-100' : 'opacity-80 group-hover:opacity-100'}`}>
                  {item.icon}
                </span>
                <span className="font-headline text-sm font-medium">
                  {item.label}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Profile Avatar / Quick Controls Footer */}
        <div className="p-4 border-t border-[#E5E1D5] flex items-center justify-between bg-[#F9F7F2]">
          <div className="flex items-center space-x-3">
            <button
              onClick={onEditProfile}
              className="relative group focus:outline-none"
              title="Edit Profile"
            >
              <img
                alt="Security Identity"
                className="w-10 h-10 rounded-full border border-[#E5E1D5] bg-[#FAF9F6] p-0.5 group-hover:border-[#1A212B] transition-all"
                src={profile.avatar}
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-600 border border-[#F9F7F2] rounded-full" />
            </button>
            <div className="text-left">
              <p className="font-headline text-xs font-semibold text-[#1A212B]">
                {profile.name}
              </p>
              <button
                onClick={onEditProfile}
                className="font-label text-[10px] text-[#585f6a] hover:text-[#1A212B] underline"
              >
                Manage Profile
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile overlay backdrop when sidebar is open */}
      {isMobileOpen && (
        <div
          onClick={() => setIsMobileOpen(false)}
          className="md:hidden fixed inset-0 bg-[#1A212B]/30 backdrop-blur-xs z-30"
        />
      )}
    </>
  );
};
