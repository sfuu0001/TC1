export interface SystemEvent {
  id: string;
  title: string;
  description: string;
  domain: 'Account & Identity' | 'Economy Center' | 'Membership Hub' | 'Lexis Core' | 'General';
  type: 'info' | 'warning' | 'error' | 'success';
  timestamp: Date;
}

export interface ApiKey {
  id: string;
  key: string;
  name: string;
  created: Date;
}

export interface Lexeme {
  id: string;
  word: string;
  translation: string;
  partOfSpeech: string;
  addedAt: Date;
}

export interface Profile {
  name: string;
  role: string;
  avatar: string;
}

export interface DashboardStats {
  identityHealth: number;
  apiUsage: number;
  totalLexemes: number;
  creditBalance: number;
}
