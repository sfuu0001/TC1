import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';

// Self-hosted fonts (no external requests to Google Fonts).
import '@fontsource/atkinson-hyperlegible-next/latin.css';
import '@fontsource/atkinson-hyperlegible-next/latin-italic.css';
import '@fontsource/courier-prime/latin.css';
import '@fontsource/courier-prime/latin-italic.css';
import '@fontsource/eb-garamond/latin.css';
import '@fontsource/eb-garamond/latin-italic.css';

import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
